#!/usr/bin/env bash
# 小鲸鱼 APK 构建脚本（手机上直接跑）
#   bash build.sh          构建
#   bash build.sh --check  只检查工具链
set -uo pipefail

ROOT="$HOME/xiaojingyu-app"
AND="$ROOT/android"
OUT="$ROOT/build"
EXT="$PREFIX/extensions"
TC="$HOME/toolchain"                 # 自建工具链（扩展中心装不上时的旁路）
ANDROID_JAR="${ANDROID_JAR:-$HOME/android.jar}"
FW_RES="/system/framework/framework-res.apk"
PKG=app.xiaojingyu.chat

say() { printf '\033[36m==>\033[0m %s\n' "$*"; }
die() { printf '\033[31m!!\033[0m %s\n' "$*" >&2; exit 1; }

# ---- 工具链定位：优先自建的，其次扩展中心的 ----
JDK=""
for c in "$TC"/lib/jvm/* "$EXT"/openjdk-21/lib/jvm/* "$EXT"/openjdk-17/lib/jvm/*; do
  [ -x "$c/bin/javac" ] && JDK="$c" && break
done
JAVAC="${JDK:+$JDK/bin/javac}"; JAVA="${JDK:+$JDK/bin/java}"; KEYTOOL="${JDK:+$JDK/bin/keytool}"

pick() { for d in "$TC/bin" "$EXT"/android-buildtools/bin; do [ -e "$d/$1" ] && { echo "$d/$1"; return; }; done; }
AAPT="$(pick aapt)"
APKSIGNER="$(pick apksigner)"
D8="$(pick d8)"
ZIPALIGN="$(pick zipalign)"
D8JAR="$(ls "$TC"/share/java/d8.jar "$EXT"/android-buildtools/share/java/d8.jar 2>/dev/null | head -1)"
APKSIGNER_JAR="$(ls "$TC"/share/java/apksigner.jar "$EXT"/android-buildtools/share/java/apksigner.jar 2>/dev/null | head -1)"

# Termux 二进制写死 /data/data/com.termux/files/usr/lib 的 RPATH，补上库搜索路径
if [ -d "$TC/lib" ]; then
  export LD_LIBRARY_PATH="$TC/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
fi

say "工具链"
printf '   JDK       %s\n   AAPT      %s\n   APKSIGNER %s\n   D8        %s / %s\n   ZIPALIGN  %s\n' \
  "${JDK:-缺失}" "${AAPT:-缺失}" "${APKSIGNER:-缺失}" "${D8:-缺失}" "${D8JAR:-缺失}" "${ZIPALIGN:-（可选）}"

[ -f "$ANDROID_JAR" ] || die "缺 android.jar"
[ "${1:-}" = "--check" ] && exit 0
[ -n "$JDK" ] || die "缺 JDK（javac）"
[ -n "$AAPT" ] || die "缺 aapt"
{ [ -n "$APKSIGNER_JAR" ] || [ -n "$APKSIGNER" ]; } || die "缺 apksigner"
{ [ -n "$D8" ] || [ -n "$D8JAR" ]; } || die "缺 d8"

rm -rf "$OUT"; mkdir -p "$OUT/classes" "$OUT/dex" "$OUT/gen/$PKG" "$OUT/jar"

say "生成 Keys.java"
node "$ROOT/tools/gen-keys.mjs" "$OUT/gen/$PKG/Keys.java" || die "生成 Keys.java 失败"

say "编译 Java"
find "$AND/src" "$OUT/gen" -name '*.java' > "$OUT/sources.txt"
CLS="$OUT/classes/${PKG//./\/}"
if ! "$JAVAC" -encoding UTF-8 -nowarn -source 8 -target 8 -classpath "$ANDROID_JAR" \
      -d "$OUT/classes" @"$OUT/sources.txt" 2>"$OUT/javac.log"; then
  say "带 -source/-target 8 失败，改用默认版本重试"
  "$JAVAC" -encoding UTF-8 -nowarn -classpath "$ANDROID_JAR" -d "$OUT/classes" @"$OUT/sources.txt" 2>&1 | tail -8
else
  grep -v -e '^Note:' -e 'warning' "$OUT/javac.log" | head -5
fi
[ -f "$CLS/MainActivity.class" ] || die "编译失败（看 $OUT/javac.log）"
[ -f "$CLS/Keys.class" ] || die "Keys.java 没编译出来"

say "dex"
find "$OUT/classes" -name '*.class' > "$OUT/classes.txt"
if [ -n "$D8JAR" ]; then
  "$JAVA" -cp "$D8JAR" com.android.tools.r8.D8 --min-api 21 --lib "$ANDROID_JAR" --output "$OUT/dex" @"$OUT/classes.txt" 2>&1 | tail -4
else
  bash "$D8" --min-api 21 --lib "$ANDROID_JAR" --output "$OUT/dex" @"$OUT/classes.txt" 2>&1 | tail -4
fi
[ -f "$OUT/dex/classes.dex" ] || die "dex 失败"
say "  classes.dex $(stat -c%s "$OUT/dex/classes.dex" 2>/dev/null || echo '?') 字节"

say "aapt 打包（含网页资源）"
"$AAPT" package -f -M "$AND/AndroidManifest.xml" -I "$FW_RES" -S "$AND/res" -A "$ROOT/app" \
  -F "$OUT/app-unsigned.apk" 2>&1 | tail -4
[ -f "$OUT/app-unsigned.apk" ] || die "aapt 打包失败"
( cd "$OUT/dex" && "$AAPT" add "$OUT/app-unsigned.apk" classes.dex ) | tail -1

KS="$AND/xiaojingyu.keystore"
if [ ! -f "$KS" ]; then
  say "生成自签密钥"
  "$KEYTOOL" -genkeypair -keystore "$KS" -alias xjy -keyalg RSA -keysize 2048 -validity 10950 \
    -storepass xiaojingyu -keypass xiaojingyu -dname "CN=XiaoJingYu, OU=Personal, O=Personal, C=CN" >/dev/null 2>&1 \
    || die "keytool 失败"
fi

APK="$OUT/xiaojingyu.apk"
UNSIGNED="$OUT/app-unsigned.apk"
if [ -n "$ZIPALIGN" ]; then
  say "zipalign（必须在签名之前）"
  "$ZIPALIGN" -f 4 "$UNSIGNED" "$OUT/app-aligned.apk" && UNSIGNED="$OUT/app-aligned.apk" && say "  aligned ok"
fi

say "签名"
if [ -n "$APKSIGNER_JAR" ]; then
  "$JAVA" -jar "$APKSIGNER_JAR" sign --ks "$KS" --ks-pass pass:xiaojingyu --key-pass pass:xiaojingyu \
    --v1-signing-enabled true --v2-signing-enabled true --out "$APK" "$UNSIGNED" 2>&1 | tail -3
else
  bash "$APKSIGNER" sign --ks "$KS" --ks-pass pass:xiaojingyu --key-pass pass:xiaojingyu \
    --v1-signing-enabled true --v2-signing-enabled true --out "$APK" "$UNSIGNED" 2>&1 | tail -3
fi
[ -f "$APK" ] || die "签名失败"

say "验签"
if [ -n "$APKSIGNER_JAR" ]; then
  "$JAVA" -jar "$APKSIGNER_JAR" verify --print-certs "$APK" 2>&1 | head -5
  "$JAVA" -jar "$APKSIGNER_JAR" verify "$APK" >/dev/null 2>&1 || die "APK 验签不通过"
else
  bash "$APKSIGNER" verify --print-certs "$APK" 2>&1 | head -5
fi

DEST="/storage/emulated/0/Download/小鲸鱼.apk"
cp "$APK" "$DEST" 2>/dev/null && say "已放到 $DEST" || say "拷贝失败（APK 在 $APK）"
ls -la "$APK"
say "完成"
