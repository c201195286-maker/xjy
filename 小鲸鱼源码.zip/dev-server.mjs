// 小鲸鱼 · 本机预览服务器（真机上不用它，真机走 Java 桥）
// 作用：在 DSH 浏览器里直接试这个聊天页；/api/chat 由服务端注入 key 并透传 SSE。
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

const PORT = Number(process.env.XJY_PORT || 3030);
const APP = path.join(process.env.HOME, 'xiaojingyu-app/app');
const CRED = path.join(process.env.HOME, '.credentials.yaml');

function apiKey() {
  // 优先环境变量（公开仓库里不依赖任何本机文件）；DSH 环境只是回退
  if (process.env.DEEPSEEK_API_KEY) return process.env.DEEPSEEK_API_KEY.trim();
  try {
    const t = fs.readFileSync(CRED, 'utf8');
    const m = t.match(/DEEPSEEK_API_KEY:\s*(\S+)/);
    return m ? m[1].trim() : '';
  } catch { return ''; }
}

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml' };

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://127.0.0.1');

  if (req.method === 'POST' && url.pathname === '/api/chat') {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', async () => {
      let payload;
      try { payload = JSON.parse(Buffer.concat(chunks).toString('utf8')); }
      catch { res.writeHead(400, { 'content-type': 'application/json' }); return res.end('{"error":"bad json"}'); }
      const provided = typeof payload.apiKey === 'string' ? payload.apiKey.trim() : '';
      delete payload.apiKey;
      const key = provided || apiKey();
      if (!key) { res.writeHead(500, { 'content-type': 'application/json' }); return res.end('{"error":"no api key"}'); }
      try {
        const up = await fetch('https://api.deepseek.com/chat/completions', {
          method: 'POST',
          headers: { authorization: 'Bearer ' + key, 'content-type': 'application/json' },
          body: JSON.stringify({ ...payload, stream: true }),
        });
        res.writeHead(up.status, {
          'content-type': up.headers.get('content-type') || 'text/event-stream',
          'cache-control': 'no-store',
          'x-accel-buffering': 'no',
        });
        if (!up.body) return res.end();
        const reader = up.body.getReader();
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          res.write(Buffer.from(value));
        }
        res.end();
      } catch (e) {
        if (!res.headersSent) res.writeHead(502, { 'content-type': 'application/json' });
        res.end(JSON.stringify({ error: String(e?.message || e) }));
      }
    });
    return;
  }

  // app 侧事件上报（只收事件元数据）
  if (url.pathname === '/diag') {
    if (req.method === 'OPTIONS') {
      res.writeHead(204, {
        'access-control-allow-origin': '*',
        'access-control-allow-methods': 'POST, OPTIONS',
        'access-control-allow-headers': 'content-type',
      });
      return res.end();
    }
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      const line = Buffer.concat(chunks).toString('utf8').trim();
      try { fs.appendFileSync(path.join(process.env.HOME, 'tmp/xjy-diag.jsonl'), line + '\n'); } catch {}
      console.log('[diag] ' + line.slice(0, 400));
      res.writeHead(204, { 'access-control-allow-origin': '*' });
      res.end();
    });
    return;
  }

  // 直接把安装包发给手机浏览器（比让用户翻文件管理省事）
  if (url.pathname === '/apk') {
    const apk = '/storage/emulated/0/Download/小鲸鱼.apk';
    if (!fs.existsSync(apk)) { res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' }); return res.end('APK 不在，先 bash build.sh'); }
    res.writeHead(200, {
      'content-type': 'application/vnd.android.package-archive',
      'content-length': fs.statSync(apk).size,
      'content-disposition': 'attachment; filename="xiaojingyu.apk"',
      'cache-control': 'no-store',
    });
    return fs.createReadStream(apk).pipe(res);
  }

  if (url.pathname === '/install' || url.pathname === '/install/') {
    const html = `<!doctype html><html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>安装小鲸鱼</title><style>
body{margin:0;background:#061423;color:#e9f2fb;font:16px/1.7 system-ui,sans-serif;display:flex;justify-content:center}
main{max-width:26rem;padding:2rem 1.2rem}
a.btn{display:block;text-align:center;padding:1rem;border-radius:14px;background:linear-gradient(180deg,#2a7bf0,#1f6feb);
 color:#fff;text-decoration:none;font-weight:700;font-size:1.1rem;box-shadow:0 8px 20px rgba(31,111,235,.4)}
ol{color:#c7cdd6;font-size:.95rem}code{background:#1b1f27;padding:.1rem .35rem;border-radius:5px}
p{color:#9aa4b2;font-size:.88rem}</style></head><body><main>
<h1 style="font-size:1.2rem">安装「小鲸鱼」</h1>
<a class="btn" href="/apk">⬇︎ 点这里下载安装包</a>
<ol>
<li>下载完，状态栏会弹"下载完成"通知 → <b>点它</b> → 安装</li>
<li>若提示"不允许安装未知来源" → 点<b>设置</b> → 允许该来源 → 返回继续</li>
<li>也可以去 文件管理 → 下载 → <code>小鲸鱼.apk</code></li>
<li>分享给朋友：直接把这个安装包发给他（里面不含任何 API Key，他自己填）</li>
</ol>
<p>包名 app.xiaojingyu.chat ｜ 只有联网权限<br><b>第一次打开会让你填自己的 DeepSeek API Key</b>（页面上有「去申请」按钮）</p>
</main></body></html>`;
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
    return res.end(html);
  }

  let p = url.pathname === '/' ? '/index.html' : url.pathname;
  p = path.normalize(p).replace(/^(\.\.[/\\])+/, '');
  const file = path.join(APP, p);
  if (!file.startsWith(APP) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    res.writeHead(404, { 'content-type': 'text/plain' }); return res.end('not found');
  }
  res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-store' });
  fs.createReadStream(file).pipe(res);
});

server.listen(PORT, '127.0.0.1', () => console.log('小鲸鱼预览 http://127.0.0.1:' + PORT + '/'));
