// 从清华 Termux 镜像按包名抓 .deb，校验 sha256 后存到 $HOME/debs
// 用法：node tools/fetch-debs.mjs openjdk-21 d8 libexpat libprotobuf
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import crypto from 'node:crypto';

const MIRROR = process.env.TERMUX_MIRROR || 'https://mirrors.tuna.tsinghua.edu.cn/termux/apt/termux-main';
const INDEX = MIRROR + '/dists/stable/main/binary-aarch64/Packages.gz';
const DEST = path.join(process.env.HOME, 'debs');
const ARCH = process.arch === 'x64' ? 'x86_64' : 'aarch64';

const want = process.argv.slice(2);
if (!want.length) { console.error('usage: fetch-debs.mjs <pkg>...'); process.exit(1); }

const idxUrl = INDEX.replace('aarch64', ARCH);
console.log('index:', idxUrl);
const res = await fetch(idxUrl);
if (!res.ok) { console.error('索引下载失败', res.status); process.exit(1); }
const raw = zlib.gunzipSync(Buffer.from(await res.arrayBuffer())).toString('utf8');

const stanzas = raw.split('\n\n').filter(Boolean).map((s) => {
  const o = {};
  for (const line of s.split('\n')) {
    const m = line.match(/^([A-Za-z0-9-]+):\s*(.*)$/);
    if (m) o[m[1]] = m[2];
  }
  return o;
});
console.log('索引条目:', stanzas.length);

fs.mkdirSync(DEST, { recursive: true });
for (const name of want) {
  const hits = stanzas.filter((s) => s.Package === name);
  if (!hits.length) { console.log('找不到包:', name); continue; }
  const best = hits.sort((a, b) => String(a.Version).localeCompare(String(b.Version), undefined, { numeric: true })).pop();
  const url = MIRROR + '/' + best.Filename;
  const out = path.join(DEST, path.basename(best.Filename));
  process.stdout.write(`下载 ${best.Package} ${best.Version} (${Math.round((+best.Size || 0) / 1048576)}MB) ... `);
  const r = await fetch(url);
  if (!r.ok) { console.log('失败', r.status); continue; }
  const buf = Buffer.from(await r.arrayBuffer());
  const sha = crypto.createHash('sha256').update(buf).digest('hex');
  if (best.SHA256 && sha !== best.SHA256) { console.log('校验失败！'); continue; }
  fs.writeFileSync(out, buf);
  console.log('ok ->', path.basename(out));
}
console.log('done');
