// 生成内置"小鲸鱼"表情包（400x400 透明 PNG）
// 用法：node tools/make-stickers.mjs
import fs from 'node:fs';
import path from 'node:path';
import { encodePng } from './png.mjs';

const S = 400;
const OUT = path.join(process.env.HOME, 'xiaojingyu-app/app/stickers');

const BODY = [122, 184, 232];
const BODY_D = [86, 150, 205];
const BELLY = [214, 236, 252];
const LINE = [38, 70, 110];
const BLUSH = [255, 150, 170];
const ACCENT = [255, 96, 120];

function canvas() { return new Uint8Array(S * S * 4); }

function set(px, x, y, c, a = 255) {
  if (x < 0 || y < 0 || x >= S || y >= S) return;
  const i = (y * S + x) * 4, na = a / 255, ia = px[i + 3] / 255, oa = na + ia * (1 - na);
  if (oa === 0) return;
  px[i] = Math.round((c[0] * na + px[i] * ia * (1 - na)) / oa);
  px[i + 1] = Math.round((c[1] * na + px[i + 1] * ia * (1 - na)) / oa);
  px[i + 2] = Math.round((c[2] * na + px[i + 2] * ia * (1 - na)) / oa);
  px[i + 3] = Math.round(oa * 255);
}

function ellipse(px, cx, cy, rx, ry, c, a = 255, ring = 0, ringC = LINE) {
  for (let y = Math.floor(cy - ry - ring - 1); y <= Math.ceil(cy + ry + ring + 1); y++) {
    for (let x = Math.floor(cx - rx - ring - 1); x <= Math.ceil(cx + rx + ring + 1); x++) {
      const d = ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2;
      const din = ((x - cx) / (rx - ring)) ** 2 + ((y - cy) / (ry - ring)) ** 2;
      if (ring > 0) { if (d <= 1 && din > 1) set(px, x, y, ringC, a); }
      else if (d <= 1) set(px, x, y, c, a);
    }
  }
}

function circle(px, cx, cy, r, c, a = 255) { ellipse(px, cx, cy, r, r, c, a); }

function arc(px, cx, cy, r, from, to, c, thick = 7, a = 255) {
  for (let t = from; t <= to; t += 0.01) {
    for (let w = -thick / 2; w <= thick / 2; w += 0.5) {
      set(px, Math.round(cx + Math.cos(t) * (r + w)), Math.round(cy + Math.sin(t) * (r + w)), c, a);
    }
  }
}

function line(px, x1, y1, x2, y2, c, thick = 7, a = 255) {
  const steps = Math.max(Math.abs(x2 - x1), Math.abs(y2 - y1)) * 2;
  for (let i = 0; i <= steps; i++) {
    const x = x1 + ((x2 - x1) * i) / steps, y = y1 + ((y2 - y1) * i) / steps;
    circle(px, Math.round(x), Math.round(y), thick / 2, c, a);
  }
}

/** 基础头型（带轮廓 + 肚子 + 小尾巴） */
function head(px, tilt = 0) {
  const cx = 200, cy = 214 + tilt;
  // 尾巴
  ellipse(px, 322, cy + 6, 60, 26, BODY_D, 255);
  ellipse(px, 352, cy - 26, 30, 40, BODY_D, 255);
  ellipse(px, 352, cy + 40, 30, 40, BODY_D, 255);
  // 头
  ellipse(px, cx, cy, 132, 118, BODY, 255, 9, LINE);
  // 肚子
  ellipse(px, cx - 6, cy + 34, 92, 66, BELLY, 255);
  // 头顶小水柱
  circle(px, 176, 74, 13, BELLY, 235);
  circle(px, 200, 58, 16, BELLY, 235);
  circle(px, 224, 74, 11, BELLY, 235);
  return { cx, cy };
}

const EYES = {
  open: (px, cx, cy) => { circle(px, cx - 46, cy - 8, 15, LINE); circle(px, cx + 46, cy - 8, 15, LINE);
    circle(px, cx - 50, cy - 13, 5, [255, 255, 255]); circle(px, cx + 42, cy - 13, 5, [255, 255, 255]); },
  happy: (px, cx, cy) => { arc(px, cx - 46, cy - 4, 17, Math.PI * 1.15, Math.PI * 1.85, LINE, 8);
    arc(px, cx + 46, cy - 4, 17, Math.PI * 1.15, Math.PI * 1.85, LINE, 8); },
  wink: (px, cx, cy) => { circle(px, cx - 46, cy - 8, 15, LINE);
    arc(px, cx + 46, cy - 4, 17, Math.PI * 1.15, Math.PI * 1.85, LINE, 8); },
  wide: (px, cx, cy) => { ellipse(px, cx - 46, cy - 8, 20, 23, [255, 255, 255], 255, 7, LINE);
    ellipse(px, cx + 46, cy - 8, 20, 23, [255, 255, 255], 255, 7, LINE);
    circle(px, cx - 46, cy - 4, 9, LINE); circle(px, cx + 46, cy - 4, 9, LINE); },
  sad: (px, cx, cy) => { arc(px, cx - 46, cy - 14, 16, Math.PI * 0.15, Math.PI * 0.85, LINE, 8);
    arc(px, cx + 46, cy - 14, 16, Math.PI * 0.15, Math.PI * 0.85, LINE, 8); },
  closed: (px, cx, cy) => { line(px, cx - 62, cy - 8, cx - 30, cy - 8, LINE, 8);
    line(px, cx + 30, cy - 8, cx + 62, cy - 8, LINE, 8); },
  angry: (px, cx, cy) => { circle(px, cx - 46, cy - 4, 14, LINE); circle(px, cx + 46, cy - 4, 14, LINE);
    line(px, cx - 70, cy - 34, cx - 30, cy - 22, LINE, 8); line(px, cx + 30, cy - 22, cx + 70, cy - 34, LINE, 8); },
  heart: (px, cx, cy) => { for (const dx of [-46, 46]) { heart(px, cx + dx, cy - 6, 20, ACCENT); } },
  dizzy: (px, cx, cy) => { for (const dx of [-46, 46]) {
    line(px, cx + dx - 14, cy - 22, cx + dx + 14, cy + 6, LINE, 7);
    line(px, cx + dx + 14, cy - 22, cx + dx - 14, cy + 6, LINE, 7); } },
};

const MOUTHS = {
  smile: (px, cx, cy) => arc(px, cx, cy + 30, 34, Math.PI * 0.12, Math.PI * 0.88, LINE, 7),
  big: (px, cx, cy) => { ellipse(px, cx, cy + 44, 34, 26, [120, 60, 70]); ellipse(px, cx, cy + 56, 22, 12, [230, 130, 140]); },
  small: (px, cx, cy) => arc(px, cx, cy + 30, 20, Math.PI * 0.15, Math.PI * 0.85, LINE, 7),
  flat: (px, cx, cy) => line(px, cx - 22, cy + 38, cx + 22, cy + 38, LINE, 7),
  wave: (px, cx, cy) => { arc(px, cx - 16, cy + 36, 16, 0, Math.PI, LINE, 6); arc(px, cx + 16, cy + 36, 16, Math.PI, Math.PI * 2, LINE, 6); },
  o: (px, cx, cy) => ellipse(px, cx, cy + 44, 16, 20, [120, 60, 70]),
};

function blush(px, cx, cy) { circle(px, cx - 88, cy + 24, 17, BLUSH, 120); circle(px, cx + 88, cy + 24, 17, BLUSH, 120); }
function tears(px, cx, cy) { ellipse(px, cx - 52, cy + 40, 12, 22, [120, 200, 255], 220); ellipse(px, cx + 52, cy + 60, 12, 22, [120, 200, 255], 220); }
function sweat(px, cx, cy) { ellipse(px, cx + 96, cy - 66, 16, 24, [130, 210, 255], 235); }
function anger(px, cx, cy) {
  for (const [x, y] of [[300, 96], [322, 118]]) {
    line(px, x - 16, y, x + 16, y, [235, 70, 70], 8);
    line(px, x, y - 16, x, y + 16, [235, 70, 70], 8);
  }
}
function heart(px, cx, cy, r, c) {
  circle(px, cx - r / 2, cy - r / 3, r * 0.55, c);
  circle(px, cx + r / 2, cy - r / 3, r * 0.55, c);
  for (let y = 0; y < r * 1.3; y++) {
    const w = r * 1.1 * (1 - y / (r * 1.3));
    line(px, cx - w, cy + y - r * 0.1, cx + w, cy + y - r * 0.1, c, 1);
  }
}
function sparkles(px, cx, cy) {
  for (const [x, y, s] of [[72, 96, 22], [330, 150, 16], [96, 300, 14]]) {
    line(px, x - s, y, x + s, y, [255, 214, 92], 6);
    line(px, x, y - s, x, y + s, [255, 214, 92], 6);
  }
}
function zzz(px, cx, cy) {
  const z = (x, y, s) => { line(px, x, y, x + s, y, LINE, 6); line(px, x + s, y, x, y + s, LINE, 6); line(px, x, y + s, x + s, y + s, LINE, 6); };
  z(288, 78, 20); z(316, 46, 26); z(350, 12, 32);
}
function question(px, cx, cy) {
  arc(px, 300, 84, 22, Math.PI * 0.9, Math.PI * 2.1, LINE, 9);
  line(px, 300, 106, 300, 122, LINE, 9);
  circle(px, 300, 142, 6, LINE);
}
function dots(px, cx, cy) { for (const dx of [-24, 0, 24]) circle(px, cx + 118 + dx, cy - 60, 7, LINE); }

const RECIPES = [
  ['happy', 'happy', 'smile', [blush]],
  ['laugh', 'happy', 'big', [blush, (p, c) => sparkles(p, c)]],
  ['smile', 'open', 'small', [blush]],
  ['wink', 'wink', 'smile', []],
  ['love', 'heart', 'small', [blush, (p, c) => heart(p, 316, 90, 22, ACCENT)]],
  ['shy', 'closed', 'small', [blush, (p, c) => { blush(p, c); }]],
  ['cry', 'sad', 'wave', [tears]],
  ['angry', 'angry', 'wave', [anger]],
  ['confused', 'open', 'flat', [question]],
  ['sleepy', 'closed', 'o', [zzz]],
  ['wow', 'wide', 'big', [sparkles]],
  ['speechless', 'closed', 'flat', [dots]],
  ['sweat', 'open', 'smile', [sweat]],
  ['dizzy', 'dizzy', 'wave', []],
  ['plead', 'wide', 'small', [blush, sparkles]],
  ['cool', 'wink', 'smile', [(p, c) => sparkles(p, c)]],
];

fs.mkdirSync(OUT, { recursive: true });
const names = [];
for (const [name, eye, mouth, decos] of RECIPES) {
  const px = canvas();
  const { cx, cy } = head(px);
  EYES[eye](px, cx, cy);
  MOUTHS[mouth](px, cx, cy);
  for (const d of decos) d(px, cx, cy);
  const file = path.join(OUT, 'builtin-' + name + '.png');
  fs.writeFileSync(file, encodePng(px, S, S));
  names.push(name);
}
console.log('生成 ' + names.length + ' 张表情：' + names.join(' '));
console.log('输出目录：' + OUT);
