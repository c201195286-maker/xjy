// 极简 PNG 编码器（RGBA → PNG）
import zlib from 'node:zlib';

const crcTable = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c; }
  return t;
})();
const crc32 = (buf) => { let c = -1; for (const b of buf) c = crcTable[(c ^ b) & 0xFF] ^ (c >>> 8); return (c ^ -1) >>> 0; };
const chunk = (type, data) => {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
};

/** @param {Uint8Array} rgba 长度 w*h*4 */
export function encodePng(rgba, w, h) {
  const raw = Buffer.alloc(h * (w * 4 + 1));
  for (let y = 0; y < h; y++) {
    raw[y * (w * 4 + 1)] = 0;
    Buffer.from(rgba.buffer, rgba.byteOffset + y * w * 4, w * 4).copy(raw, y * (w * 4 + 1) + 1);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

/** 从 RGBA 源裁剪 + 缩放到目标尺寸（盒式平均，缩小时不糊） */
export function cropResize(src, sw, sh, cx, cy, side, out) {
  const dst = new Uint8Array(out * out * 4);
  const x0 = cx - side / 2, y0 = cy - side / 2;
  const scale = side / out;
  for (let y = 0; y < out; y++) {
    for (let x = 0; x < out; x++) {
      let r = 0, g = 0, b = 0, a = 0, n = 0;
      const sx0 = Math.floor(x0 + x * scale), sx1 = Math.max(sx0 + 1, Math.floor(x0 + (x + 1) * scale));
      const sy0 = Math.floor(y0 + y * scale), sy1 = Math.max(sy0 + 1, Math.floor(y0 + (y + 1) * scale));
      for (let sy = sy0; sy < sy1; sy++) {
        if (sy < 0 || sy >= sh) continue;
        for (let sx = sx0; sx < sx1; sx++) {
          if (sx < 0 || sx >= sw) continue;
          const i = (sy * sw + sx) * 4;
          const al = src[i + 3] / 255;
          r += src[i] * al; g += src[i + 1] * al; b += src[i + 2] * al; a += al; n++;
        }
      }
      const o = (y * out + x) * 4;
      if (n === 0 || a === 0) { dst[o] = dst[o + 1] = dst[o + 2] = 0; dst[o + 3] = 0; continue; }
      dst[o] = Math.round(r / a); dst[o + 1] = Math.round(g / a); dst[o + 2] = Math.round(b / a);
      dst[o + 3] = Math.round((a / n) * 255);
    }
  }
  return dst;
}
