// 生成 Keys.java —— 永远不内置任何 API Key（统一版本：谁用谁在设置里自己填）
import fs from 'node:fs';
import path from 'node:path';

const out = process.argv[2];
if (!out) { console.error('usage: gen-keys.mjs <out Keys.java>'); process.exit(1); }

fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, `package app.xiaojingyu.chat;

/**
 * 本应用不内置任何 API Key：用户在设置里填自己的（只存本机 SharedPreferences）。
 * 这里永远是空串 —— 想改成"自带 key 的私用构建"请自行改代码，但公开分发的包绝不要这么做。
 */
public final class Keys {
    public static final String API_KEY = "";
    private Keys() { }
}
`);
console.log('Keys.java 已生成：不内置 API Key（用户在设置里自己填）');
