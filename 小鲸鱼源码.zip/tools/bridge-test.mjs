// 静态一致性检查：JS 里调用的每个 Android.xxx 方法，Java 的 Bridge 内部类里都真的暴露了吗？
// （真机 bug 复盘：listStickers / listNotes / httpGet 都曾因为写在 Bridge 外面而静默失效，
//   jsdom 测试永远发现不了，因为它们用的是 mock。）
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const javaFile = path.join(root, 'android/src/app/xiaojingyu/chat/MainActivity.java');
const jsFile = path.join(root, 'app/app.js');

const java = fs.readFileSync(javaFile, 'utf8').split('\n');
const js = fs.readFileSync(jsFile, 'utf8');

let failed = 0;
const check = (name, ok, extra = '') => {
  console.log((ok ? '  ✓ ' : '  ✗ ') + name + (extra ? ' — ' + extra : ''));
  if (!ok) failed++;
};

// 1) Bridge 内部类的行范围
const startIdx = java.findIndex((l) => /private class Bridge/.test(l));
let endIdx = java.length;
for (let i = startIdx + 1; i < java.length; i++) {
  if (/^    \}$/.test(java[i])) { endIdx = i; break; }
}
check('找到 Bridge 内部类', startIdx >= 0 && endIdx > startIdx, `第 ${startIdx + 1}~${endIdx + 1} 行`);

// 2) 收集 @JavascriptInterface 方法，并按位置分类
const exposed = [], misplaced = [];
java.forEach((line, i) => {
  if (!/@JavascriptInterface/.test(line)) return;
  for (let j = i + 1; j < Math.min(i + 8, java.length); j++) {
    const m = java[j].match(/public\s+[\w<>\[\]]+\s+(\w+)\s*\(/);
    if (m) {
      const inside = i > startIdx && i < endIdx;
      (inside ? exposed : misplaced).push({ name: m[1], line: i + 1 });
      return;
    }
  }
});

check('没有"标了接口但写在 Bridge 外面"的方法（JS 看不到的那种）', misplaced.length === 0,
  misplaced.map((x) => `${x.name}@${x.line}`).join(', '));
check('暴露的方法数 >= 20', exposed.length >= 20, exposed.length + ' 个');

// 3) JS 调用的每个方法都必须在暴露列表里
const called = [...new Set([...js.matchAll(/Android\.(\w+)\s*\(/g)].map((m) => m[1]))];
const exposedNames = new Set(exposed.map((e) => e.name));
const missing = called.filter((c) => !exposedNames.has(c));
check('JS 调用的桥方法全部已暴露', missing.length === 0, missing.length ? '缺: ' + missing.join(', ') : called.length + ' 个调用全部匹配');

// 4) JS 里对 Android 的方法做能力判断时用的名字也一致（typeof Android.x === 'function'）
const guarded = [...new Set([...js.matchAll(/typeof\s+(?:window\.)?Android\.(\w+)\s*===?\s*['"]function['"]/g)].map((m) => m[1]))];
const badGuard = guarded.filter((g) => !exposedNames.has(g));
check('能力判断里的方法名也都存在', badGuard.length === 0, badGuard.join(', ') || guarded.length + ' 处判断');

// 5) JS 里的回调函数名跟 Java 里 runJs 调的名字对得上（防止改名后对不上）
const jsCallbacks = [...new Set([...js.matchAll(/window\.(__on\w+)\s*=/g)].map((m) => m[1]))];
const javaCalled = [...new Set([...fs.readFileSync(javaFile, 'utf8').matchAll(/window\.(__on\w+)\s*\(/g)].map((m) => m[1]))];
const orphan = javaCalled.filter((c) => !jsCallbacks.includes(c));
check('Java 回调的每个 window.__onXxx 在 JS 里都有实现', orphan.length === 0, orphan.length ? 'Java 调了但 JS 没有: ' + orphan.join(', ') : jsCallbacks.length + ' 个回调');

console.log(failed === 0 ? '\n桥接口一致性：全部通过 ✅' : `\n桥接口一致性：${failed} 项失败 ❌`);
process.exit(failed === 0 ? 0 : 1);
