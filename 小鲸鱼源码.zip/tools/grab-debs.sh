#!/usr/bin/env bash
# 盯着 app 的扩展下载缓存，把出现的 .deb 拷到 $HOME/debs/（安装器回滚删缓存也不怕）
SRC=/data/user/0/app.dsh.mobile/cache
DST="$HOME/debs"
mkdir -p "$DST"
for i in $(seq 1 600); do
  find "$SRC" -maxdepth 2 -name "*.deb" 2>/dev/null | while read -r f; do
    b="$(basename "$f")"
    [ -s "$DST/$b" ] || cp -n "$f" "$DST/$b" 2>/dev/null
  done
  sleep 2
done
