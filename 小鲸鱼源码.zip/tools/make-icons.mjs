// 把小鲸鱼原图（webp）切成：桌面图标各分辨率 + 聊天页头像
// 用法：node tools/make-icons.mjs <源图> [--crop cxRatio cyRatio sideRatio]
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { encodePng, cropResize } from './png.mjs';

// jsquash 用 fetch() 加载自己的 .wasm；Node 里 file:// 不被 fetch 支持，这里补一个
const realFetch = globalThis.fetch;
globalThis.fetch = async (url, opts) => {
  const s = typeof url === 'string' ? url : (url && url.url) || String(url);
  if (s.startsWith('file:')) {
    const p = fileURLToPath(s.split('#')[0].split('?')[0]);
    return new Response(fs.readFileSync(p), { headers: { 'content-type': 'application/wasm' } });
  }
  return realFetch(url, opts);
};
const { decode } = await import('@jsquash/webp');

const ROOT = path.join(process.env.HOME, 'xiaojingyu-app');
const src = process.argv[2];
if (!src) { console.error('usage: make-icons.mjs <image>'); process.exit(1); }

// 裁剪参数（相对原图）：默认取"帽子+脸+上身"
let cxR = 0.50, cyR = 0.46, sideR = 0.63;
const ci = process.argv.indexOf('--crop');
if (ci > 0 && process.argv[ci + 1]) {
  const [a, b, c] = process.argv[ci + 1].split(',').map(Number);
  if ([a, b, c].every((n) => !Number.isNaN(n))) { cxR = a; cyR = b; sideR = c; }
}

const buf = fs.readFileSync(src);
const img = await decode(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength));
const { data, width, height } = img;
console.log('source:', width + 'x' + height);

const cx = width * cxR, cy = height * cyR, side = Math.min(width, height) * sideR;

const sizes = [[48, 'mipmap-mdpi'], [72, 'mipmap-hdpi'], [96, 'mipmap-xhdpi'], [144, 'mipmap-xxhdpi'], [192, 'mipmap-xxxhdpi']];
for (const [s, dir] of sizes) {
  const out = cropResize(new Uint8Array(data.buffer || data), width, height, cx, cy, side, s);
  const file = path.join(ROOT, 'android/res', dir, 'icon.png');
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, encodePng(out, s, s));
  console.log('icon', s + 'px ->', path.relative(ROOT, file));
}

// 聊天页头像（脸更近一点）+ 大图（设置页/分享用）
const faceOut = cropResize(new Uint8Array(data.buffer || data), width, height, width * 0.5, height * 0.50, Math.min(width, height) * 0.40, 256);
fs.mkdirSync(path.join(ROOT, 'app'), { recursive: true });
fs.writeFileSync(path.join(ROOT, 'app/avatar.png'), encodePng(faceOut, 256, 256));
console.log('avatar -> app/avatar.png');

const fullOut = cropResize(new Uint8Array(data.buffer || data), width, height, width * 0.5, height * 0.50, Math.min(width, height) * 0.95, 512);
fs.writeFileSync(path.join(ROOT, 'app/portrait.png'), encodePng(fullOut, 512, 512));
console.log('portrait -> app/portrait.png');
