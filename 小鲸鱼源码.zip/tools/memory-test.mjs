// 长期记忆测试：预置 60 条历史 → 发一句 → 应触发压缩 → 下一轮请求里应带上"往事"
import fs from 'node:fs';
import path from 'node:path';
import { JSDOM } from 'jsdom';

const APP = path.join(process.env.HOME, 'xiaojingyu-app/app');
const html = fs.readFileSync(path.join(APP, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(APP, 'app.js'), 'utf8');

const dom = new JSDOM(html, { runScripts: 'outside-only', pretendToBeVisual: true, url: 'https://xjy.local/' });
const { window } = dom;
window.__XJY_NO_SELFTEST = true;

// 预置历史：60 条（30 轮），超过 24 轮窗口
const seed = [];
for (let i = 0; i < 60; i++) {
  seed.push({ role: 'user', content: '第' + (i + 1) + '轮：我叫小明，喜欢鲸鱼', t: Date.now() });
  seed.push({ role: 'assistant', content: '第' + (i + 1) + '轮：记住啦', t: Date.now() });
}
const store = new Map([
  ['xjy.history', JSON.stringify(seed)],
  ['xjy.config', JSON.stringify({ contextTurns: 24, persona: '你是小鲸鱼', apiKey: 'sk-test1234567890' })],
]);

let summarizerCalls = 0, chatCalls = 0, lastMessages = null;
const addedNotes = [];
window.Android = {
  hasBuiltinKey: () => false,
  addNote: (text) => { addedNotes.push(text); return JSON.stringify(addedNotes.map((x, i) => ({ t: i, text: x }))); },
  kvGet: (k) => (store.has(k) ? store.get(k) : ''),
  kvSet: (k, v) => store.set(k, v),
  startChat: (json) => {
    const req = JSON.parse(json);
    lastMessages = req.messages;
    const isSummary = String(req.messages[0].content).includes('维护');
    if (isSummary) {
      summarizerCalls++;
      setTimeout(() => window.__onDone('【往事】\n他叫小明，喜欢鲸鱼；已经聊了60轮。\n【笔记】\n- 他叫小明\n- 他喜欢鲸鱼\n- 无'), 5);
    } else { chatCalls++; setTimeout(() => window.__onDone('在的'), 5); }
  },
  speak: () => {},
  stop: () => {},
};

let failed = 0;
const check = (name, cond, extra = '') => { console.log((cond ? '  ✓ ' : '  ✗ ') + name + (extra ? ' — ' + extra : '')); if (!cond) failed++; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

window.eval(js);
await sleep(50);

const $ = (s) => window.document.querySelector(s);

console.log('1) 启动时加载了历史');
check("页面渲染出历史消息", window.document.querySelectorAll(".bub").length > 10, window.document.querySelectorAll('.bub').length + ' 条');

console.log('2) 发一句 → 应触发记忆压缩');
$('#input').value = '还记得我叫什么吗';
$('#send').dispatchEvent(new window.Event('click'));
await sleep(900);   // finish() 之后还有 300ms 才触发压缩，要给足时间
check('聊天请求发出', chatCalls >= 1, 'chatCalls=' + chatCalls);
check('自动触发了压缩请求', summarizerCalls >= 1, 'summarizerCalls=' + summarizerCalls);
const mem = JSON.parse(store.get('xjy.memory') || '{}');
check('记忆已写入存储', !!mem.summary, JSON.stringify(mem).slice(0, 80));
check('记忆里保留了关键事实', String(mem.summary).includes('小明'), String(mem.summary).slice(0, 60));
check('往事里没有混进【笔记】段', !String(mem.summary).includes('【笔记】'), String(mem.summary).slice(-26));
check('顺手抽出了 2 条笔记', addedNotes.length === 2, JSON.stringify(addedNotes));
check('笔记内容是原子事实', addedNotes.includes('他叫小明') && addedNotes.includes('他喜欢鲸鱼'), JSON.stringify(addedNotes));
check('「无」不会被当成笔记', !addedNotes.includes('无'));

console.log('3) 下一轮请求要带上"往事"');
$('#input').value = '那你说说我叫什么';
$('#send').dispatchEvent(new window.Event('click'));
await sleep(400);
const sys = String(lastMessages?.[0]?.content || '');
check('system 里带上了往事段', sys.includes('你记得的往事'), sys.slice(-60));
check('往事内容是小明那条', sys.includes('小明'));
check('仍然是 system + 最近窗口 + 新消息', lastMessages[0].role === 'system' && lastMessages[lastMessages.length - 1].content === '那你说说我叫什么');
check('窗口被裁剪过（没把 60 条全发）', lastMessages.length < 55, lastMessages.length + ' 条');

console.log(failed === 0 ? '\n长期记忆：全部通过 ✅' : `\n${failed} 项失败 ❌`);
process.exit(failed === 0 ? 0 : 1);
