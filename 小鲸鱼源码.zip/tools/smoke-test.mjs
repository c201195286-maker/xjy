// 冒烟测试：在 jsdom 里跑真实 app.js，模拟 WebView + 安卓桥
// 用法：node tools/smoke-test.mjs
import fs from 'node:fs';
import path from 'node:path';
import { JSDOM } from 'jsdom';

const APP = path.join(process.env.HOME, 'xiaojingyu-app/app');
const html = fs.readFileSync(path.join(APP, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(APP, 'app.js'), 'utf8');

let failed = 0;
const check = (name, cond, extra = '') => {
  console.log((cond ? '  ✓ ' : '  ✗ ') + name + (extra ? ' — ' + extra : ''));
  if (!cond) failed++;
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* ============ 第 1 部分：已有 key（用户自己填过） ============ */
console.log('1) 首次渲染');
const dom = new JSDOM(html, { runScripts: 'outside-only', pretendToBeVisual: true, url: 'https://xjy.local/' });
const { window } = dom;
window.__XJY_NO_SELFTEST = true;

const calls = { kvSet: [], startChat: [], speak: [] };
const openedUrls = [];
const store = new Map([['xjy.config', JSON.stringify({ apiKey: 'sk-test1234567890' })]]);
window.Android = {
  hasBuiltinKey: () => false,          // 分享版：没有内置 key
  openUrl: (u) => { openedUrls.push(u); },
  kvGet: (k) => (store.has(k) ? store.get(k) : ''),
  kvSet: (k, v) => { calls.kvSet.push(k); store.set(k, v); },
  startChat: (json) => {
    calls.startChat.push(JSON.parse(json));
    setTimeout(() => window.__onDelta('在'), 0);
    setTimeout(() => window.__onDelta('的'), 5);
    setTimeout(() => window.__onDone('在的'), 10);
  },
  speak: (t) => calls.speak.push(t),
  stop: () => {},
};

window.eval(js);
await sleep(40);
const $ = (s) => window.document.querySelector(s);
const log = $('#log');

check('页面有问候气泡', log.textContent.includes('你终于来啦'));
check('头像用的是图片', $('#bar img') !== null);
check('有 key 时不会自动弹设置', !$('#sheet').classList.contains('open'));

console.log('2) 发一条消息（走安卓桥）');
$('#input').value = '在吗';
$('#send').dispatchEvent(new window.Event('click'));
await sleep(5);
check('出现用户气泡', log.textContent.includes('在吗'));
check('状态变成正在输入', $('#status').textContent.includes('正在输入'), $('#status').textContent);
await sleep(60);
check('助手气泡显示完整回复', log.textContent.includes('在的'));
check('请求带上了人设与 model', calls.startChat.length === 1 && calls.startChat[0].messages[0].role === 'system' && !!calls.startChat[0].model, String(calls.startChat[0]?.model));
check('上下文里包含刚才那句', JSON.stringify(calls.startChat[0]?.messages).includes('在吗'));
const msgs0 = calls.startChat[0]?.messages || [];
const dup = msgs0.filter((m) => m.content === '在吗').length;
check('你说的话只发了一次（不再出现两遍）', dup === 1, '在请求里出现 ' + dup + ' 次');
check('最后一条就是刚发的那句', msgs0[msgs0.length - 1]?.content === '在吗');
check('历史写进了原生存储（按角色分开存）', calls.kvSet.some((k) => k.startsWith('xjy.hist.')), JSON.stringify(calls.kvSet.filter((k) => k.startsWith('xjy.hist'))));
check('结束后状态回到在线', $('#status').textContent.includes('在线'), $('#status').textContent);

console.log('3) 设置面板开合（踩过的坑：CSS display:flex 会盖掉 hidden）');
check('一开始面板是关的', $('#sheet').hidden === true && !$('#sheet').classList.contains('open'));
$('#gear').dispatchEvent(new window.Event('click'));
check('点齿轮后面板打开', $('#sheet').hidden === false && $('#sheet').classList.contains('open'));
check('人设框有默认内容', $('#s-persona').value.includes('小鲸鱼'), $('#s-persona').value.length + ' 字');
check('历史条数默认 24', $('#s-ctx').value === '24', $('#s-ctx').value);
check('key 回填正确', $('#s-key').value === 'sk-test1234567890');

console.log('4) 保存设置');
$('#s-persona').value = '你是测试人设';
$('#s-model').value = 'deepseek-chat';
$('#s-key').value = 'sk-test1234567890';
$('#s-save').dispatchEvent(new window.Event('click'));
check('保存后面板关闭（class 也移除）', $('#sheet').hidden === true && !$('#sheet').classList.contains('open'));
const savedCfg = JSON.parse(store.get('xjy.config') || '{}');
check('人设已保存到当前角色', savedCfg.chars?.jingyu?.persona === '你是测试人设', JSON.stringify(savedCfg.chars));
check('自定义 key 已保存', savedCfg.apiKey === 'sk-test1234567890');
check('model 已保存', savedCfg.model === 'deepseek-chat');

console.log('5) key 会随请求发送 + 测试连接');
$('#input').value = '再问一次';
$('#send').dispatchEvent(new window.Event('click'));
await sleep(20);
check('请求里带上了 key', calls.startChat.at(-1)?.apiKey === 'sk-test1234567890', String(calls.startChat.at(-1)?.apiKey));
await sleep(40);
$('#gear').dispatchEvent(new window.Event('click'));
$('#s-test').dispatchEvent(new window.Event('click'));
await sleep(60);
check('测试连接显示通了', $('#s-hint').textContent.includes('通了'), $('#s-hint').textContent);

console.log('6) 返回键');
check('__onBack 面板开着返回 true', window.__onBack() === true);
check('__onBack 面板关了返回 false', window.__onBack() === false);

/* ============ 第 2 部分：没填 key（分享版首次使用） ============ */
console.log('7) 没填 key 时（分享版首次使用）');
const dom2 = new JSDOM(html, { runScripts: 'outside-only', pretendToBeVisual: true, url: 'https://xjy.local/' });
const w2 = dom2.window;
w2.__XJY_NO_SELFTEST = true;
const store2 = new Map();
let sent2 = 0;
const urls2 = [];
w2.Android = {
  hasBuiltinKey: () => false,
  openUrl: (u) => urls2.push(u),
  kvGet: (k) => (store2.has(k) ? store2.get(k) : ''),
  kvSet: (k, v) => store2.set(k, v),
  startChat: () => { sent2++; },
  speak: () => {}, stop: () => {},
};
w2.eval(js);
await sleep(900);            // 等自动弹设置（600ms）
const q = (s) => w2.document.querySelector(s);
check('自动弹出了设置页', q('#sheet').classList.contains('open'));
check('提示语引导填 key', q('#s-hint').textContent.includes('API Key'), q('#s-hint').textContent.slice(0, 46));
q('#input').value = '在吗';
q('#send').dispatchEvent(new w2.Event('click'));
await sleep(80);
check('没 key 时不发请求', sent2 === 0, 'sent=' + sent2);
const bubbles = [...w2.document.querySelectorAll('.bub')].map((b) => b.textContent);
check('她回中文提示而不是 401', bubbles.some((x) => x.includes('还没有钥匙')), JSON.stringify(bubbles.slice(-1)));
q('#s-getkey').dispatchEvent(new w2.Event('click'));
check('申请 key 按钮调起浏览器', urls2.length === 1 && urls2[0].includes('deepseek'), JSON.stringify(urls2));

/* ============ 第 3 部分：图片 / 文件附件 ============ */
console.log('8) 发图片（视觉）与文本文件');
const dom3 = new JSDOM(html, { runScripts: 'outside-only', pretendToBeVisual: true, url: 'https://xjy.local/' });
const w3 = dom3.window;
w3.__XJY_NO_SELFTEST = true;
const store3 = new Map([['xjy.config', JSON.stringify({ apiKey: 'sk-test1234567890' })]]);
const sent3 = [];
let pickedImage = 0, pickedFile = 0;
w3.Android = {
  hasBuiltinKey: () => false,
  openUrl: () => {},
  pickImage: () => { pickedImage++; },
  pickFile: () => { pickedFile++; },
  readAsDataUrl: (p, id) => w3.__onDataUrl(id, 'data:image/jpeg;base64,QUJD'),
  kvGet: (k) => (store3.has(k) ? store3.get(k) : ''),
  kvSet: (k, v) => store3.set(k, v),
  startChat: (json) => { sent3.push(JSON.parse(json)); setTimeout(() => w3.__onDone('看到啦'), 5); },
  speak: () => {}, stop: () => {},
};
w3.eval(js);
await sleep(50);
const q3 = (s) => w3.document.querySelector(s);

// 点一下图片按钮，确认真的去调了原生选择器
q3('#pick-img').dispatchEvent(new w3.Event('click'));
check('点图片按钮会调原生选择器', pickedImage === 1, 'pickedImage=' + pickedImage);
q3('#pick-file').dispatchEvent(new w3.Event('click'));
check('点文件按钮会调原生选择器', pickedFile === 1, 'pickedFile=' + pickedFile);

// 模拟选了一张图
w3.__onAttachment(JSON.stringify({ kind: 'image', path: '/data/user/0/app.xiaojingyu.chat/files/img/a.jpg', name: 'a.jpg', bytes: 120000, w: 1280, h: 960, dataUrl: 'data:image/jpeg;base64,QUJD' }));
check('附件条显示出来了', q3('#attach').hidden === false);
check('附件条里有缩略图', q3('#attach-thumb').getAttribute('src').startsWith('data:image'));
check('附件说明写了尺寸', q3('#attach-meta').textContent.includes('1280'), q3('#attach-meta').textContent);

q3('#input').value = '看看这张图';
q3('#send').dispatchEvent(new w3.Event('click'));
await sleep(80);
const last3 = sent3.at(-1)?.messages?.at(-1);
check('请求里最后一条是数组（多模态）', Array.isArray(last3?.content), JSON.stringify(last3?.content)?.slice(0, 60));
check('数组里有 image_url', JSON.stringify(last3?.content || []).includes('image_url'));
check('图片以 data URL 传过去', JSON.stringify(last3?.content || []).includes('data:image/jpeg;base64'));
check('文字和图片在同一个消息里', (last3?.content || []).some((x) => x.type === 'text' && x.text === '看看这张图'));
check('发送后附件条自动收起', q3('#attach').hidden === true);
check('聊天记录里气泡有图片', [...w3.document.querySelectorAll('.bub img.shot')].length === 1);

// 模拟选了一张 GIF 动图：app 里显示动图，给模型的是首帧静态图
w3.__onAttachment(JSON.stringify({ kind: 'image', path: '/data/user/0/app.xiaojingyu.chat/files/img/a.gif', name: 'a.gif', bytes: 300000, gif: true, dataUrl: 'data:image/png;base64,U1RBVElD' }));
check('动图附件条会说明「动图」', q3('#attach-meta').textContent.includes('动图'), q3('#attach-meta').textContent);
q3('#input').value = '';
q3('#send').dispatchEvent(new w3.Event('click'));
await sleep(80);
const gifMsg = JSON.stringify(sent3.at(-1)?.messages?.at(-1)?.content || []);
check('动图发给模型的是静态首帧（PNG）', gifMsg.includes('data:image/png') && gifMsg.includes('U1RBVElD'), gifMsg.slice(0, 110));
check('气泡里用的是本地 GIF（会动）', [...w3.document.querySelectorAll('.bub img.shot')].some((im) => im.getAttribute('src').endsWith('.gif')));

// 模拟选了一个文本文件
w3.__onAttachment(JSON.stringify({ kind: 'text', name: 'note.txt', chars: 12, text: '你好，这是文件内容' }));
check('文本附件不显示缩略图', q3('#attach-thumb').hidden === true);
check('文本附件说明写了字数', q3('#attach-meta').textContent.includes('12'), q3('#attach-meta').textContent);
q3('#input').value = '看看这个文件';
q3('#send').dispatchEvent(new w3.Event('click'));
await sleep(80);
const txtMsg = String(sent3.at(-1)?.messages?.at(-1)?.content || '');
check('文件内容被当文字发过去', txtMsg.includes('你好，这是文件内容') && txtMsg.includes('note.txt'), txtMsg.slice(0, 60));

// 附件读取失败时的提示
w3.__onAttachmentError('这个文件是二进制格式');
check('读不了的文件会给系统提示', [...w3.document.querySelectorAll('.sys')].some((x) => x.textContent.includes('二进制')));

/* ============ 第 4 部分：表情面板 / 我的表情包 ============ */
console.log('9) 表情面板与贴纸');
const dom4 = new JSDOM(html, { runScripts: 'outside-only', pretendToBeVisual: true, url: 'https://xjy.local/' });
const w4 = dom4.window;
w4.__XJY_NO_SELFTEST = true;
const store4 = new Map([['xjy.config', JSON.stringify({ apiKey: 'sk-test1234567890' })]]);
const sent4 = [];
let added = 0;
const builtin = [
  { path: '/data/user/0/app.xiaojingyu.chat/files/stickers/builtin-happy.png', name: 'builtin-happy.png', bytes: 3100 },
  { path: '/data/user/0/app.xiaojingyu.chat/files/stickers/builtin-cry.png', name: 'builtin-cry.png', bytes: 3000 },
];
w4.Android = {
  hasBuiltinKey: () => false,
  openUrl: () => {},
  listStickers: () => JSON.stringify(builtin),
  addSticker: () => { added++; },
  deleteSticker: () => JSON.stringify(builtin.slice(0, 1)),
  readAsDataUrl: (p, id) => w4.__onDataUrl(id, p.endsWith('.png') ? 'data:image/png;base64,UE5H' : 'data:image/jpeg;base64,SlBH'),
  kvGet: (k) => (store4.has(k) ? store4.get(k) : ''),
  kvSet: (k, v) => store4.set(k, v),
  startChat: (json) => { sent4.push(JSON.parse(json)); setTimeout(() => w4.__onDone('哈哈哈'), 5); },
  speak: () => {}, stop: () => {},
};
w4.eval(js);
await sleep(50);
const q4 = (s) => w4.document.querySelector(s);

check('表情面板一开始是关的', q4('#stk').hidden === true);
q4('#pick-stk').dispatchEvent(new w4.Event('click'));
check('点 😊 打开面板', q4('#stk').hidden === false);
check('常用表情渲染出来了', q4('#stk-emoji').children.length >= 50, q4('#stk-emoji').children.length + ' 个');
q4('#stk-emoji').children[0].dispatchEvent(new w4.Event('click'));
check('点表情会插进输入框', q4('#input').value === '😀' && [...q4('#input').value].length === 1, JSON.stringify(q4('#input').value));

q4('#tab-mine').dispatchEvent(new w4.Event('click'));
await sleep(30);
check('切到「我的表情包」', q4('#stk-mine').hidden === false && q4('#stk-emoji').hidden === true);
check('内置表情包列出来了', q4('#stk-mine').querySelectorAll('img').length === 2, q4('#stk-mine').querySelectorAll('img').length + ' 张');
check('贴纸用 file:// 显示', q4('#stk-mine img').getAttribute('src').startsWith('file://'));

q4('#stk-add').dispatchEvent(new w4.Event('click'));
check('＋添加 会调原生选择器', added === 1, 'added=' + added);

q4('#input').value = '';   // 贴纸可以单独发，这里先清空输入框
q4('#stk-mine').querySelector('button').dispatchEvent(new w4.Event('click'));
await sleep(90);
const stkMsg = sent4.at(-1)?.messages?.at(-1);
check('点贴纸会直接发出去', Array.isArray(stkMsg?.content), JSON.stringify(stkMsg?.content)?.slice(0, 60));
check('贴纸以 PNG data URL 发出', JSON.stringify(stkMsg?.content || []).includes('data:image/png'), JSON.stringify(stkMsg?.content || []).slice(0, 120));
check('附带「表情包」说明', JSON.stringify(stkMsg?.content || []).includes('表情包'));
check('发完面板自动收起', q4('#stk').hidden === true);
check('气泡里能看到表情图', [...w4.document.querySelectorAll('.bub img.shot')].length === 1);

w4.__onStickers(JSON.stringify([builtin[0]]));
check('__onStickers 会刷新列表', q4('#stk-mine').querySelectorAll('img').length === 1, q4('#stk-mine').querySelectorAll('img').length + ' 张');

/* ============ 第 5 部分：时间 / 联网工具 ============ */
console.log('10) 看时间与联网搜索');
const dom5 = new JSDOM(html, { runScripts: 'outside-only', pretendToBeVisual: true, url: 'https://xjy.local/' });
const w5 = dom5.window;
w5.__XJY_NO_SELFTEST = true;
const store5 = new Map([['xjy.config', JSON.stringify({ apiKey: 'sk-test1234567890' })]]);
const sent5 = [];
w5.Android = {
  hasBuiltinKey: () => false,
  openUrl: () => {},
  kvGet: (k) => (store5.has(k) ? store5.get(k) : ''),
  kvSet: (k, v) => store5.set(k, v),
  startChat: (json) => { sent5.push(JSON.parse(json)); setTimeout(() => w5.__onDone('好的'), 5); },
  speak: () => {}, stop: () => {},
};
w5.eval(js);
await sleep(50);
const q5 = (s) => w5.document.querySelector(s);

q5('#input').value = '现在几点';
q5('#send').dispatchEvent(new w5.Event('click'));
await sleep(80);
const p5 = sent5.at(-1);
check('默认带上联网工具', p5.tools === true, 'tools=' + p5.tools);
const sys5 = String(p5.messages[0].content);
check('人设里注入了当前时间', /【当前时间】\d{4}-\d{2}-\d{2}/.test(sys5), (sys5.match(/【当前时间】[^\n]*/) || [''])[0]);
check('告诉她可以联网查', sys5.includes('web_search'));

// 模拟原生侧用了工具 → 界面要有提示
w5.__onTool('web_search', '上海天气 今天');
check('搜索时界面有提示', [...w5.document.querySelectorAll('.sys')].some((x) => x.textContent.includes('正在搜')), JSON.stringify([...w5.document.querySelectorAll('.sys')].map((x) => x.textContent).slice(-1)));
w5.__onTool('get_time', '');
check('看时间时界面有提示', [...w5.document.querySelectorAll('.sys')].some((x) => x.textContent.includes('看一下时间')));

// 关掉联网开关 → 请求里不该再带 tools
q5('#gear').dispatchEvent(new w5.Event('click'));
q5('#s-web').checked = false;
q5('#s-save').dispatchEvent(new w5.Event('click'));
q5('#input').value = '那现在几点';
q5('#send').dispatchEvent(new w5.Event('click'));
await sleep(80);
check('关掉开关后不再带 tools', sent5.at(-1).tools === false, 'tools=' + sent5.at(-1).tools);
check('关掉后也不再提 web_search', !String(sent5.at(-1).messages[0].content).includes('web_search'));

/* ============ 第 6 部分：笔记本 + 聊天背景 ============ */
console.log('11) 笔记本与聊天背景');
const dom6 = new JSDOM(html, { runScripts: 'outside-only', pretendToBeVisual: true, url: 'https://xjy.local/' });
const w6 = dom6.window;
w6.__XJY_NO_SELFTEST = true;
w6.confirm = () => true;   // jsdom 里 confirm 默认返回 undefined，这里放行
const store6 = new Map([['xjy.config', JSON.stringify({ apiKey: 'sk-test1234567890' })]]);
let noteList = [{ t: 1791900000000, text: '他叫小明，喜欢鲸鱼' }, { t: 1791900100000, text: '他周四要体检' }];
let addedNotes = [], searched = 0, pickedBg = 0, clearedBg = 0;
w6.Android = {
  hasBuiltinKey: () => false,
  openUrl: () => {},
  kvGet: (k) => (store6.has(k) ? store6.get(k) : ''),
  kvSet: (k, v) => store6.set(k, v),
  startChat: () => {},
  listNotes: () => JSON.stringify(noteList),
  addNote: (text) => { addedNotes.push(text); noteList = [{ t: Date.now(), text }].concat(noteList); return JSON.stringify(noteList); },
  deleteNote: (tt) => { noteList = noteList.filter((o) => o.t !== tt); return JSON.stringify(noteList); },
  searchNotes: (q) => { searched++; return JSON.stringify(noteList.filter((o) => o.text.includes(q))); },
  pickBackground: () => { pickedBg++; },
  clearBackground: () => { clearedBg++; w6.__onBackground(''); },
  currentBackground: () => 'file:///data/user/0/app.xiaojingyu.chat/files/bg/bg-1.jpg',
  speak: () => {}, stop: () => {},
};
w6.eval(js);
await sleep(60);
const q6 = (s) => w6.document.querySelector(s);

// 背景：启动时应该从原生恢复
check('启动时恢复了背景', q6('#bg').hidden === false && w6.document.body.classList.contains('has-bg'));
check('背景图地址用上了', String(q6('#bg').style.backgroundImage).startsWith('url('), q6('#bg').style.backgroundImage.slice(0, 48));
check('压暗层有默认值', q6('#bg').style.getPropertyValue('--veil') !== '', q6('#bg').style.getPropertyValue('--veil'));

q6('#gear').dispatchEvent(new w6.Event('click'));
check('设置里显示笔记条数', q6('#s-notes-count').textContent === '2', q6('#s-notes-count').textContent);
q6('#s-bg').dispatchEvent(new w6.Event('click'));
check('点「选图」调起原生选背景', pickedBg === 1, 'pickedBg=' + pickedBg);
q6('#s-bgdim').value = '0.7';
q6('#s-bgdim').dispatchEvent(new w6.Event('input'));
check('拖动压暗立刻生效', q6('#bg').style.getPropertyValue('--veil') === '0.7', q6('#bg').style.getPropertyValue('--veil'));
q6('#s-bg-clear').dispatchEvent(new w6.Event('click'));
check('恢复默认会调原生并隐藏背景层', clearedBg === 1 && q6('#bg').hidden === true);

// 笔记本面板
q6('#s-notes').dispatchEvent(new w6.Event('click'));
check('笔记本面板打开', q6('#nb').hidden === false);
check('笔记列出来了', q6('#nb-list').querySelectorAll('.nb-row').length === 2, q6('#nb-list').querySelectorAll('.nb-row').length + ' 条');
check('设置了面板会关掉', q6('#sheet').classList.contains('open') === false);
check('条目上有时间', q6('#nb-list .nb-time').textContent.length >= 6, q6('#nb-list .nb-time').textContent);

q6('#nb-search').value = '体检';
q6('#nb-search').dispatchEvent(new w6.Event('input'));
await sleep(20);
check('搜索走的是原生同一套检索', searched >= 1, 'searched=' + searched);
check('搜到 1 条', q6('#nb-list').querySelectorAll('.nb-row').length === 1, q6('#nb-list').querySelectorAll('.nb-row').length + ' 条');
q6('#nb-search').value = '';
q6('#nb-search').dispatchEvent(new w6.Event('input'));

q6('#nb-input').value = '他最近在做一个聊天 app';
q6('#nb-save').dispatchEvent(new w6.Event('click'));
check('手动加笔记会写进去', addedNotes.length === 1 && addedNotes[0].includes('聊天 app'), JSON.stringify(addedNotes));
check('加完列表变 3 条', q6('#nb-list').querySelectorAll('.nb-row').length === 3, q6('#nb-list').querySelectorAll('.nb-row').length + ' 条');
check('设置里的条数同步', q6('#s-notes-count').textContent === '3', q6('#s-notes-count').textContent);

const firstDel = [...q6('#nb-list').querySelectorAll('.nb-row .icon')][0];
firstDel.dispatchEvent(new w6.Event('click'));
await sleep(20);
check('删除笔记生效', q6('#nb-list').querySelectorAll('.nb-row').length === 2, q6('#nb-list').querySelectorAll('.nb-row').length + ' 条');

w6.__onNotes(JSON.stringify([{ t: 1, text: '她主动记的一条' }]));
check('__onNotes 会刷新界面', q6('#nb-list').querySelectorAll('.nb-row').length === 1);

/* ============ 第 7 部分：多服务商 ============ */
console.log('12) 服务商切换（OpenAI 兼容）');
const dom7 = new JSDOM(html, { runScripts: 'outside-only', pretendToBeVisual: true, url: 'https://xjy.local/' });
const w7 = dom7.window;
w7.__XJY_NO_SELFTEST = true;
const store7 = new Map([['xjy.config', JSON.stringify({ apiKey: 'sk-test1234567890' })]]);
const sent7 = [];
w7.Android = {
  hasBuiltinKey: () => false,
  openUrl: () => {},
  kvGet: (k) => (store7.has(k) ? store7.get(k) : ''),
  kvSet: (k, v) => store7.set(k, v),
  startChat: (json) => { sent7.push(JSON.parse(json)); setTimeout(() => w7.__onDone('好'), 5); },
  speak: () => {}, stop: () => {},
};
w7.eval(js);
await sleep(50);
const q7 = (s) => w7.document.querySelector(s);
const send7 = async (txt) => { q7('#input').value = txt; q7('#send').dispatchEvent(new w7.Event('click')); await sleep(90); return sent7.at(-1); };

let req7 = await send7('你好');
check('默认用 DeepSeek 官方地址', req7.baseUrl === 'https://api.deepseek.com', req7.baseUrl);
check('默认模型是 deepseek-flash', req7.model === 'deepseek-flash', req7.model);

q7('#gear').dispatchEvent(new w7.Event('click'));
check('服务商下拉有多个选项', q7('#s-provider').options.length >= 8, q7('#s-provider').options.length + ' 个');
q7('#s-provider').value = 'zhipu';
q7('#s-provider').dispatchEvent(new w7.Event('change'));
check('换服务商自动填地址', q7('#s-base').value.includes('bigmodel.cn'), q7('#s-base').value);
check('换服务商自动换默认模型', q7('#s-model').value === 'glm-4-flash', q7('#s-model').value);
check('模型候选下拉被填入', q7('#model-presets').children.length >= 3, q7('#model-presets').children.length + ' 个');
q7('#s-key').value = 'zhipu-key-123456';
q7('#s-save').dispatchEvent(new w7.Event('click'));
req7 = await send7('你好呀');
check('请求带上了新服务商地址', req7.baseUrl.includes('bigmodel.cn'), req7.baseUrl);
check('请求带上了新模型', req7.model === 'glm-4-flash', req7.model);
check('请求带上了新 key', req7.apiKey === 'zhipu-key-123456');

// 本地 Ollama：不支持工具 → 请求里不该带 tools
q7('#gear').dispatchEvent(new w7.Event('click'));
q7('#s-provider').value = 'ollama';
q7('#s-provider').dispatchEvent(new w7.Event('change'));
check('本地模型地址是 127.0.0.1', q7('#s-base').value.includes('127.0.0.1'), q7('#s-base').value);
check('本地模型能力默认关掉工具', q7('#s-tools').checked === false);
q7('#s-save').dispatchEvent(new w7.Event('click'));
req7 = await send7('在吗');
check('不支持工具的服务商不发 tools', req7.tools === false, 'tools=' + req7.tools);

// 不支持看图的服务商：发图只发文字并提示
q7('#gear').dispatchEvent(new w7.Event('click'));
q7('#s-provider').value = 'siliconflow';
q7('#s-provider').dispatchEvent(new w7.Event('change'));
check('该服务商能力默认不支持看图', q7('#s-vision').checked === false);
q7('#s-save').dispatchEvent(new w7.Event('click'));
w7.__onAttachment(JSON.stringify({ kind: 'image', path: '/tmp/a.jpg', name: 'a.jpg', bytes: 1000, w: 10, h: 10, dataUrl: 'data:image/jpeg;base64,QUJD' }));
q7('#input').value = '看这个';
q7('#send').dispatchEvent(new w7.Event('click'));
await sleep(90);
const last7 = JSON.stringify(sent7.at(-1).messages.at(-1).content);
check('不支持看图时不发 image_url', !last7.includes('image_url'), last7.slice(0, 80));
check('而是明确告诉模型这是张图', last7.includes('不支持看图片'), last7.slice(0, 80));

/* ============ 第 8 部分：多角色 ============ */
console.log('13) 多角色切换');
const dom8 = new JSDOM(html, { runScripts: 'outside-only', pretendToBeVisual: true, url: 'https://xjy.local/' });
const w8 = dom8.window;
w8.__XJY_NO_SELFTEST = true;
w8.confirm = () => true;
const seedJingyu = [
  { role: 'user', content: '第一条：我是小明', t: 1 },
  { role: 'assistant', content: '记住啦', t: 2 },
];
const store8 = new Map([
  ['xjy.config', JSON.stringify({ apiKey: 'sk-test1234567890' })],
  ['xjy.history', JSON.stringify(seedJingyu)],
]);
const sent8 = [];
w8.Android = {
  hasBuiltinKey: () => false,
  openUrl: () => {},
  kvGet: (k) => (store8.has(k) ? store8.get(k) : ''),
  kvSet: (k, v) => store8.set(k, v),
  startChat: (json) => { sent8.push(JSON.parse(json)); setTimeout(() => w8.__onDone('好'), 5); },
  listNotes: () => '[]',
  speak: () => {}, stop: () => {},
};
w8.eval(js);
await sleep(60);
const q8 = (s) => w8.document.querySelector(s);

check('默认角色是小鲸鱼', q8('#char-name').textContent === '小鲸鱼', q8('#char-name').textContent);
check('旧版单份记录被迁移到小鲸鱼名下', store8.has('xjy.hist.jingyu'), [...store8.keys()].join(','));
check('小鲸鱼的记录在页面上', w8.document.querySelector('#log').textContent.includes('我是小明'));

q8('#who').dispatchEvent(new w8.Event('click'));
check('点头像弹出角色列表', q8('#chars').classList.contains('open'));
const rows8 = [...q8('#char-list').querySelectorAll('.char-row')];
check('角色列表有多个角色', rows8.length >= 6, rows8.length + ' 个');
check('列表里有温柔姐姐', rows8.some((r) => r.textContent.includes('温柔姐姐')));

// 切到温柔姐姐
const sisterRow = rows8.find((r) => r.textContent.includes('温柔姐姐'));
sisterRow.querySelector('button.ghost').dispatchEvent(new w8.Event('click'));
await sleep(40);
check('切换后头部名字变了', q8('#char-name').textContent === '温柔姐姐', q8('#char-name').textContent);
check('切换后是干净的记录（只剩招呼语）', !w8.document.querySelector('#log').textContent.includes('我是小明'));
check('切换后显示该角色的招呼语', w8.document.querySelector('#log').textContent.includes('先坐下歇会儿'), w8.document.querySelector('#log').textContent.slice(0, 30));

q8('#input').value = '姐姐在吗';
q8('#send').dispatchEvent(new w8.Event('click'));
await sleep(90);
const sysSister = String(sent8.at(-1).messages[0].content);
check('发给模型的人设换成了姐姐', sysSister.includes('姐姐') && !sysSister.includes('小鲸鱼娘'), sysSister.slice(0, 40));

// 切回小鲸鱼：记录应该还在
q8('#who').dispatchEvent(new w8.Event('click'));
const jingRow = [...q8('#char-list').querySelectorAll('.char-row')].find((r) => r.textContent.includes('小鲸鱼'));
jingRow.querySelector('button.ghost').dispatchEvent(new w8.Event('click'));
await sleep(40);
check('切回小鲸鱼后旧记录还在', w8.document.querySelector('#log').textContent.includes('我是小明'));
check('两个角色的记录是分开存的', store8.has('xjy.hist.jingyu') && store8.has('xjy.hist.sister'), [...store8.keys()].filter((k) => k.startsWith('xjy.hist')).join(','));

// 新建角色 + 改名改人设
q8('#who').dispatchEvent(new w8.Event('click'));
q8('#char-new').dispatchEvent(new w8.Event('click'));
await sleep(40);
check('新建后当前角色是新角色', q8('#char-name').textContent === '新角色', q8('#char-name').textContent);
const savedCfg8 = JSON.parse(store8.get('xjy.config'));
check('自建角色写进了配置', Array.isArray(savedCfg8.customChars) && savedCfg8.customChars.length === 1, JSON.stringify(savedCfg8.customChars?.length));

q8('#gear').dispatchEvent(new w8.Event('click'));
q8('#s-char-name').value = '小猫咪';
q8('#s-char-emoji').value = '🐱';
q8('#s-persona').value = '你是一只高冷的小猫咪，说话带喵。';
q8('#s-save').dispatchEvent(new w8.Event('click'));
check('改名后头部跟着变', q8('#char-name').textContent === '小猫咪', q8('#char-name').textContent);
check('头像用了新 emoji', q8('#char-avatar').textContent === '🐱', q8('#char-avatar').textContent);
await sleep(30);
q8('#input').value = '喵一声';
q8('#send').dispatchEvent(new w8.Event('click'));
await sleep(90);
check('新角色的人设生效', String(sent8.at(-1).messages[0].content).includes('小猫咪'), String(sent8.at(-1).messages[0].content).slice(0, 30));

/* ============ 第 9 部分：英文界面 / 头像图 / 导出 / 更新检查 ============ */
console.log('14) 英文界面 · 角色头像 · 导出 · 更新检查');
const dom9 = new JSDOM(html, { runScripts: 'outside-only', pretendToBeVisual: true, url: 'https://xjy.local/' });
const w9 = dom9.window;
w9.__XJY_NO_SELFTEST = true;
const store9 = new Map([
  ['xjy.config', JSON.stringify({ apiKey: 'sk-test1234567890', character: 'jingyu' })],
  ['xjy.hist.jingyu', JSON.stringify([{ role: 'user', content: '你好呀', t: 1791900000000 }, { role: 'assistant', content: '嘿嘿', t: 1791900001000 }])],
]);
const sent9 = [];
let exported = null, openedUrl = null, httpCalled = null, avatarPicked = 0;
w9.Android = {
  hasBuiltinKey: () => false,
  openUrl: (u) => { openedUrl = u; },
  kvGet: (k) => (store9.has(k) ? store9.get(k) : ''),
  kvSet: (k, v) => store9.set(k, v),
  startChat: (json) => { sent9.push(JSON.parse(json)); setTimeout(() => w9.__onDone('ok'), 5); },
  appVersion: () => '1.0.0',
  listNotes: () => '[]',
  exportText: (name, content) => { exported = { name, content }; },
  pickCharAvatar: () => { avatarPicked++; },
  httpGet: (url, reqId) => { httpCalled = url; w9.__onHttp(reqId, JSON.stringify({ tag_name: 'v1.2.0', html_url: 'https://github.com/u/r/releases/tag/v1.2.0', assets: [{ name: 'xiaojingyu.apk', browser_download_url: 'https://github.com/u/r/releases/download/v1.2.0/xiaojingyu.apk' }] })); },
  speak: () => {}, stop: () => {},
};
w9.eval(js);
await sleep(60);
const q9 = (s) => w9.document.querySelector(s);

// --- 英文界面 ---
check('默认是中文界面', q9('#sheet-title').textContent === '设置', q9('#sheet-title').textContent);
q9('#gear').dispatchEvent(new w9.Event('click'));
q9('#s-lang').value = 'en';
q9('#s-lang').dispatchEvent(new w9.Event('change'));
await sleep(30);
check('设置标题变英文', q9('#sheet-title').textContent === 'Settings', q9('#sheet-title').textContent);
check('输入框占位变英文', q9('#input').placeholder === 'Say something…', q9('#input').placeholder);
check('保存按钮变英文', q9('#s-save').textContent === 'Save', q9('#s-save').textContent);
check('标签文字变英文', q9('#l-persona').textContent.trim().startsWith('Persona'), q9('#l-persona').textContent.trim().slice(0, 20));
check('语言存进了配置', JSON.parse(store9.get('xjy.config')).lang === 'en');

q9('#input').value = 'hi';
q9('#send').dispatchEvent(new w9.Event('click'));
await sleep(90);
const sysEn = String(sent9.at(-1).messages[0].content);
check('英文界面下发的是英文人设', sysEn.includes('Little Whale') && sysEn.includes('ALWAYS reply in English'), sysEn.slice(0, 40));
check('头部状态也变英文', q9('#status').textContent === 'online', q9('#status').textContent);

// --- 角色头像图片 ---
q9('#s-char-img').dispatchEvent(new w9.Event('click'));
check('点选图片会调原生', avatarPicked === 1, 'picked=' + avatarPicked);
w9.__onCharAvatar('file:///data/user/0/app.xiaojingyu.chat/files/chars/a.jpg');
await sleep(30);
check('头部换成图片头像', !!q9('#char-avatar').querySelector('img'));
check('头像图存进了角色覆盖表', String(JSON.parse(store9.get('xjy.config')).chars?.jingyu?.image || '').includes('chars/a.jpg'), JSON.stringify(JSON.parse(store9.get('xjy.config')).chars));

// --- 导出 ---
q9('#s-export').dispatchEvent(new w9.Event('click'));
await sleep(30);
check('导出调起了原生保存', !!exported, JSON.stringify(exported && exported.name));
check('文件名带角色和日期', /\.md$/.test(exported.name), exported.name);
check('导出内容含聊天记录', exported.content.includes('你好呀') && exported.content.includes('嘿嘿'), exported.content.content);
check('导出内容含角色名', exported.content.includes('小鲸鱼'));
w9.__onExportResult(true, 'content://x');
check('导出成功有提示', [...w9.document.querySelectorAll('.sys')].some((x) => x.textContent.includes('Exported')), 'ok');

// --- 更新检查 ---
q9('#s-repo').value = 'someone/xiaojingyu';
q9('#s-save').dispatchEvent(new w9.Event('click'));
q9('#gear').dispatchEvent(new w9.Event('click'));
q9('#s-check-update').dispatchEvent(new w9.Event('click'));
await sleep(120);
check('更新检查请求打到 GitHub API', String(httpCalled).includes('api.github.com/repos/someone/xiaojingyu/releases/latest'), String(httpCalled));
const link9 = [...w9.document.querySelectorAll('.sys a')].pop();
check('发现新版本时给出可点提示', !!link9 && link9.textContent.includes('1.2.0'), link9 ? link9.textContent : '(无)');
link9.dispatchEvent(new w9.Event('click'));
check('点提示会打开 APK 下载地址', String(openedUrl).includes('releases/download/v1.2.0'), String(openedUrl));

/* ============ 第 10 部分：浮层互斥（回归：设置被角色面板盖住打不开） ============ */
console.log('15) 浮层互斥');
const domA = new JSDOM(html, { runScripts: 'outside-only', pretendToBeVisual: true, url: 'https://xjy.local/' });
const wA = domA.window;
wA.__XJY_NO_SELFTEST = true;
const storeA = new Map([['xjy.config', JSON.stringify({ apiKey: 'sk-test1234567890' })]]);
wA.Android = {
  hasBuiltinKey: () => false, openUrl: () => {},
  kvGet: (k) => (storeA.has(k) ? storeA.get(k) : ''), kvSet: (k, v) => storeA.set(k, v),
  startChat: () => {}, listNotes: () => '[]', speak: () => {}, stop: () => {}, appVersion: () => '1.0.0',
};
wA.eval(js);
await sleep(60);
const qA = (s) => wA.document.querySelector(s);
const open = (id) => !qA(id).hidden || qA(id).classList.contains('open');
const countOpen = () => ['#sheet', '#chars', '#nb', '#stk'].filter((s) => (s === '#nb' || s === '#stk' ? !qA(s).hidden : (qA(s).classList.contains('open') && !qA(s).hidden))).length;

qA('#gear').dispatchEvent(new wA.Event('click'));
check('点齿轮：只开设置', countOpen() === 1 && open('#sheet'), '开着的浮层数=' + countOpen());
qA('#who').dispatchEvent(new wA.Event('click'));
check('点头像：只开角色页', countOpen() === 1 && open('#chars'), '开着的浮层数=' + countOpen());
qA('#gear').dispatchEvent(new wA.Event('click'));
check('角色页开着时点齿轮：设置能开、角色页自动关', open('#sheet') && !open('#chars'), '开着的浮层数=' + countOpen());
qA('#s-notes').dispatchEvent(new wA.Event('click'));
check('开笔记本：设置自动关', open('#nb') && !open('#sheet'), '开着的浮层数=' + countOpen());
qA('#pick-stk').dispatchEvent(new wA.Event('click'));
check('开表情面板：笔记本自动关', open('#stk') && !open('#nb'), '开着的浮层数=' + countOpen());
qA('#who').dispatchEvent(new wA.Event('click'));
check('开角色页：表情面板自动关', open('#chars') && !open('#stk'), '开着的浮层数=' + countOpen());
qA('#char-close').dispatchEvent(new wA.Event('click'));
check('关掉角色页后没有残留浮层', countOpen() === 0, '开着的浮层数=' + countOpen());

/* ============ 第 11 部分：真机解析顺序（脚本在 HTML 里的位置） ============ */
console.log('16) 真机解析顺序（回归：脚本先于元素执行导致后面绑定全丢）');
const TAG = '<script src="app.js"></script>';
check('index.html 里 script 在 </body> 前、且在所有元素之后',
  html.indexOf(TAG) > html.indexOf('id="chars"') && html.indexOf(TAG) > html.indexOf('id="sheet"'),
  'script@' + html.indexOf(TAG) + ' chars@' + html.indexOf('id="chars"'));

const [pre, post] = html.split(TAG);
const domB = new JSDOM(pre, { runScripts: 'outside-only', pretendToBeVisual: true, url: 'https://xjy.local/' });
const wB = domB.window;
wB.__XJY_NO_SELFTEST = true;
const storeB = new Map([['xjy.config', JSON.stringify({ apiKey: 'sk-test1234567890' })]]);
wB.Android = {
  hasBuiltinKey: () => false, openUrl: () => {},
  kvGet: (k) => (storeB.has(k) ? storeB.get(k) : ''), kvSet: (k, v) => storeB.set(k, v),
  startChat: () => {}, listNotes: () => '[]', speak: () => {}, stop: () => {}, appVersion: () => '1.0.2',
};
let bootErr = null;
try { wB.eval(js); } catch (e) { bootErr = e; }
check('脚本在元素之前执行也不抛错', !bootErr, bootErr ? bootErr.message : '无异常');
check('没有缺失的绑定元素', (wB.__XJY_MISSING || []).length === 0, JSON.stringify(wB.__XJY_MISSING || []));
wB.document.body.insertAdjacentHTML('beforeend', post);   // 继续解析剩余 HTML

const qB = (s) => wB.document.querySelector(s);
qB('#gear').dispatchEvent(new wB.Event('click'));
check('★ 点齿轮能打开设置（真机顺序）', qB('#sheet').classList.contains('open') && !qB('#sheet').hidden);
qB('#who').dispatchEvent(new wB.Event('click'));
check('★ 点头像能打开角色列表（真机顺序）', qB('#chars').classList.contains('open'));
qB('#pick-stk').dispatchEvent(new wB.Event('click'));
check('★ 表情面板也能开（真机顺序）', !qB('#stk').hidden);

/* ============ 第 12 部分：新建角色防抖 / 删除角色 ============ */
console.log('17) 新建角色防抖与删除');
const domC = new JSDOM(html, { runScripts: 'outside-only', pretendToBeVisual: true, url: 'https://xjy.local/' });
const wC = domC.window;
wC.__XJY_NO_SELFTEST = true;
wC.confirm = () => true;   // 真机上由 Java 的系统对话框接管
const storeC = new Map([['xjy.config', JSON.stringify({ apiKey: 'sk-test1234567890' })]]);
wC.Android = {
  hasBuiltinKey: () => false, openUrl: () => {},
  kvGet: (k) => (storeC.has(k) ? storeC.get(k) : ''), kvSet: (k, v) => storeC.set(k, v),
  startChat: () => {}, listNotes: () => '[]', speak: () => {}, stop: () => {}, appVersion: () => '1.0.2',
};
wC.eval(js);
await sleep(60);
const qC = (s) => wC.document.querySelector(s);
const custom = () => JSON.parse(storeC.get('xjy.config')).customChars || [];

qC('#who').dispatchEvent(new wC.Event('click'));
qC('#char-new').dispatchEvent(new wC.Event('click'));   // 连点 4 次
qC('#char-new').dispatchEvent(new wC.Event('click'));
qC('#char-new').dispatchEvent(new wC.Event('click'));
qC('#char-new').dispatchEvent(new wC.Event('click'));
await sleep(30);
check('连点 4 次只新建 1 个角色', custom().length === 1, custom().length + ' 个');
check('新建后自动打开设置（方便马上改名）', qC('#sheet').classList.contains('open'));
check('角色页已自动关闭', !qC('#chars').classList.contains('open'));

// 再点新建：因为当前这个还没改过，应该不新建、只提示
const before = custom().length;
await sleep(900);
qC('#who').dispatchEvent(new wC.Event('click'));
qC('#char-new').dispatchEvent(new wC.Event('click'));
await sleep(30);
check('当前已是未修改的新角色时不再重复新建', custom().length === before, custom().length + ' 个');

// 删除：确认后应该真的删掉
qC('#who').dispatchEvent(new wC.Event('click'));
const delBtn = qC('#char-list .char-del');
check('自建角色有删除按钮', !!delBtn);
delBtn.dispatchEvent(new wC.Event('click'));
await sleep(30);
check('★ 确认后角色被删掉（真机上靠 Java 的 confirm 对话框）', custom().length === before - 1, custom().length + ' 个');
check('删完回到内置角色', qC('#char-name').textContent === '小鲸鱼', qC('#char-name').textContent);

/* ============ 第 13 部分：更新检查的反馈与兜底 ============ */
console.log('18) 更新检查（设置页内反馈 / 网页兜底）');
const mkDom18 = async (httpImpl) => {
  const dom = new JSDOM(html, { runScripts: 'outside-only', pretendToBeVisual: true, url: 'https://xjy.local/' });
  const w = dom.window; w.__XJY_NO_SELFTEST = true;
  const store = new Map([['xjy.config', JSON.stringify({ apiKey: 'sk-test1234567890', repoSlug: 'someone/xjy' })]]);
  w.Android = {
    hasBuiltinKey: () => false, openUrl: (u) => { w.__opened = u; },
    kvGet: (k) => (store.has(k) ? store.get(k) : ''), kvSet: (k, v) => store.set(k, v),
    startChat: () => {}, listNotes: () => '[]', speak: () => {}, stop: () => {}, appVersion: () => '1.0.3',
    httpGet: httpImpl,
  };
  w.eval(js);
  await sleep(60);
  return w;
};
const q18 = (w, s) => w.document.querySelector(s);
const click18 = (w, id) => q18(w, '#' + id).dispatchEvent(new w.Event('click'));

// A) API 失败（限流/被墙）→ 退回抓网页
let wApi = null;
const pageHtml = '<html><a href="/someone/xjy/releases/tag/v1.0.9">v1.0.9</a></html>';
const fragHtml = '<a href="/someone/xjy/releases/download/v1.0.9/default.apk"><span>default.apk</span></a>'
  + '<a href="/someone/xjy/releases/download/v1.0.9/xiaojingyu-1.0.9.apk"><span>xiaojingyu-1.0.9.apk</span></a>';
wApi = await mkDom18((url, reqId) => {
  if (url.indexOf('api.github.com') >= 0) return setTimeout(() => wApi.__onHttp(reqId, null), 5);
  if (url.indexOf('expanded_assets') >= 0) return setTimeout(() => wApi.__onHttp(reqId, fragHtml), 5);
  return setTimeout(() => wApi.__onHttp(reqId, pageHtml), 5);
});
click18(wApi, 'gear');
click18(wApi, 's-check-update');
await sleep(180);
const hintA = q18(wApi, '#s-hint');
check('★ 手动检查结果写在设置页里（不再被面板盖住）', /1\.0\.9/.test(hintA.textContent), hintA.textContent);
check('★ API 失败时能退回网页解析', /1\.0\.9/.test(hintA.textContent), String(hintA.textContent).slice(0, 44));
check('发现新版时提示可点', !!hintA.onclick);
hintA.dispatchEvent(new wApi.Event('click'));
await sleep(20);
check('点提示打开的是带版本号的那个 apk', String(wApi.__opened || '').includes('xiaojingyu-1.0.9.apk'), String(wApi.__opened));

// B) 已是最新版
let wUp2 = null;
wUp2 = await mkDom18((url, reqId) => setTimeout(() => wUp2.__onHttp(reqId, url.indexOf('api.github.com') >= 0
  ? JSON.stringify({ tag_name: 'v1.0.3', html_url: 'https://github.com/someone/xjy/releases/tag/v1.0.3', assets: [] }) : ''), 5));
click18(wUp2, 'gear');
click18(wUp2, 's-check-update');
await sleep(140);
check('★ 同时弹出底部提示条（滚到哪都看得见）', !q18(wApi, '#toast').hidden && /1\.0\.9/.test(q18(wApi, '#toast').textContent), q18(wApi, '#toast').textContent);
check('按钮下面那行也有回执', /1\.0\.9/.test(q18(wApi, '#s-upd-hint').textContent), q18(wApi, '#s-upd-hint').textContent);
q18(wApi, '#toast').dispatchEvent(new wApi.Event('click'));
await sleep(20);
check('点提示条也能下载', String(wApi.__opened || '').includes('1.0.9'), String(wApi.__opened));
check('点完提示条自动收起', q18(wApi, '#toast').hidden === true);
check('已是最新版时给明确回执', /最新版|latest/i.test(q18(wUp2, '#s-hint').textContent), q18(wUp2, '#s-hint').textContent);
check('已是最新版也弹提示条', !q18(wUp2, '#toast').hidden && /最新版|latest/i.test(q18(wUp2, '#toast').textContent), q18(wUp2, '#toast').textContent);

// C) 没填仓库时给提示
const dom18c = new JSDOM(html, { runScripts: 'outside-only', pretendToBeVisual: true, url: 'https://xjy.local/' });
const w18c = dom18c.window; w18c.__XJY_NO_SELFTEST = true;
const store18c = new Map([['xjy.config', JSON.stringify({ apiKey: 'sk-test1234567890' })]]);
w18c.Android = { hasBuiltinKey: () => false, openUrl: () => {}, kvGet: (k) => store18c.get(k) || '', kvSet: (k, v) => store18c.set(k, v),
  startChat: () => {}, listNotes: () => '[]', speak: () => {}, stop: () => {}, appVersion: () => '1.0.3', httpGet: () => {} };
w18c.eval(js);
await sleep(60);
const cfg18c = JSON.parse(store18c.get('xjy.config')); cfg18c.repoSlug = ''; store18c.set('xjy.config', JSON.stringify(cfg18c));
q18(w18c, '#gear').dispatchEvent(new w18c.Event('click'));
q18(w18c, '#s-repo').value = '';
q18(w18c, '#s-save').dispatchEvent(new w18c.Event('click'));
q18(w18c, '#gear').dispatchEvent(new w18c.Event('click'));
q18(w18c, '#s-check-update').dispatchEvent(new w18c.Event('click'));
await sleep(60);
check('没填仓库时也有提示', q18(w18c, '#s-hint').textContent.length > 0, q18(w18c, '#s-hint').textContent);

console.log(failed === 0 ? '\n全部通过 ✅' : `\n${failed} 项失败 ❌`);
process.exit(failed === 0 ? 0 : 1);
