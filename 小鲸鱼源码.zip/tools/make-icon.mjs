// 生成 App 图标（纯 JS 画图 + 手写 PNG），输出 res/drawable/icon.png
import fs from 'node:fs';
import zlib from 'node:zlib';
import path from 'node:path';

const S = 192;
const out = process.argv[2] || path.join(process.env.HOME, 'xiaojingyu-app/android/res/drawable/icon.png');

const px = new Uint8Array(S * S * 4); // RGBA

const set = (x, y, r, g, b, a = 255) => {
  if (x < 0 || y < 0 || x >= S || y >= S) return;
  const i = (y * S + x) * 4;
  const na = a / 255, ia = px[i + 3] / 255;
  const oa = na + ia * (1 - na);
  if (oa === 0) return;
  px[i] = Math.round((r * na + px[i] * ia * (1 - na)) / oa);
  px[i + 1] = Math.round((g * na + px[i + 1] * ia * (1 - na)) / oa);
  px[i + 2] = Math.round((b * na + px[i + 2] * ia * (1 - na)) / oa);
  px[i + 3] = Math.round(oa * 255);
};

const ellipse = (cx, cy, rx, ry, col, alpha = 255) => {
  for (let y = Math.floor(cy - ry); y <= Math.ceil(cy + ry); y++)
    for (let x = Math.floor(cx - rx); x <= Math.ceil(cx + rx); x++) {
      const dx = (x - cx) / rx, dy = (y - cy) / ry;
      const d = dx * dx + dy * dy;
      if (d <= 1) set(x, y, col[0], col[1], col[2], alpha);
    }
};

const tri = (p1, p2, p3, col, alpha = 255) => {
  const minx = Math.min(p1[0], p2[0], p3[0]), maxx = Math.max(p1[0], p2[0], p3[0]);
  const miny = Math.min(p1[1], p2[1], p3[1]), maxy = Math.max(p1[1], p2[1], p3[1]);
  const sign = (a, b, c) => (a[0] - c[0]) * (b[1] - c[1]) - (b[0] - c[0]) * (a[1] - c[1]);
  for (let y = miny; y <= maxy; y++) for (let x = minx; x <= maxx; x++) {
    const p = [x, y];
    const d1 = sign(p, p1, p2), d2 = sign(p, p2, p3), d3 = sign(p, p3, p1);
    const neg = d1 < 0 || d2 < 0 || d3 < 0, pos = d1 > 0 || d2 > 0 || d3 > 0;
    if (!(neg && pos)) set(x, y, col[0], col[1], col[2], alpha);
  }
};

// 圆角背景（深海底）+ 一点渐变
const R = 44;
for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
  const inCorner = (cx, cy) => Math.hypot(x - cx, y - cy) > R;
  const corner = (x < R && y < R && inCorner(R, R)) || (x >= S - R && y < R && inCorner(S - R, R))
    || (x < R && y >= S - R && inCorner(R, S - R)) || (x >= S - R && y >= S - R && inCorner(S - R, S - R));
  if (corner) continue;
  const t = y / S;
  set(x, y, Math.round(10 + 18 * (1 - t)), Math.round(38 + 52 * (1 - t)), Math.round(64 + 70 * (1 - t)));
}

const BLUE = [88, 166, 255];
const LIGHT = [186, 224, 255];
const WHITE = [255, 255, 255];

// 尾巴（右侧两片）
tri([126, 104], [178, 62], [172, 104], BLUE);
tri([126, 104], [178, 146], [172, 104], BLUE);
// 身体
ellipse(92, 104, 56, 38, BLUE);
// 肚皮
ellipse(90, 118, 42, 20, LIGHT, 210);
// 眼睛
ellipse(64, 92, 7, 7, WHITE);
ellipse(66, 93, 3, 3, [12, 32, 52]);
// 笑脸
for (let i = 0; i < 40; i++) {
  const a = Math.PI * (0.15 + 0.7 * (i / 39));
  set(Math.round(84 + Math.cos(a) * 14), Math.round(102 + Math.sin(a) * 9), 12, 32, 52, 200);
}
// 喷出的水花
for (const [x, y, r] of [[78, 52, 7], [92, 40, 6], [106, 50, 5], [86, 62, 4]])
  ellipse(x, y, r, r, WHITE, 220);

// ---- PNG 编码 ----
const crcTable = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c; }
  return t;
})();
const crc32 = (buf) => { let c = -1; for (const b of buf) c = crcTable[(c ^ b) & 0xFF] ^ (c >>> 8); return (c ^ -1) >>> 0; };
const chunk = (type, data) => {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
};
const raw = Buffer.alloc(S * (S * 4 + 1));
for (let y = 0; y < S; y++) {
  raw[y * (S * 4 + 1)] = 0;
  Buffer.from(px.buffer, y * S * 4, S * 4).copy(raw, y * (S * 4 + 1) + 1);
}
const ihdr = Buffer.alloc(13);
ihdr.writeUInt32BE(S, 0); ihdr.writeUInt32BE(S, 4);
ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
const png = Buffer.concat([
  Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]),
  chunk('IHDR', ihdr),
  chunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
  chunk('IEND', Buffer.alloc(0)),
]);
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, png);
console.log('icon written:', out, png.length, 'bytes');
