// 在 JVM 上跑一遍和 MainActivity 里一模一样的"请求 + SSE 解析"逻辑
// 用法：XJY_KEY=sk-xxx java -cp <json.jar>:<classes> StreamTest [badkey]
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONObject;

public class StreamTest {

    static final String API_URL = "https://api.deepseek.com/chat/completions";

    /** 从一条 SSE data 负载里取出增量文本；没有就返回 ""（与 MainActivity 里同一套判断） */
    static String deltaText(String payload) {
        try {
            JSONObject j = new JSONObject(payload);
            JSONArray choices = j.optJSONArray("choices");
            if (choices == null || choices.length() == 0) return "";
            JSONObject delta = choices.getJSONObject(0).optJSONObject("delta");
            if (delta == null) return "";
            Object raw = delta.opt("content");          // optString 遇到 JSON null 会返回 "null"
            if (!(raw instanceof String)) return "";
            return (String) raw;
        } catch (Throwable e) { return ""; }
    }

    static void nullTest() {
        System.out.println("content: null   -> " + quote(deltaText("{\"choices\":[{\"delta\":{\"content\":null}}]}")));
        System.out.println("无 content 字段 -> " + quote(deltaText("{\"choices\":[{\"delta\":{\"role\":\"assistant\"}}]}")));
        System.out.println("content: \"\"    -> " + quote(deltaText("{\"choices\":[{\"delta\":{\"content\":\"\"}}]}")));
        System.out.println("content: 你好   -> " + quote(deltaText("{\"choices\":[{\"delta\":{\"content\":\"你好\"}}]}")));
        String all = deltaText("{\"choices\":[{\"delta\":{\"content\":null}}]}")
                   + deltaText("{\"choices\":[{\"delta\":{\"content\":\"真\"}}]}")
                   + deltaText("{\"choices\":[{\"delta\":{\"content\":null}}]}")
                   + deltaText("{\"choices\":[{\"delta\":{\"content\":\"的\"}}]}");
        System.out.println("混合三片拼起来 -> " + quote(all) + (all.equals("真的") ? "  ✅ 没有 null 混进来" : "  ❌ 混进了脏数据"));
    }

    static String quote(String s) { return "【" + s + "】"; }

    public static void main(String[] args) throws Exception {
        if (args.length > 0 && "nulltest".equals(args[0])) { nullTest(); return; }
        boolean badKey = args.length > 0 && "badkey".equals(args[0]);
        String key = badKey ? "sk-invalidkey0000000000" : System.getenv("XJY_KEY");
        if (key == null || key.isEmpty()) { System.out.println("缺 XJY_KEY"); System.exit(2); }

        JSONObject body = new JSONObject();
        body.put("model", "deepseek-flash");
        body.put("temperature", 1.0);
        body.put("stream", true);
        JSONArray msgs = new JSONArray();
        msgs.put(new JSONObject().put("role", "system")
                .put("content", "你是『小鲸鱼』，温柔贴心、古灵精怪、暗恋傲娇。说话短、口语化，别端着。"));
        msgs.put(new JSONObject().put("role", "user").put("content", "在吗？"));
        body.put("messages", msgs);

        long t0 = System.currentTimeMillis();
        HttpURLConnection c = (HttpURLConnection) new URL(API_URL).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(20000);
        c.setReadTimeout(180000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        c.setRequestProperty("Accept", "text/event-stream");
        c.setRequestProperty("Authorization", "Bearer " + key);

        OutputStream os = c.getOutputStream();
        os.write(body.toString().getBytes("UTF-8"));
        os.flush();
        os.close();

        int code = c.getResponseCode();
        long tHeaders = System.currentTimeMillis() - t0;
        if (code != 200) {
            System.out.println("HTTP " + code + " (第一个字节前 " + tHeaders + "ms)");
            System.out.println("错误体: " + readAll(c.getErrorStream()));
            System.exit(badKey ? 0 : 1);
        }

        StringBuilder full = new StringBuilder();
        int deltas = 0;
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
        String line;
        while ((line = r.readLine()) != null) {
            if (!line.startsWith("data:")) continue;
            String payload = line.substring(5).trim();
            if (payload.isEmpty() || "[DONE]".equals(payload)) continue;
            String piece = deltaText(payload);
            if (piece.length() > 0) { full.append(piece); deltas++; }
        }
        long total = System.currentTimeMillis() - t0;
        System.out.println("HTTP 200，首字节 " + tHeaders + "ms，共 " + deltas + " 个增量，总耗时 " + total + "ms");
        System.out.println("解析得到的回复: " + full);
        System.out.println(full.length() > 0 ? "结果: 解析成功 ✅" : "结果: 空回复 ❌");
    }

    static String readAll(InputStream in) throws Exception {
        if (in == null) return "(空)";
        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String l;
        while ((l = r.readLine()) != null) sb.append(l);
        return sb.toString();
    }
}
