// 验证 deepseek-flash 收不收图片（OpenAI 风格的 image_url + data URL）
// 用法：XJY_KEY=sk-xxx java -cp json.jar:. VisionTest <图片路径>
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.*;
import java.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

public class VisionTest {
    public static void main(String[] args) throws Exception {
        String key = System.getenv("XJY_KEY");
        if (key == null || key.isEmpty()) { System.out.println("缺 XJY_KEY"); System.exit(2); }
        String img = args.length > 0 ? args[0] : null;
        if (img == null) { System.out.println("用法: VisionTest <图片路径>"); System.exit(2); }

        byte[] raw = Files.readAllBytes(Paths.get(img));
        String b64 = Base64.getEncoder().encodeToString(raw);
        String mime = img.toLowerCase().endsWith(".png") ? "image/png" : "image/jpeg";
        System.out.println("图片: " + img + "  " + raw.length + " 字节  base64 " + b64.length() + " 字符");

        JSONArray content = new JSONArray();
        content.put(new JSONObject().put("type", "text")
                .put("text", "用一句中文说：这张图里有什么？主要颜色是什么？"));
        content.put(new JSONObject().put("type", "image_url")
                .put("image_url", new JSONObject().put("url", "data:" + mime + ";base64," + b64)));

        JSONObject msg = new JSONObject().put("role", "user").put("content", content);
        JSONObject body = new JSONObject()
                .put("model", "deepseek-flash")
                .put("stream", true)
                .put("messages", new JSONArray().put(msg));

        HttpURLConnection c = (HttpURLConnection) new URL("https://api.deepseek.com/chat/completions").openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(20000);
        c.setReadTimeout(180000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        c.setRequestProperty("Accept", "text/event-stream");
        c.setRequestProperty("Authorization", "Bearer " + key);
        OutputStream os = c.getOutputStream();
        os.write(body.toString().getBytes("UTF-8"));
        os.flush(); os.close();

        int code = c.getResponseCode();
        long t0 = System.currentTimeMillis();
        if (code != 200) {
            System.out.println("HTTP " + code);
            BufferedReader er = new BufferedReader(new InputStreamReader(c.getErrorStream(), "UTF-8"));
            String l; while ((l = er.readLine()) != null) System.out.println(l);
            System.exit(1);
        }
        StringBuilder full = new StringBuilder();
        int deltas = 0;
        JSONObject usage = null;
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
        String line;
        while ((line = r.readLine()) != null) {
            if (!line.startsWith("data:")) continue;
            String p = line.substring(5).trim();
            if (p.isEmpty() || "[DONE]".equals(p)) continue;
            JSONObject j = new JSONObject(p);
            if (j.has("usage")) usage = j.optJSONObject("usage");
            JSONArray ch = j.optJSONArray("choices");
            if (ch == null || ch.length() == 0) continue;
            JSONObject d = ch.getJSONObject(0).optJSONObject("delta");
            if (d == null) continue;
            Object raw2 = d.opt("content");
            if (raw2 instanceof String && ((String) raw2).length() > 0) { full.append((String) raw2); deltas++; }
        }
        System.out.println("HTTP 200，用时 " + (System.currentTimeMillis() - t0) + "ms，增量 " + deltas);
        System.out.println("她的回答: " + full);
        if (usage != null) System.out.println("usage: " + usage);
        System.out.println(full.length() > 0 ? "结果: 图片输入可用 ✅" : "结果: 空回复 ❌");
    }
}
