// 在 JVM 上跑一遍和 MainActivity 里一样的「函数调用 →联网搜索 → 再问一轮」链路
// 用法：XJY_KEY=sk-xxx java -cp json.jar:. ToolLoopTest "你的问题"
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.*;
import java.util.regex.*;

import org.json.*;

public class ToolLoopTest {
    static final String API = "https://api.deepseek.com/chat/completions";
    static final String UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36";
    static final int MAX_ROUNDS = 2;

    public static void main(String[] args) throws Exception {
        String key = System.getenv("XJY_KEY");
        if (key == null || key.isEmpty()) { System.out.println("缺 XJY_KEY"); System.exit(2); }
        String question = args.length > 0 ? args[0] : "最近有什么 DeepSeek 的新闻？";

        JSONArray messages = new JSONArray()
                .put(new JSONObject().put("role", "system").put("content",
                        "你是小鲸鱼。遇到需要时效性的信息，用 web_search 工具查，别编。"))
                .put(new JSONObject().put("role", "user").put("content", question));

        for (int round = 0; round <= MAX_ROUNDS; round++) {
            JSONObject req = new JSONObject().put("model", "deepseek-flash").put("stream", true)
                    .put("messages", messages).put("tools", toolDefs());
            Map<Integer, JSONObject> calls = new TreeMap<>();
            StringBuilder content = new StringBuilder();
            oneRound(key, req, calls, content);

            if (calls.isEmpty()) {
                System.out.println("最终回答（第 " + (round + 1) + " 轮，未用工具）: " + content);
                return;
            }
            JSONArray callsForApi = new JSONArray(), toolMsgs = new JSONArray();
            for (JSONObject tc : calls.values()) {
                String name = tc.getJSONObject("function").optString("name");
                String argsRaw = tc.getJSONObject("function").optString("arguments", "{}");
                String query = argsRaw;
                try { query = new JSONObject(argsRaw).optString("query", argsRaw); } catch (Throwable ignored) { }
                String result;
                if ("web_search".equals(name)) {
                    System.out.println("→ 工具调用 web_search： " + query);
                    result = webSearch(query);
                    System.out.println("   搜到：" + result.split("\n")[0] + " …（" + result.length() + " 字）");
                } else if ("get_time".equals(name)) {
                    result = "手机当前时间：" + new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss EEEE", Locale.CHINA).format(new Date());
                    System.out.println("→ 工具调用 get_time");
                } else { result = "未知工具"; }
                callsForApi.put(new JSONObject().put("id", tc.optString("id")).put("type", "function")
                        .put("function", new JSONObject().put("name", name).put("arguments", argsRaw)));
                toolMsgs.put(new JSONObject().put("role", "tool").put("tool_call_id", tc.optString("id")).put("content", result));
            }
            messages.put(new JSONObject().put("role", "assistant").put("content", "").put("tool_calls", callsForApi));
            for (int i = 0; i < toolMsgs.length(); i++) messages.put(toolMsgs.get(i));
        }
        System.out.println("超过最大轮数");
    }

    static JSONArray toolDefs() throws Exception {
        return new JSONArray().put(new JSONObject().put("type", "function").put("function", new JSONObject()
                .put("name", "web_search").put("description", "联网搜索实时信息")
                .put("parameters", new JSONObject().put("type", "object")
                        .put("properties", new JSONObject().put("query", new JSONObject().put("type", "string")))
                        .put("required", new JSONArray().put("query")))));
    }

    /** 一轮流式请求；content 累积文本，calls 累积工具调用 */
    static void oneRound(String key, JSONObject req, Map<Integer, JSONObject> calls, StringBuilder content) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(API).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(20000);
        c.setReadTimeout(180000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        c.setRequestProperty("Accept", "text/event-stream");
        c.setRequestProperty("Authorization", "Bearer " + key);
        OutputStream os = c.getOutputStream();
        os.write(req.toString().getBytes("UTF-8"));
        os.flush(); os.close();
        if (c.getResponseCode() != 200) {
            BufferedReader er = new BufferedReader(new InputStreamReader(c.getErrorStream(), "UTF-8"));
            String l; while ((l = er.readLine()) != null) System.out.println(l);
            throw new RuntimeException("HTTP " + c.getResponseCode());
        }
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
        String line;
        while ((line = r.readLine()) != null) {
            if (!line.startsWith("data:")) continue;
            String p = line.substring(5).trim();
            if (p.isEmpty() || "[DONE]".equals(p)) continue;
            JSONObject j = new JSONObject(p);
            JSONArray ch = j.optJSONArray("choices");
            if (ch == null || ch.length() == 0) continue;
            JSONObject d = ch.getJSONObject(0).optJSONObject("delta");
            if (d == null) continue;
            Object raw = d.opt("content");
            if (raw instanceof String) content.append((String) raw);
            JSONArray tcs = d.optJSONArray("tool_calls");
            if (tcs != null) for (int i = 0; i < tcs.length(); i++) {
                JSONObject tc = tcs.getJSONObject(i);
                int idx = tc.optInt("index", i);
                JSONObject acc = calls.get(idx);
                if (acc == null) { acc = new JSONObject(); calls.put(idx, acc); }
                if (tc.has("id")) acc.put("id", tc.optString("id"));
                JSONObject fn = tc.optJSONObject("function");
                if (fn != null) {
                    JSONObject af = acc.optJSONObject("function");
                    if (af == null) { af = new JSONObject(); acc.put("function", af); }
                    if (fn.has("name")) af.put("name", fn.optString("name"));
                    if (fn.has("arguments")) af.put("arguments", af.optString("arguments", "") + fn.optString("arguments", ""));
                }
            }
        }
    }

    // ---- 和 MainActivity 里同一套 Bing 解析 ----
    static String webSearch(String query) throws Exception {
        String url = "https://cn.bing.com/search?q=" + URLEncoder.encode(query, "UTF-8") + "&setlang=zh-CN";
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(15000);
        c.setRequestProperty("User-Agent", UA);
        c.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9");
        if (c.getResponseCode() != 200) return "（搜索失败 HTTP " + c.getResponseCode() + "）";
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
        StringBuilder html = new StringBuilder();
        String l;
        while ((l = r.readLine()) != null && html.length() < 900000) html.append(l).append('\n');
        String parsed = parseBing(html.toString(), 6);
        return parsed.length() > 0 ? "以下是 Bing 搜索「" + query + "」的结果：\n" + parsed
                : "（没解析出结果）\n" + stripTags(html.toString()).substring(0, 800);
    }

    static String parseBing(String html, int max) {
        StringBuilder sb = new StringBuilder();
        String[] blocks = html.split("<li class=\"b_algo\"");
        int idx = 0;
        for (int i = 1; i < blocks.length && idx < max; i++) {
            String b = blocks[i];
            String title = match1(b, "<h2[^>]*>([\\s\\S]*?)</h2>");
            String snip = match1(b, "<p[^>]*>([\\s\\S]*?)</p>");
            String link = "";
            Matcher m = Pattern.compile("href=\"(https?://[^\"]+)\"").matcher(b);
            while (m.find()) {
                String u = m.group(1);
                if (!u.contains("bing.com") && !u.contains("microsoft.com") && !u.contains("msn.com")) { link = u; break; }
            }
            if ((title == null || title.trim().isEmpty()) && (snip == null || snip.trim().isEmpty())) continue;
            idx++;
            sb.append(idx).append(". ").append(title == null ? "" : stripTags(title)).append('\n');
            if (snip != null) sb.append("   摘要：").append(clip(stripTags(snip), 300)).append('\n');
            if (!link.isEmpty()) sb.append("   来源：").append(link).append('\n');
        }
        return sb.toString();
    }

    static String match1(String src, String re) {
        Matcher m = Pattern.compile(re, Pattern.DOTALL).matcher(src);
        return m.find() ? m.group(1) : null;
    }

    static String clip(String s, int n) { return s.length() <= n ? s : s.substring(0, n) + "…"; }

    static String stripTags(String html) {
        String s = html.replaceAll("(?is)<(script|style)[^>]*>[\\s\\S]*?</\\1>", " ");
        s = s.replaceAll("(?s)<[^>]+>", " ");
        s = s.replace("&nbsp;", " ").replace("&ensp;", " ").replace("&amp;", "&").replace("&quot;", "\"")
             .replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">");
        return s.replaceAll("\\s+", " ").trim();
    }
}
