// 手动解包 Termux .deb（ar + xz/tar），用于扩展安装器失败时的兜底
// 用法：node tools/extract-deb.mjs <deb 文件> <目标前缀目录>
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const [deb, dest] = process.argv.slice(2);
if (!deb || !dest) { console.error('usage: extract-deb.mjs <deb> <destPrefix>'); process.exit(1); }

const XZ = path.join(process.env.PREFIX, 'extensions/archivers/bin/xz');
const TAR = '/system/bin/tar';
// Termux 二进制写死了 /data/data/com.termux/files/usr/lib 的 RPATH，这里用 LD_LIBRARY_PATH 补上
const ENV = Object.assign({}, process.env, {
  LD_LIBRARY_PATH: [path.join(process.env.PREFIX, 'extensions/archivers/lib'), process.env.LD_LIBRARY_PATH].filter(Boolean).join(':'),
});

// ---- 解析 ar 归档 ----
const buf = fs.readFileSync(deb);
if (buf.slice(0, 8).toString() !== '!<arch>\n') throw new Error('不是 ar 归档');
let off = 8;
const members = [];
while (off + 60 <= buf.length) {
  const name = buf.slice(off, off + 16).toString().trim().replace(/\/$/, '');
  const size = parseInt(buf.slice(off + 48, off + 58).toString().trim(), 10);
  if (Number.isNaN(size)) break;
  const start = off + 60;
  members.push({ name, start, size });
  off = start + size + (size % 2);
}
const data = members.find((m) => /^data\.tar/.test(m.name));
if (!data) throw new Error('找不到 data.tar*：' + members.map((m) => m.name).join(','));

const tmpDir = fs.mkdtempSync(path.join(process.env.HOME, 'tmp/deb-'));
const raw = path.join(tmpDir, data.name);
fs.writeFileSync(raw, buf.slice(data.start, data.start + data.size));

let tarFile = raw;
if (/\.xz$/.test(data.name)) {
  tarFile = path.join(tmpDir, 'data.tar');
  execFileSync(XZ, ["-d", "-c", raw], { stdio: ["ignore", fs.openSync(tarFile, "w"), "inherit"], env: ENV });
} else if (/\.gz$/.test(data.name)) {
  tarFile = path.join(tmpDir, 'data.tar');
  execFileSync('/system/bin/gzip', ['-dc', raw], { stdio: ['ignore', fs.openSync(tarFile, 'w'), 'inherit'] });
} else if (/\.zst$/.test(data.name)) {
  throw new Error('zstd 还没支持');
}

fs.mkdirSync(dest, { recursive: true });
// Termux deb 里的路径是 data/data/com.termux/files/usr/... → 去掉前四段
execFileSync(TAR, ['-xf', tarFile, '-C', dest, '--strip-components=6'], { stdio: 'inherit' });
fs.rmSync(tmpDir, { recursive: true, force: true });
console.log('extracted', path.basename(deb), '->', dest);
