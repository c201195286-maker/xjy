<div align="center">

<img src="docs/icon.png" width="120" alt="小鲸鱼">

# 小鲸鱼 · XiaoJingYu

**一个只属于你自己的 AI 聊天 App —— 安卓单文件 APK，直连任意 OpenAI 兼容大模型。**

不绑服务商 · 人设随便改 · 能看图 · 能联网 · 有笔记本 · 有表情包 · 不用注册任何账号

[功能](#功能) · [下载安装](#下载安装) · [支持的服务商](#支持的服务商) · [隐私](#隐私) · [自己编译](#自己编译) · [开发笔记](docs/DEVNOTES.md)

</div>

---

## 功能

- 🎭 **多角色，随时切换**：内置 6 个 —— 小鲸鱼（温柔贴心·古灵精怪·暗恋傲娇）、温柔姐姐、毒舌损友、元气少女、冷静学霸、正经助手；
  还能**自建角色**（名字 / emoji 头像 / 人设随你写）。**点右上角头像就能切**
- 🗂 **每个角色各自独立**：聊天记录、长期记忆都是分开的（切过去是干净的另一个人）；笔记本和表情包共用
- 💬 **流式回复**：字一个个蹦出来，跟真人打字一样；聊天记录存在手机本地
- 🧠 **长期记忆**：超窗的老对话自动压成「往事」摘要；再加一本**可检索的笔记本**（她需要时才查，只把命中的几条喂给模型 —— 这是省 token 的关键）
- 🔍 **联网搜索**：真·function calling，她自己决定要不要搜（新闻/天气/价格），界面会显示「正在搜：xxx」；也能看当前时间
- 🖼 **能看图**：发照片、截图、表情包都行；**GIF 动图你看到的是动的**，她看首帧
- 📄 **能读文本文件**：txt / md / json / csv / 代码，直接当文字发给她
- 😊 **表情面板**：70 个常用 emoji + **「我的表情包」**（内置 16 张，也能把你喜欢的图加进去，点一下直接发）
- 🎨 **自定义聊天背景**：选张图当背景，配一个「压暗」滑块保证字看得清
- 🔌 **多服务商**：DeepSeek / OpenAI / Kimi / 智谱 / 通义千问 / SiliconFlow / OpenRouter / 本地 Ollama / 任意自定义接口
- 🌏 **中英文界面**：设置 → 语言 / Language，一键切换；内置角色连**人设也是双语**的（英文界面下她用英文跟你聊）
- 🔄 **更新检查**：默认盯着本项目的 Releases（可在设置里改成你自己的仓库），启动时静默检查、设置里也能手动查；发现新版给一个可点的下载链接
- 🖼 **角色头像可换成图片**：不想用 emoji 就从相册选一张
- 📤 **聊天记录导出**：Markdown 格式，走系统"保存到"，不需要任何存储权限；可导出单个角色或全部
- 🔒 **只有联网权限**，没有自己的服务器，不收集任何数据；**构建产物里不含任何 API Key**

<div align="center">
<img src="docs/screenshots/chat.jpg" width="45%" alt="聊天">
&nbsp;&nbsp;
<img src="docs/screenshots/settings.jpg" width="45%" alt="设置">
</div>

## 下载安装

1. 到 [Releases](../../releases) 下载 `小鲸鱼.apk`（或自己编译，见下）
2. 手机点开安装（可能要在系统设置里允许「未知来源」）
3. 第一次打开会自动弹出设置页：**选服务商 → 填你自己的 API Key → 点「测试连接」**（页面上有「去申请」按钮，DeepSeek 充 10 块钱能用很久）
4. 开聊 🐳

> 支持 Android 5.0 (API 21) 及以上。APK 约 850 KB。

## 角色

| 角色 | 性格 |
|---|---|
| 🐳 小鲸鱼 | 温柔贴心 · 古灵精怪 · 暗恋傲娇（默认） |
| 🌙 温柔姐姐 | 成熟、耐心、会照顾人 |
| 😏 毒舌损友 | 嘴毒爱吐槽，关键时刻靠得住 |
| 🌞 元气少女 | 话多跳脱、永远在兴头上 |
| 📚 冷静学霸 | 准确、有条理、不废话 |
| ✨ 自建 | 名字、头像（emoji 或图片）、人设你自己写 |
| 🤖 正经助手 | 专业可靠、直接给结论 |

> 切换方式：点聊天页**右上角的头像/名字** → 选角色。每个角色的聊天记录和记忆分开存，笔记本共用。

## 支持的服务商

只要是 **OpenAI 兼容**的 `/chat/completions` 接口都能用。内置了这些预设（也可以选「自定义」自己填地址）：

| 服务商 | 默认接口地址 | 看图 | 工具调用（联网/笔记本） |
|---|---|:--:|:--:|
| DeepSeek（默认） | `https://api.deepseek.com` | ✅ | ✅ |
| OpenAI | `https://api.openai.com/v1` | ✅ | ✅ |
| Moonshot（Kimi） | `https://api.moonshot.cn/v1` | ✅ | ✅ |
| 智谱 GLM | `https://open.bigmodel.cn/api/paas/v4` | ✅ | ✅ |
| 通义千问（DashScope） | `https://dashscope.aliyuncs.com/compatible-mode/v1` | ✅ | ✅ |
| SiliconFlow | `https://api.siliconflow.cn/v1` | ❌ | ✅ |
| OpenRouter | `https://openrouter.ai/api/v1` | ✅ | ✅ |
| 本地 Ollama | `http://127.0.0.1:11434/v1` | ❌ | ❌ |
| 自定义 | 自己填 | 可勾 | 可勾 |

「看图 / 工具调用」能力会自动跟着服务商走，也能在设置里手动勾（比如某个模型不支持工具，关掉就不会发 `tools` 参数）。

> ⚠️ **明文 HTTP 只对 127.0.0.1 / localhost 放行**（为了本地 Ollama），局域网里的 `http://192.168.x.x:11434` 会被系统拦下 —— 这是安全考虑。

## 隐私

- 你的聊天内容**只发给你自己选的服务商**；联网搜索的**查询词发往 Bing**（`cn.bing.com`）
- 本应用**没有自己的服务器**，不上传、不收集任何数据
- API Key 只存在手机本地（Android SharedPreferences）
- 「本机诊断上报」默认**关闭**，开了也只发往 `127.0.0.1`（开发用）
- 图片、贴纸、背景、笔记本都存在 app 私有目录，卸载即删除

## 自己编译

需要 JDK 17+、以及 Android 的 `aapt` / `d8` / `apksigner`（`zipalign` 可选），再准备一个 `android.jar`：

```sh
# 一次性：把工具链放到 PATH（或改 build.sh 里的探测路径）
export ANDROID_JAR=/path/to/android.jar

cd xiaojingyu-app
bash build.sh          # 编译 + 签名 + zipalign → 产出 APK
bash build.sh --check  # 只检查工具链，不编译
```

- 第一次跑会自动生成自签名的 `android/xiaojingyu.keystore`（**这个文件不要提交到仓库**，已在 `.gitignore` 里）
- 产出：`build/xiaojingyu.apk`
- **本应用永远不内置 API Key**（`tools/gen-keys.mjs` 生成的常量恒为空串）—— 谁用谁在设置里填，代码里没有第二条路

## 工程结构

| 路径 | 作用 |
|---|---|
| `app/` | 网页部分：`index.html` / `app.js` / `style.css` / 头像 / `stickers/`（内置表情包） |
| `android/` | `AndroidManifest.xml`、`MainActivity.java`（WebView 壳 + Java↔JS 桥 + 网络与工具调用）、`res/` 图标 |
| `tools/` | 图标与表情生成、Termux deb 抓取/解包、`smoke-test.mjs`（jsdom 冒烟测试 100+ 项）、`memory-test.mjs` |
| `build.sh` | 一键编译 + 签名 |
| `docs/` | [开发笔记 / 踩坑记录](docs/DEVNOTES.md)、截图 |

## 设计取舍（为什么这么写）

- **网络请求放在 Java 侧**（`HttpURLConnection` + SSE 解析），不走网页 `fetch`：绕过 WebView 对 `file://` 的跨域限制，API Key 也不出现在网页脚本里
- **聊天记录走原生 SharedPreferences**：`file://` 页面的 localStorage 在部分机型重启就清空
- **联网搜索用 Bing**：DuckDuckGo 在国内不可达
- **笔记本用本地关键词检索**（中文 2 字滑窗 + 整串匹配打分），只把命中的前几条喂给模型，而不是整本塞进上下文

英文一句话版：*A tiny on-device Android chat client for any OpenAI-compatible LLM — persona, vision, web search, notebook memory, sticker pack, custom background. No account, no server, MIT licensed.*

## 仓库

<https://github.com/c201195286-maker/xjy>

## License

[MIT](LICENSE)

> 「小鲸鱼」这个名字和默认人设只是示例，随便改成你自己的角色。
> 使用第三方大模型服务时请遵守对应服务商的条款；联网搜索抓取的是公开搜索结果页。
