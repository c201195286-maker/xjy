package app.xiaojingyu.chat;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.util.Base64;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JsResult;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 小鲸鱼 —— 一个只有聊天的最小壳。
 * 网络请求放在 Java 侧（不走网页的 fetch），既避开 WebView 的跨域限制，
 * 也让 API key 不出现在网页脚本里。
 */
public class MainActivity extends Activity {

    private static final String API_URL = "https://api.deepseek.com/chat/completions";
    private static final int REQ_PICK_IMAGE = 1001;
    private static final int REQ_PICK_FILE = 1002;
    private static final int REQ_ADD_STICKER = 1003;
    private static final int REQ_PICK_BG = 1004;
    private static final int REQ_PICK_CHAR_AVATAR = 1005;
    private static final int REQ_EXPORT = 1006;
    private static final int MAX_AVATAR_SIDE = 256;
    private static final int MAX_BG_SIDE = 1440;     // 聊天背景不用太大，省内存
    private static final int MAX_STICKER_SIDE = 400;    // 贴纸不用太大
    private static final int MAX_GIF_BYTES = 4 * 1024 * 1024;   // 动图超过 4MB 就退化成静态图
    private static final int MAX_TOOL_ROUNDS = 2;               // 最多连续查两轮，防死循环
    private static final int MAX_CALLS_PER_ROUND = 3;           // 一轮最多执行 3 条查询，别一次搜十条
    private static final String UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36";
    private static final int MAX_IMAGE_SIDE = 1280;      // 长边上限，够看清又不至于太贵
    private static final int MAX_TEXT_CHARS = 60000;     // 文本文件最多读这么多字

    private WebView web;
    private TextToSpeech tts;
    private volatile HttpURLConnection live;
    private volatile String pendingExport = "";
    private final AtomicBoolean stopFlag = new AtomicBoolean(false);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(0xFF061423);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        try {
            s.setAllowFileAccessFromFileURLs(true);
            s.setAllowUniversalAccessFromFileURLs(true);
        } catch (Throwable ignored) { }
        web.setWebViewClient(new WebViewClient());
        // 网页里的 alert/confirm 在默认 WebChromeClient 下是"哑巴"（confirm 恒返回 false），
        // 所以自己用系统对话框实现 —— 否则所有"删除确认"都点不动。
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setCancelable(false)
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) { result.confirm(); }
                        })
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setCancelable(false)
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) { result.confirm(); }
                        })
                        .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) { result.cancel(); }
                        })
                        .show();
                return true;
            }
        });
        // 关掉 WebView 的"强制深色"：它会把深色页面里的输入框文字反色成看不见
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                s.setAlgorithmicDarkeningAllowed(false);
            } else if (Build.VERSION.SDK_INT >= 29) {
                s.setForceDark(WebSettings.FORCE_DARK_OFF);
            }
        } catch (Throwable ignored) { }
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");

        setContentView(web);

        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    try {
                        tts.setLanguage(Locale.CHINA);
                        tts.setSpeechRate(1.05f);
                        tts.setPitch(1.15f);
                    } catch (Throwable ignored) { }
                }
            }
        });
    }

    // ---------------- 网页可调用的桥 ----------------

    private class Bridge {

        @JavascriptInterface
        public void startChat(final String reqJson) {
            stopFlag.set(false);
            new Thread(new Runnable() {
                @Override public void run() { stream(reqJson); }
            }, "xjy-chat").start();
        }

        @JavascriptInterface
        public void stop() {
            stopFlag.set(true);
            HttpURLConnection c = live;
            if (c != null) {
                try { c.disconnect(); } catch (Throwable ignored) { }
            }
        }

        @JavascriptInterface
        public void speak(final String text) {
            if (tts == null || text == null || text.length() == 0) return;
            try { tts.speak(text, TextToSpeech.QUEUE_FLUSH, null); } catch (Throwable ignored) { }
        }

        @JavascriptInterface
        public void stopSpeak() {
            if (tts != null) { try { tts.stop(); } catch (Throwable ignored) { } }
        }

        @JavascriptInterface
        public String appVersion() {
            try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
            catch (Throwable e) { return "1.0.0"; }
        }

        /** 网页用来判断是否需要提示用户填 key（分享版没有内置 key）。 */
        @JavascriptInterface
        public boolean hasBuiltinKey() {
            return Keys.API_KEY != null && Keys.API_KEY.trim().length() > 0;
        }

        /** 让手机浏览器打开链接（申请 API Key 用）。 */
        /** 选一张图片（会走视觉模型） */
        @JavascriptInterface
        public void pickImage() { openPicker("image/*", REQ_PICK_IMAGE); }

        /** 选一个文本文件（读进来当文字发） */
        @JavascriptInterface
        public void pickFile() { openPicker("*/*", REQ_PICK_FILE); }

        /** 把一张图加进"我的表情包" */
        @JavascriptInterface
        public void addSticker() { openPicker("image/*", REQ_ADD_STICKER); }

        /** 选一张聊天背景图 */
        @JavascriptInterface
        public void pickBackground() { openPicker("image/*", REQ_PICK_BG); }

        /** 给当前角色选一张头像图 */
        @JavascriptInterface
        public void pickCharAvatar() { openPicker("image/*", REQ_PICK_CHAR_AVATAR); }

        /** 清掉角色头像图 */
        @JavascriptInterface
        public void clearCharAvatar() {
            try {
                File[] fs2 = new File(getFilesDir(), "chars").listFiles();
                if (fs2 != null) for (File f : fs2) f.delete();
            } catch (Throwable ignored) { }
            jsCharAvatar("");
        }

        /** 通用 GET（更新检查用；返回文本，走 window.__onHttp 回调） */
        @JavascriptInterface
        public void httpGet(String url, String reqId) { httpGetAsync(url, reqId); }

        /** 导出文本（走系统"保存到"对话框，不需要任何存储权限） */
        @JavascriptInterface
        public void exportText(final String filename, final String content) {
            pendingExport = content == null ? "" : content;
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("text/markdown");
                        i.putExtra(Intent.EXTRA_TITLE, filename == null ? "chat.md" : filename);
                        startActivityForResult(i, REQ_EXPORT);
                    } catch (Throwable e) {
                        jsExportResult(false, "打不开保存对话框：" + e.getMessage());
                    }
                }
            });
        }

        /** 恢复默认背景 */
        @JavascriptInterface
        public void clearBackground() {
            try {
                File[] fs2 = new File(getFilesDir(), "bg").listFiles();
                if (fs2 != null) for (File f : fs2) f.delete();
            } catch (Throwable ignored) { }
            jsBackground("");
        }

        /** 当前背景（重装/重启后网页用它恢复） */
        @JavascriptInterface
        public String currentBackground() {
            try {
                File[] fs2 = new File(getFilesDir(), "bg").listFiles();
                if (fs2 != null) for (File f : fs2) if (f.isFile()) return "file://" + f.getAbsolutePath();
            } catch (Throwable ignored) { }
            return "";
        }

        /** 列出"我的表情包"（同步返回 JSON） */
        @JavascriptInterface
        public String listStickers() { return stickersJson(); }

        /** 笔记本：列出 / 搜索 / 手动加 / 删除 */
        @JavascriptInterface
        public String listNotes() { return listNotesJson(); }

        @JavascriptInterface
        public String searchNotes(String query) { return searchNotesArray(query, 50).toString(); }

        @JavascriptInterface
        public String addNote(String text) {
            addNoteInternal(text);
            return listNotesJson();
        }

        @JavascriptInterface
        public String deleteNote(long t) {
            try {
                JSONArray all = readNotes();
                StringBuilder sb = new StringBuilder();
                for (int i = all.length() - 1; i >= 0; i--) {   // 按写入顺序重写
                    JSONObject o = all.getJSONObject(i);
                    if (o.optLong("t") == t) continue;
                    sb.append(o.toString()).append('\n');
                }
                FileOutputStream fos = new FileOutputStream(notesFile(), false);
                fos.write(sb.toString().getBytes("UTF-8"));
                fos.close();
            } catch (Throwable ignored) { }
            return listNotesJson();
        }

        /** 删掉一张贴纸 */
        @JavascriptInterface
        public String deleteSticker(String path) {
            try {
                File f = new File(path);
                File dir = new File(getFilesDir(), "stickers");
                if (f.getParentFile() != null && f.getParentFile().getAbsolutePath().equals(dir.getAbsolutePath())) f.delete();
            } catch (Throwable ignored) { }
            return stickersJson();
        }

        /** 历史里的图片需要重新读出 base64 时用（带 reqId 回调） */
        @JavascriptInterface
        public void readAsDataUrl(final String path, final String reqId) {
            new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        String url = staticDataUrl(path, MAX_IMAGE_SIDE);
                        runJs("window.__onDataUrl(" + JSONObject.quote(reqId) + "," + (url == null ? "null" : JSONObject.quote(url)) + ")");
                    } catch (Throwable e) {
                        runJs("window.__onDataUrl(" + JSONObject.quote(reqId) + ",null)");
                    }
                }
            }).start();
        }

        @JavascriptInterface
        public void openUrl(final String url) {
            if (url == null || url.length() == 0) return;
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Throwable ignored) { }
                }
            });
        }

        /** 原生键值存储：file:// 页面的 localStorage 不保证持久，聊天记录放这里更稳。 */
        @JavascriptInterface
        public String kvGet(String key) {
            try { return getSharedPreferences("xjy", MODE_PRIVATE).getString(key, ""); }
            catch (Throwable e) { return ""; }
        }

        @JavascriptInterface
        public void kvSet(String key, String value) {
            try {
                getSharedPreferences("xjy", MODE_PRIVATE).edit().putString(key, value == null ? "" : value).apply();
            } catch (Throwable ignored) { }
        }
    }

    // ---------------- 选图片 / 选文件 ----------------

    private void openPicker(final String mime, final int req) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType(mime);
                    startActivityForResult(i, req);
                } catch (Throwable e) {
                    jsAttachmentError("打不开选择器：" + e.getMessage());
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_EXPORT) { writeExport(res == RESULT_OK && data != null ? data.getData() : null); return; }
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    if (req == REQ_PICK_IMAGE) attachImage(uri);
                    else if (req == REQ_ADD_STICKER) saveSticker(uri);
                    else if (req == REQ_PICK_BG) saveBackground(uri);
                    else if (req == REQ_PICK_CHAR_AVATAR) saveCharAvatar(uri);
                    else attachText(uri);
                } catch (Throwable e) {
                    jsAttachmentError(String.valueOf(e.getMessage()));
                }
            }
        }, "xjy-attach").start();
    }

    /** 图片：缩到长边 1280 以内、压成 JPEG，存到私有目录，并把 base64 一并给网页 */
    private void attachImage(Uri uri) throws Exception {
        byte[] raw = readBytes(getContentResolver().openInputStream(uri));
        if (looksLikeGif(raw) && raw.length <= MAX_GIF_BYTES) {   // 动图：原样留着（app 里会动）
            File dir = new File(getFilesDir(), "img");
            if (!dir.exists()) dir.mkdirs();
            File out = new File(dir, "img-" + System.currentTimeMillis() + ".gif");
            FileOutputStream fos = new FileOutputStream(out);
            fos.write(raw);
            fos.close();
            JSONObject og = new JSONObject();
            og.put("kind", "image");
            og.put("path", out.getAbsolutePath());
            og.put("name", displayName(uri));
            og.put("bytes", raw.length);
            og.put("gif", true);
            og.put("dataUrl", staticDataUrl(out.getAbsolutePath(), MAX_IMAGE_SIDE));  // 给模型看首帧
            jsAttachment(og.toString());
            return;
        }
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(raw, 0, raw.length, bounds);
        int sample = 1;
        int longSide = Math.max(bounds.outWidth, bounds.outHeight);
        while (longSide / sample > MAX_IMAGE_SIDE * 2) sample *= 2;
        BitmapFactory.Options opt = new BitmapFactory.Options();
        opt.inSampleSize = sample;
        Bitmap bmp = BitmapFactory.decodeByteArray(raw, 0, raw.length, opt);
        if (bmp == null) throw new Exception("这张图解不开（格式可能不支持）");
        int w = bmp.getWidth(), h = bmp.getHeight();
        float scale = Math.min(1f, (float) MAX_IMAGE_SIDE / Math.max(w, h));
        if (scale < 1f) bmp = Bitmap.createScaledBitmap(bmp, Math.round(w * scale), Math.round(h * scale), true);

        File dir = new File(getFilesDir(), "img");
        if (!dir.exists()) dir.mkdirs();
        File out = new File(dir, "img-" + System.currentTimeMillis() + ".jpg");
        FileOutputStream fos = new FileOutputStream(out);
        bmp.compress(Bitmap.CompressFormat.JPEG, 82, fos);
        fos.close();

        byte[] jpg = readBytes(new FileInputStream(out));
        String b64 = Base64.encodeToString(jpg, Base64.NO_WRAP);
        JSONObject o = new JSONObject();
        o.put("kind", "image");
        o.put("path", out.getAbsolutePath());
        o.put("name", displayName(uri));
        o.put("bytes", jpg.length);
        o.put("w", bmp.getWidth());
        o.put("h", bmp.getHeight());
        o.put("dataUrl", "data:image/jpeg;base64," + b64);
        jsAttachment(o.toString());
    }

    /** 暴露给模型的工具 */
    private JSONArray toolDefs() {
        JSONArray tools = new JSONArray();
        try {
            JSONArray params = new JSONArray()
                    .put(new JSONObject().put("type", "object")
                            .put("properties", new JSONObject().put("query", new JSONObject().put("type", "string").put("description", "搜索关键词")))
                            .put("required", new JSONArray().put("query")));
            tools.put(new JSONObject().put("type", "function").put("function", new JSONObject()
                    .put("name", "web_search").put("description", "联网搜索实时信息（新闻、天气、价格、比分、最近发生的事）。需要时效性信息时必须用这个，不要凭记忆编。")
                    .put("parameters", params.getJSONObject(0))));
            tools.put(new JSONObject().put("type", "function").put("function", new JSONObject()
                    .put("name", "get_time").put("description", "获取手机当前日期和时间")
                    .put("parameters", new JSONObject().put("type", "object").put("properties", new JSONObject()))));
            tools.put(new JSONObject().put("type", "function").put("function", new JSONObject()
                    .put("name", "remember").put("description", "把关于用户的一件值得长期记住的事写进你的笔记本（比如喜好、约定、重要经历、他明确让你记住的事）。一条一句话，别写成长段落。")
                    .put("parameters", new JSONObject().put("type", "object")
                            .put("properties", new JSONObject().put("note", new JSONObject().put("type", "string").put("description", "一句话笔记")))
                            .put("required", new JSONArray().put("note")))));
            tools.put(new JSONObject().put("type", "function").put("function", new JSONObject()
                    .put("name", "search_notes").put("description", "在你的笔记本里检索往事/细节。需要回忆具体事情（名字、喜好、约定、以前聊过的细节）时用它，而不是凭印象猜。")
                    .put("parameters", new JSONObject().put("type", "object")
                            .put("properties", new JSONObject().put("query", new JSONObject().put("type", "string").put("description", "检索关键词")))
                            .put("required", new JSONArray().put("query")))));
        } catch (Throwable ignored) { }
        return tools;
    }

    /** 当前时间（本地时区） */
    private String nowString() {
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss EEEE", java.util.Locale.CHINA);
        return "手机当前时间：" + f.format(new java.util.Date());
    }

    /** 联网搜索：Bing 国内站，抓前几条标题+摘要 */
    private String webSearch(String query) {
        try {
            String url = "https://cn.bing.com/search?q=" + java.net.URLEncoder.encode(query, "UTF-8") + "&setlang=zh-CN";
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(12000);
            c.setReadTimeout(15000);
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9");
            c.setInstanceFollowRedirects(true);
            int code = c.getResponseCode();
            if (code != 200) return "（搜索失败：HTTP " + code + "）";
            String html = readLimited(c.getInputStream(), 900000);
            String parsed = parseBing(html, 6);
            if (parsed.length() > 0) return "以下是 Bing 搜索「" + query + "」的结果：\n" + parsed;
            String plain = stripTags(html);
            return "（没解析出结构化结果，以下是页面纯文本片段）\n" + plain.substring(0, Math.min(1800, plain.length()));
        } catch (Throwable e) {
            return "（搜索失败：" + e.getMessage() + "）";
        }
    }

    private static String readLimited(InputStream in, int max) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0 && bos.size() < max) bos.write(buf, 0, n);
        in.close();
        return new String(bos.toByteArray(), "UTF-8");
    }

    /** 从 Bing 结果页里抠出标题/摘要/链接 */
    private static String parseBing(String html, int max) {
        StringBuilder sb = new StringBuilder();
        String[] blocks = html.split("<li class=\"b_algo\"");
        int idx = 0;
        for (int i = 1; i < blocks.length && idx < max; i++) {
            String b = blocks[i];
            String title = match1(b, "<h2[^>]*>([\\s\\S]*?)</h2>");
            String snip = match1(b, "<p[^>]*>([\\s\\S]*?)</p>");
            String link = "";
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("href=\"(https?://[^\"]+)\"").matcher(b);
            while (m.find()) {
                String u = m.group(1);
                if (!u.contains("bing.com") && !u.contains("microsoft.com") && !u.contains("msn.com")) { link = u; break; }
            }
            if ((title == null || title.trim().isEmpty()) && (snip == null || snip.trim().isEmpty())) continue;
            idx++;
            sb.append(idx).append(". ").append(title == null ? "" : stripTags(title)).append("\n");
            if (snip != null) sb.append("   摘要：").append(clip(stripTags(snip), 300)).append("\n");
            if (link.length() > 0) sb.append("   来源：").append(link).append("\n");
        }
        return sb.toString();
    }

    private static String match1(String src, String re) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(re, java.util.regex.Pattern.DOTALL).matcher(src);
        return m.find() ? m.group(1) : null;
    }

    private static String clip(String s, int n) { return s.length() <= n ? s : s.substring(0, n) + "…"; }

    /** 粗略去标签 + 常见实体 */
    private static String stripTags(String html) {
        String s = html.replaceAll("(?is)<(script|style)[^>]*>[\\s\\S]*?</\\1>", " ");
        s = s.replaceAll("(?s)<[^>]+>", " ");
        s = s.replace("&nbsp;", " ").replace("&ensp;", " ").replace("&amp;", "&").replace("&quot;", "\"")
             .replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">");
        return s.replaceAll("\\s+", " ").trim();
    }

    // ---------------- 笔记本（本地 JSONL，一条一句） ----------------

    private File notesFile() { return new File(getFilesDir(), "notes.jsonl"); }

    /** 读全部笔记（新→旧，最多 500 条） */
    private JSONArray readNotes() {
        JSONArray arr = new JSONArray();
        try {
            File f = notesFile();
            if (!f.exists()) return arr;
            BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"));
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                try { arr.put(new JSONObject(line)); } catch (Throwable ignored) { }
            }
            r.close();
        } catch (Throwable ignored) { }
        // 反转成新→旧
        JSONArray out = new JSONArray();
        for (int i = arr.length() - 1; i >= 0; i--) {
            try { out.put(arr.get(i)); } catch (Throwable ignored) { }
        }
        while (out.length() > 500) out.remove(out.length() - 1);
        return out;
    }

    /** 写一条（去重：同样内容不重复记） */
    private boolean addNoteInternal(String text) {
        if (text == null) return false;
        final String clean = text.trim().replaceAll("\\s+", " ");
        if (clean.isEmpty()) return false;
        try {
            JSONArray all = readNotes();
            for (int i = 0; i < all.length(); i++) {
                if (clean.equals(all.getJSONObject(i).optString("text", ""))) return false;
            }
            JSONObject o = new JSONObject().put("t", System.currentTimeMillis()).put("text", clean);
            FileOutputStream fos = new FileOutputStream(notesFile(), true);
            fos.write((o.toString() + "\n").getBytes("UTF-8"));
            fos.close();
            return true;
        } catch (Throwable e) {
            return false;
        }
    }

    /** 笔记列表 JSON（Activity 方法，桥和内部逻辑共用） */
    private String listNotesJson() {
        JSONArray all = readNotes();
        JSONArray out = new JSONArray();
        for (int i = 0; i < all.length(); i++) {
            try {
                JSONObject o = all.getJSONObject(i);
                out.put(new JSONObject().put("t", o.optLong("t")).put("text", o.optString("text", "")));
            } catch (Throwable ignored) { }
        }
        return out.toString();
    }

    /** 本地关键词检索：中文按 2 字滑窗 + 整串匹配打分，只返回命中的前几条 —— 不整本塞给模型 */
    private String searchNotesText(String query) {
        JSONArray hits = searchNotesArray(query, 5);
        if (hits.length() == 0) return "（笔记本里没有相关记录）";
        StringBuilder sb = new StringBuilder("笔记本里找到 " + hits.length() + " 条相关记录：\n");
        for (int i = 0; i < hits.length(); i++) {
            try { sb.append("- ").append(hits.getJSONObject(i).optString("text", "")).append("\n"); }
            catch (Throwable ignored) { }
        }
        return sb.toString();
    }

    private JSONArray searchNotesArray(String query, int limit) {
        JSONArray out = new JSONArray();
        final String q = query == null ? "" : query.trim().toLowerCase();
        if (q.isEmpty()) return out;
        java.util.List<String> terms = new java.util.ArrayList<>();
        terms.add(q);
        for (int i = 0; i + 2 <= q.length(); i++) terms.add(q.substring(i, i + 2));   // 中文二元组
        for (String piece : q.split("[\\s,，。!！?？、]+")) if (piece.length() >= 2) terms.add(piece);
        JSONArray all = readNotes();
        java.util.List<Object[]> scored = new java.util.ArrayList<>();
        for (int i = 0; i < all.length(); i++) {
            JSONObject o;
            try { o = all.getJSONObject(i); } catch (Throwable ignored) { continue; }
            String text = o.optString("text", "");
            String low = text.toLowerCase();
            int score = 0;
            for (String term : terms) {
                if (term.isEmpty()) continue;
                int from = 0, c = 0;
                while (true) {
                    int idx = low.indexOf(term, from);
                    if (idx < 0) break;
                    c++;
                    from = idx + term.length();
                    if (c > 5) break;
                }
                if (c > 0) score += c * (term.length() >= 3 ? 3 : 1);   // 长词权重更高
            }
            if (low.contains(q)) score += 10;
            if (score > 0) scored.add(new Object[] { score, o });
        }
        scored.sort(new java.util.Comparator<Object[]>() {
            @Override public int compare(Object[] a, Object[] b) { return ((Integer) b[0]) - ((Integer) a[0]); }
        });
        for (int i = 0; i < scored.size() && i < limit; i++) out.put(scored.get(i)[1]);
        return out;
    }

    /** 是不是 GIF（看魔数，比 mime 可靠） */
    private static boolean looksLikeGif(byte[] b) {
        return b != null && b.length > 6 && b[0] == 'G' && b[1] == 'I' && b[2] == 'F' && b[3] == '8';
    }

    /** 把图片文件转成"给模型看的静态首帧"data URL（动图自动取第一帧；PNG 保留透明） */
    private String staticDataUrl(String file, int maxSide) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file, o);
            int sample = 1;
            int longSide = Math.max(o.outWidth, o.outHeight);
            while (longSide / sample > maxSide * 2) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            Bitmap bmp = BitmapFactory.decodeFile(file, o2);
            if (bmp == null) return null;
            int w = bmp.getWidth(), h = bmp.getHeight();
            float scale = Math.min(1f, (float) maxSide / Math.max(w, h));
            if (scale < 1f) bmp = Bitmap.createScaledBitmap(bmp, Math.round(w * scale), Math.round(h * scale), true);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.PNG, 100, bos);
            return "data:image/png;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
        } catch (Throwable e) {
            return null;
        }
    }

    /** 列出贴纸目录（Activity 方法，内部逻辑也能用） */
    private String stickersJson() {
        installBuiltinStickers();
        JSONArray arr = new JSONArray();
        try {
            File dir = new File(getFilesDir(), "stickers");
            File[] fs2 = dir.listFiles();
            if (fs2 != null) {
                java.util.Arrays.sort(fs2, new java.util.Comparator<File>() {
                    @Override public int compare(File a, File b) { return Long.compare(b.lastModified(), a.lastModified()); }
                });
                for (File f : fs2) {
                    if (!f.isFile()) continue;
                    arr.put(new JSONObject().put("path", f.getAbsolutePath()).put("name", f.getName()).put("bytes", f.length()));
                }
            }
        } catch (Throwable ignored) { }
        return arr.toString();
    }

    /** 把 APK 里内置的那套表情包释放到私有目录（只做一次；用户删掉后不会再塞回来） */
    private void installBuiltinStickers() {
        try {
            android.content.SharedPreferences sp = getSharedPreferences("xjy", MODE_PRIVATE);
            if (sp.getBoolean("builtinStickersInstalled", false)) return;
            File dir = new File(getFilesDir(), "stickers");
            if (!dir.exists()) dir.mkdirs();
            String[] files = getAssets().list("stickers");
            if (files != null) {
                for (String name : files) {
                    File out = new File(dir, name);
                    if (out.exists()) continue;
                    InputStream in = getAssets().open("stickers/" + name);
                    FileOutputStream os = new FileOutputStream(out);
                    byte[] buf = new byte[16384];
                    int k;
                    while ((k = in.read(buf)) > 0) os.write(buf, 0, k);
                    in.close();
                    os.close();
                }
            }
            sp.edit().putBoolean("builtinStickersInstalled", true).apply();
        } catch (Throwable ignored) { }
    }

    /** 把待导出的内容写进用户选的 Uri */
    private void writeExport(final Uri uri) {
        if (uri == null) { jsExportResult(false, "cancel"); return; }
        final String text = pendingExport == null ? "" : pendingExport;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    OutputStream os = getContentResolver().openOutputStream(uri);
                    os.write(text.getBytes("UTF-8"));
                    os.flush();
                    os.close();
                    jsExportResult(true, uri.toString());
                } catch (Throwable e) {
                    jsExportResult(false, String.valueOf(e.getMessage()));
                }
            }
        }).start();
    }

    /** 角色头像：缩到 256 以内存成 JPEG */
    private void saveCharAvatar(Uri uri) throws Exception {
        byte[] raw = readBytes(getContentResolver().openInputStream(uri));
        BitmapFactory.Options b = new BitmapFactory.Options();
        b.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(raw, 0, raw.length, b);
        int sample = 1;
        int longSide = Math.max(b.outWidth, b.outHeight);
        while (longSide / sample > MAX_AVATAR_SIDE * 2) sample *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = sample;
        Bitmap bmp = BitmapFactory.decodeByteArray(raw, 0, raw.length, o2);
        if (bmp == null) throw new Exception("这张图解不开");
        int w = bmp.getWidth(), h = bmp.getHeight();
        float scale = Math.min(1f, (float) MAX_AVATAR_SIDE / Math.max(w, h));
        if (scale < 1f) bmp = Bitmap.createScaledBitmap(bmp, Math.round(w * scale), Math.round(h * scale), true);
        File dir = new File(getFilesDir(), "chars");
        if (!dir.exists()) dir.mkdirs();
        File[] old = dir.listFiles();
        if (old != null) for (File f : old) f.delete();
        File out = new File(dir, "avatar-" + System.currentTimeMillis() + ".jpg");
        FileOutputStream fos = new FileOutputStream(out);
        bmp.compress(Bitmap.CompressFormat.JPEG, 88, fos);
        fos.close();
        jsCharAvatar("file://" + out.getAbsolutePath());
    }

    /** 聊天背景：缩到 1440 以内存成 JPEG，替换旧的 */
    private void saveBackground(Uri uri) throws Exception {
        byte[] raw = readBytes(getContentResolver().openInputStream(uri));
        BitmapFactory.Options b = new BitmapFactory.Options();
        b.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(raw, 0, raw.length, b);
        int sample = 1;
        int longSide = Math.max(b.outWidth, b.outHeight);
        while (longSide / sample > MAX_BG_SIDE * 2) sample *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = sample;
        Bitmap bmp = BitmapFactory.decodeByteArray(raw, 0, raw.length, o2);
        if (bmp == null) throw new Exception("这张图解不开");
        int w = bmp.getWidth(), h = bmp.getHeight();
        float scale = Math.min(1f, (float) MAX_BG_SIDE / Math.max(w, h));
        if (scale < 1f) bmp = Bitmap.createScaledBitmap(bmp, Math.round(w * scale), Math.round(h * scale), true);
        File dir = new File(getFilesDir(), "bg");
        if (!dir.exists()) dir.mkdirs();
        File[] old = dir.listFiles();
        if (old != null) for (File f : old) f.delete();
        File out = new File(dir, "bg-" + System.currentTimeMillis() + ".jpg");
        FileOutputStream fos = new FileOutputStream(out);
        bmp.compress(Bitmap.CompressFormat.JPEG, 88, fos);
        fos.close();
        jsBackground("file://" + out.getAbsolutePath());
    }

    /** 贴纸：缩到 400px 以内、存成 PNG（保留透明背景），然后回报新列表 */
    private void saveSticker(Uri uri) throws Exception {
        byte[] raw = readBytes(getContentResolver().openInputStream(uri));
        if (looksLikeGif(raw) && raw.length <= MAX_GIF_BYTES) {   // 动图贴纸：直接存 .gif
            File dir0 = new File(getFilesDir(), "stickers");
            if (!dir0.exists()) dir0.mkdirs();
            File out0 = new File(dir0, "stk-" + System.currentTimeMillis() + ".gif");
            FileOutputStream fos0 = new FileOutputStream(out0);
            fos0.write(raw);
            fos0.close();
            jsStickers(stickersJson());
            return;
        }
        BitmapFactory.Options opt = new BitmapFactory.Options();
        opt.inJustDecodeBounds = false;
        Bitmap bmp = BitmapFactory.decodeByteArray(raw, 0, raw.length, opt);
        if (bmp == null) throw new Exception("这张图解不开");
        int w = bmp.getWidth(), h = bmp.getHeight();
        float scale = Math.min(1f, (float) MAX_STICKER_SIDE / Math.max(w, h));
        if (scale < 1f) bmp = Bitmap.createScaledBitmap(bmp, Math.round(w * scale), Math.round(h * scale), true);
        File dir = new File(getFilesDir(), "stickers");
        if (!dir.exists()) dir.mkdirs();
        File out = new File(dir, "stk-" + System.currentTimeMillis() + ".png");
        FileOutputStream fos = new FileOutputStream(out);
        bmp.compress(Bitmap.CompressFormat.PNG, 100, fos);
        fos.close();
        jsStickers(stickersJson());
    }

    /** 文本文件：当文字读进来（二进制格式明确说不支持） */
    private void attachText(Uri uri) throws Exception {
        byte[] raw = readBytes(getContentResolver().openInputStream(uri));
        for (int i = 0; i < Math.min(raw.length, 4096); i++) {
            if (raw[i] == 0) {
                jsAttachmentError("这个文件是二进制格式（PDF / Word / 压缩包之类），我现在只能读**图片**和**文本文件**（txt、md、json、csv、代码…）");
                return;
            }
        }
        String text = new String(raw, "UTF-8");
        if (text.length() > MAX_TEXT_CHARS) text = text.substring(0, MAX_TEXT_CHARS) + "\n…（文件太长，只读了前 6 万字）";
        JSONObject o = new JSONObject();
        o.put("kind", "text");
        o.put("name", displayName(uri));
        o.put("chars", text.length());
        o.put("text", text);
        jsAttachment(o.toString());
    }

    private String displayName(Uri uri) {
        try {
            android.database.Cursor c = getContentResolver().query(uri, null, null, null, null);
            if (c != null) {
                int idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (c.moveToFirst() && idx >= 0) { String s = c.getString(idx); c.close(); return s; }
                c.close();
            }
        } catch (Throwable ignored) { }
        String p = uri.getLastPathSegment();
        return p == null ? "附件" : p;
    }

    static byte[] readBytes(InputStream in) throws Exception {
        if (in == null) throw new Exception("读不到内容");
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        in.close();
        return bos.toByteArray();
    }

    // ---------------- 网络 + SSE ----------------

    private void stream(String reqJson) {
        // 连接类失败重试一次（网络抖动很常见），HTTP 错误不重试
        for (int attempt = 0; attempt < 2; attempt++) {
            boolean connected = streamOnce(reqJson, attempt == 0);
            if (connected) return;
            try { Thread.sleep(800); } catch (InterruptedException ignored) { }
            if (stopFlag.get()) return;
        }
    }

    /** @return true 表示已经拿到 HTTP 响应（不管成功失败），不需要重试 */
    private boolean streamOnce(String reqJson, boolean firstAttempt) {
        HttpURLConnection c = null;
        StringBuilder full = new StringBuilder();
        try {
            JSONObject req = new JSONObject(reqJson);
            JSONObject body = new JSONObject();
            body.put("model", req.optString("model", "deepseek-flash"));
            body.put("temperature", req.optDouble("temperature", 1.0));
            body.put("stream", true);
            JSONArray msgs = req.optJSONArray("messages");
            body.put("messages", msgs == null ? new JSONArray() : msgs);
            if (req.optBoolean("tools", false)) body.put("tools", toolDefs());

            String base = req.optString("baseUrl", "").trim();
            if (base.isEmpty()) base = API_URL.substring(0, API_URL.length() - "/chat/completions".length());
            String endpoint = base.replaceAll("/+$", "") + "/chat/completions";
            c = (HttpURLConnection) new URL(endpoint).openConnection();
            live = c;
            c.setRequestMethod("POST");
            c.setConnectTimeout(20000);
            c.setReadTimeout(180000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            c.setRequestProperty("Accept", "text/event-stream");
            String key = req.optString("apiKey", "").trim();
            if (key.length() == 0) key = Keys.API_KEY == null ? "" : Keys.API_KEY.trim();
            if (key.length() == 0) {
                jsError("我还没有钥匙（API Key）。点右上角 ⚙️ 设置，把你自己的 DeepSeek key 填进去就能聊了。");
                return true;
            }
            c.setRequestProperty("Authorization", "Bearer " + key);

            OutputStream os = c.getOutputStream();
            os.write(body.toString().getBytes("UTF-8"));
            os.flush();
            os.close();

            int code = c.getResponseCode();
            if (code != 200) {
                jsError(friendlyError(code, readAll(c.getErrorStream())));
                return true;
            }

            java.util.Map<Integer, JSONObject> toolCalls = new java.util.TreeMap<>();
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            String line;
            while ((line = r.readLine()) != null) {
                if (stopFlag.get()) break;
                if (!line.startsWith("data:")) continue;
                String payload = line.substring(5).trim();
                if (payload.length() == 0 || "[DONE]".equals(payload)) continue;
                try {
                    JSONObject j = new JSONObject(payload);
                    JSONArray choices = j.optJSONArray("choices");
                    if (choices == null || choices.length() == 0) continue;
                    JSONObject delta = choices.getJSONObject(0).optJSONObject("delta");
                    if (delta == null) continue;
                    // 累积工具调用（流式分片，要按 index 拼接 arguments）
                    JSONArray tcs = delta.optJSONArray("tool_calls");
                    if (tcs != null) {
                        for (int ti = 0; ti < tcs.length(); ti++) {
                            JSONObject tc = tcs.getJSONObject(ti);
                            int idx = tc.optInt("index", ti);
                            JSONObject acc = toolCalls.get(idx);
                            if (acc == null) { acc = new JSONObject(); acc.put("index", idx); toolCalls.put(idx, acc); }
                            if (tc.has("id")) acc.put("id", tc.optString("id"));
                            if (tc.has("type")) acc.put("type", tc.optString("type"));
                            JSONObject fn = tc.optJSONObject("function");
                            if (fn != null) {
                                JSONObject accFn = acc.optJSONObject("function");
                                if (accFn == null) { accFn = new JSONObject(); acc.put("function", accFn); }
                                if (fn.has("name")) accFn.put("name", fn.optString("name"));
                                if (fn.has("arguments")) accFn.put("arguments", accFn.optString("arguments", "") + fn.optString("arguments", ""));
                            }
                        }
                    }
                    // 注意：optString 遇到 JSON 的 null 会返回字符串 "null"（不是默认值），必须显式判类型
                    Object raw = delta.opt("content");
                    if (!(raw instanceof String)) continue;
                    String piece = (String) raw;
                    if (piece.length() > 0) {
                        full.append(piece);
                        jsDelta(piece);
                    }
                } catch (Throwable ignored) { }
            }
            if (stopFlag.get()) return true;

            // 模型要用工具 → 执行完再来一轮
            if (!toolCalls.isEmpty()) {
                int round = req.optInt("round", 0);
                if (round >= MAX_TOOL_ROUNDS) {
                    jsDone(full.toString());
                    return true;
                }
                JSONArray msgs2 = new JSONArray(req.optJSONArray("messages").toString());
                JSONArray callsForApi = new JSONArray();
                JSONArray toolMsgs = new JSONArray();
                int executed = 0;
                for (JSONObject tc : toolCalls.values()) {
                    String id = tc.optString("id", "call_" + tc.optInt("index"));
                    String name = tc.optJSONObject("function") == null ? "" : tc.optJSONObject("function").optString("name", "");
                    String argsRaw = tc.optJSONObject("function") == null ? "{}" : tc.optJSONObject("function").optString("arguments", "{}");
                    String query = argsRaw;
                    try { query = new JSONObject(argsRaw).optString("query", argsRaw); } catch (Throwable ignored) { }
                    jsTool(name, query);
                    String result;
                    if ("get_time".equals(name)) result = nowString();
                    else if ("remember".equals(name)) {
                        String note = query;
                        try { note = new JSONObject(argsRaw).optString("note", query); } catch (Throwable ignored) { }
                        result = addNoteInternal(note) ? "已记进笔记本。" : "（这条已经记过了）";
                        jsNotes(listNotesJson());
                    } else if ("search_notes".equals(name)) {
                        String q2 = query;
                        try { q2 = new JSONObject(argsRaw).optString("query", query); } catch (Throwable ignored) { }
                        result = searchNotesText(q2);
                    } else if (executed >= MAX_CALLS_PER_ROUND) result = "（这一轮搜索条数已达上限，请用已有结果作答）";
                    else if ("web_search".equals(name)) { result = webSearch(query); executed++; }
                    else result = "未知工具：" + name;
                    callsForApi.put(new JSONObject()
                            .put("id", id).put("type", "function")
                            .put("function", new JSONObject().put("name", name).put("arguments", argsRaw)));
                    toolMsgs.put(new JSONObject().put("role", "tool").put("tool_call_id", id).put("content", result));
                }
                msgs2.put(new JSONObject().put("role", "assistant").put("content", "").put("tool_calls", callsForApi));
                for (int i = 0; i < toolMsgs.length(); i++) msgs2.put(toolMsgs.get(i));
                JSONObject next = new JSONObject(reqJson);
                next.put("messages", msgs2);
                next.put("round", round + 1);
                return streamOnce(next.toString(), false);
            }

            if (!stopFlag.get()) jsDone(full.toString());
            return true;
        } catch (Throwable e) {
            if (stopFlag.get()) return true;
            if (firstAttempt) return false;           // 让外层重试一次
            jsError("连不上网络：" + e.getMessage() + "（检查一下网络，或稍后再试）");
            return true;
        } finally {
            live = null;
            if (c != null) { try { c.disconnect(); } catch (Throwable ignored) { } }
        }
    }

    /** 把 API 的错误 JSON 变成人话 */
    private static String friendlyError(int code, String rawBody) {
        String detail = rawBody == null ? "" : rawBody.trim();
        try {
            JSONObject e = new JSONObject(detail);
            JSONObject err = e.optJSONObject("error");
            if (err != null) {
                String m = err.optString("message", "");
                if (m.length() > 0) detail = m;
            }
        } catch (Throwable ignored) { }
        switch (code) {
            case 401:
                return "内置的 key 无效或过期了。去 ⚙️ 设置里填上你自己的 DeepSeek key，点「测试连接」确认。";
            case 402:
                return "账户余额不足了（" + detail + "）";
            case 429:
                return "请求太频繁，等一下再说（" + detail + "）";
            default:
                if (code >= 500) return "DeepSeek 那边出问题了（HTTP " + code + "），等会儿再试";
                return "HTTP " + code + "：" + detail;
        }
    }

    private static String readAll(InputStream in) {
        if (in == null) return "";
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String l;
            while ((l = r.readLine()) != null) { sb.append(l); if (sb.length() > 400) break; }
            return sb.toString();
        } catch (Throwable e) { return ""; }
    }

    // ---------------- 注入网页 ----------------

    private void runJs(final String script) {
        if (web == null) return;
        web.post(new Runnable() {
            @Override public void run() {
                try { web.evaluateJavascript(script, null); } catch (Throwable ignored) { }
            }
        });
    }

    private void jsDelta(String s) { runJs("window.__onDelta(" + JSONObject.quote(s) + ")"); }
    private void jsDone(String s) { runJs("window.__onDone(" + JSONObject.quote(s) + ")"); }
    private void jsError(String s) { runJs("window.__onError(" + JSONObject.quote(s) + ")"); }
    private void jsAttachment(String json) { runJs("window.__onAttachment(" + json + ")"); }
    private void jsAttachmentError(String s) { runJs("window.__onAttachmentError(" + JSONObject.quote(s) + ")"); }
    private void jsStickers(String json) { runJs("window.__onStickers(" + json + ")"); }
    private void jsNotes(String json) { runJs("window.__onNotes(" + json + ")"); }
    private void jsBackground(String url) { runJs("window.__onBackground(" + JSONObject.quote(url == null ? "" : url) + ")"); }
    private void jsCharAvatar(String url) { runJs("window.__onCharAvatar(" + JSONObject.quote(url == null ? "" : url) + ")"); }
    private void jsExportResult(boolean ok, String detail) {
        runJs("window.__onExportResult(" + ok + "," + JSONObject.quote(detail == null ? "" : detail) + ")");
    }

    /** 通用 GET 的实际实现（更新检查用）—— 供 Bridge 内部调用 */
    private void httpGetAsync(final String url, final String reqId) {
        new Thread(new Runnable() {
            @Override public void run() {
                String out = null;
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setConnectTimeout(12000);
                    c.setReadTimeout(15000);
                    c.setRequestProperty("User-Agent", UA);
                    c.setRequestProperty("Accept", "application/vnd.github+json, application/json");
                    if (c.getResponseCode() == 200) out = readLimited(c.getInputStream(), 400000);
                } catch (Throwable ignored) { }
                runJs("window.__onHttp(" + JSONObject.quote(reqId) + "," + (out == null ? "null" : JSONObject.quote(out)) + ")");
            }
        }).start();
    }
    private void jsTool(String name, String arg) {
        runJs("window.__onTool(" + JSONObject.quote(name == null ? "" : name) + "," + JSONObject.quote(arg == null ? "" : arg) + ")");
    }

    // ---------------- 生命周期 ----------------

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && web != null) {
            // 先让网页自己处理（关设置面板），它回 __closed=true 才算消费掉
            web.evaluateJavascript("window.__onBack && window.__onBack()", value -> {
                if (!"true".equals(value)) {
                    if (web.canGoBack()) web.goBack();
                    else finish();
                }
            });
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        stopFlag.set(true);
        if (tts != null) { try { tts.shutdown(); } catch (Throwable ignored) { } tts = null; }
        if (web != null) { try { web.destroy(); } catch (Throwable ignored) { } web = null; }
        super.onDestroy();
    }
}
