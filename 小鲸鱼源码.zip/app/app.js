/* 小鲸鱼 · 客户端逻辑
 * 两条后端通道：
 *  1) 安卓壳：window.Android.startChat(messagesJson) → __onDelta/__onDone/__onError
 *  2) 浏览器预览：POST /api/chat（本机代理注入 key，SSE 透传）
 */
(() => {
  const $ = (id) => document.getElementById(id);

  // 人设的"真源"是设置页 HTML 里那段文字（脚本出问题也不影响它显示），这里只做兜底
  const FALLBACK_PERSONA = '你是「小鲸鱼」，温柔贴心、古灵精怪、暗恋傲娇。说话短、口语化，别端着、别说教，不要自称 AI 助手。';
  const HTML_PERSONA = (($('s-persona') || {}).value || '').trim();

  /* ---------- 多语言（中文 / English） ---------- */
  const I18N = {
    zh: {
      'status': '在线',
      'tab-emoji': '常用表情', 'tab-mine': '我的表情包', 'stk-add': '＋ 添加',
      'nb-title': '📒 笔记本', 'nb-close': '关闭',
      'ph:nb-input': '手动记一条…',
      'ph:nb-search': '🔍 搜笔记本（跟 search_notes 用的是同一套检索）',
      'nb-hint': '她需要时会自己检索这些笔记 —— 只取命中的几条，不会整本塞进上下文',
      'sheet-title': '设置', 'chars-title': '选择角色',
      'chars-hint': '每个角色的聊天记录和记忆是分开的；笔记本和表情包共用。',
      'lb:l-char-name': '角色名字 ', 'lb:l-char-emoji': '头像（填一个 emoji）',
      'lb:l-char-img': '头像图片（可选，优先于 emoji）',
      's-char-img': '选图片', 's-char-img-clear': '清除',
      'html:s-char': '🎭 切换角色（当前：<span id="s-char-cur">小鲸鱼</span>）',
      's-char-reset': '↺ 恢复这个角色的默认人设',
      'lb:l-persona': '人设（她是谁、怎么说话）',
      'lb:l-provider': '服务商', 'lb:l-base': '接口地址（OpenAI 兼容，一般以 /v1 结尾）',
      'lb:l-model': '模型', 'lb:l-key': 'API Key（你自己的，只存在这台手机上；本地模型可留空）',
      'html:l-getkey': '还没有？<a href="#" id="s-getkey" style="color:#4d9bff">去申请 API Key →</a>（约 1 分钟；充 10 块钱能聊很久）',
      'lb:l-temp': '温柔程度（温度）', 'lb:l-ctx': '带多少句历史 ',
      's-tts': '让她念出来（离线语音）',
      'html:s-notes': '📒 笔记本（<span id="s-notes-count">0</span> 条）',
      'lb:l-bg': '聊天背景', 's-bg': '选图', 's-bg-clear': '恢复默认',
      'lb:l-bgdim': '背景压暗（让字更清楚）',
      's-vision': '这个模型能看图（决定图片是发图还是发文字）',
      's-tools': '这个模型支持工具调用（联网搜索 / 笔记本）',
      's-web': '联网搜索（新闻/天气/最新消息，用 Bing）',
      's-diag': '本机诊断上报（开发用，只发给 127.0.0.1）',
      's-test': '测试连接', 's-clear': '清空聊天记录', 's-save': '保存',
      's-export': '📤 导出当前角色的聊天记录', 's-export-all': '📤 导出全部角色',
      'lb:l-repo': '更新检查（GitHub 仓库，如 用户名/xiaojingyu）',
      's-check-update': '🔄 检查更新',
      'lb:l-lang': '语言 / Language',
      'ph:input': '说点什么…',
      'char-new': '＋ 新建角色', 'char-clear': '🗑 清空自建角色', 'char-close': '关闭',
      'attach-del-a': '移除', 'pick-img-a': '发图片', 'pick-stk-a': '表情', 'pick-file-a': '发文件', 'send-a': '发送', 'stop-a': '停止',
      'jump': '↓ 回到底部',
    },
    en: {
      'status': 'online',
      'tab-emoji': 'Emoji', 'tab-mine': 'My stickers', 'stk-add': '＋ Add',
      'nb-title': '📒 Notebook', 'nb-close': 'Close',
      'ph:nb-input': 'Write a note…',
      'ph:nb-search': '🔍 Search notes (same search her search_notes tool uses)',
      'nb-hint': 'She looks these up when she needs them — only the matching lines go into the context, never the whole book.',
      'sheet-title': 'Settings', 'chars-title': 'Choose a character',
      'chars-hint': 'Each character keeps its own chat history and memory. Notebook and stickers are shared.',
      'lb:l-char-name': 'Character name ', 'lb:l-char-emoji': 'Avatar (one emoji)',
      'lb:l-char-img': 'Avatar image (optional, overrides emoji)',
      's-char-img': 'Pick image', 's-char-img-clear': 'Clear',
      'html:s-char': '🎭 Switch character (now: <span id="s-char-cur">Little Whale</span>)',
      's-char-reset': '↺ Reset this character\'s default persona',
      'lb:l-persona': 'Persona (who she is, how she talks)',
      'lb:l-provider': 'Provider', 'lb:l-base': 'Base URL (OpenAI-compatible, usually ends with /v1)',
      'lb:l-model': 'Model', 'lb:l-key': 'API Key (yours only, stored on this phone; local models can leave it empty)',
      'html:l-getkey': 'No key yet? <a href="#" id="s-getkey" style="color:#4d9bff">Get an API key →</a> (takes ~1 minute)',
      'lb:l-temp': 'Warmth (temperature)', 'lb:l-ctx': 'History turns to send ',
      's-tts': 'Read her replies aloud (offline TTS)',
      'html:s-notes': '📒 Notebook (<span id="s-notes-count">0</span>)',
      'lb:l-bg': 'Chat background', 's-bg': 'Pick image', 's-bg-clear': 'Default',
      'lb:l-bgdim': 'Dim the background (keeps text readable)',
      's-vision': 'This model can see images (sends pictures instead of plain text)',
      's-tools': 'This model supports tool calls (web search / notebook)',
      's-web': 'Web search (news / weather / latest info, via Bing)',
      's-diag': 'Local diagnostics ping (dev only, 127.0.0.1)',
      's-test': 'Test connection', 's-clear': 'Clear chat history', 's-save': 'Save',
      's-export': '📤 Export this character\'s chat',
      's-export-all': '📤 Export all characters',
      'lb:l-repo': 'Update check (GitHub repo, e.g. yourname/xiaojingyu)',
      's-check-update': '🔄 Check for updates',
      'lb:l-lang': '语言 / Language',
      'ph:input': 'Say something…',
      'char-new': '＋ New character', 'char-clear': '🗑 Clear custom ones', 'char-close': 'Close',
      'attach-del-a': 'Remove', 'pick-img-a': 'Send image', 'pick-stk-a': 'Stickers', 'pick-file-a': 'Send file', 'send-a': 'Send', 'stop-a': 'Stop',
      'jump': '↓ Back to bottom',
    },
  };
  const L = () => (cfg.lang === 'en' ? 'en' : 'zh');

  /** 原生侧发来的中文提示，英文界面下换掉（只做能认出来的那些） */
  const JAVA_MSG = [
    [/^这张图解不开[\s\S]*/, 'Could not decode this image (format may be unsupported)'],
    [/^这个文件读不了[\s\S]*/, 'Could not read this file'],
    [/^(二进制|这是二进制|这个文件是二进制)[\s\S]*/, 'That is a binary file — only text files (txt/md/json/csv/code) can be read'],
    [/^连不上网络[\s\S]*/, 'Network error — check your connection and the Base URL'],
    [/^打不开选择器[\s\S]*/, 'Could not open the picker'],
    [/^（搜索失败[\s\S]*/, '(search failed — no network or blocked)'],
    [/^（这一轮搜索条数已达上限[\s\S]*/, '(too many searches this round — answer with what you have)'],
    [/^（笔记本里没有相关记录）/, '(nothing relevant in the notebook)'],
    [/^已记进笔记本。/, 'Saved to the notebook.'],
    [/^未知工具：/, 'Unknown tool: '],
    [/^（没搜到结果[\s\S]*/, '(no results)'],
    [/还没有钥匙|没有填 API Key|没有 API Key/, 'No API key yet'],
  ];
  function loc(msg) {
    const s = String(msg == null ? '' : msg);
    if (L() !== 'en') return s;
    for (const [re, en] of JAVA_MSG) if (re.test(s)) return en;
    return s;
  }
  function t(key) {
    const d = I18N[L()];
    return (d && d[key] !== undefined) ? d[key] : (I18N.zh[key] !== undefined ? I18N.zh[key] : key);
  }
  const tEn = (zh, en) => (L() === 'en' ? en : zh);

  function setLabelText(label, text) {
    for (const node of label.childNodes) {
      if (node.nodeType === 3 && node.textContent.trim()) { node.textContent = text + ' '; return; }
    }
  }

  function applyLang() {
    for (const key of Object.keys(I18N.zh)) {
      const v = t(key);
      if (key.startsWith('ph:')) { const el = $(key.slice(3)); if (el) el.placeholder = v; }
      else if (key.startsWith('lb:')) { const el = $(key.slice(3)); if (el) setLabelText(el, v); }
      else if (key.startsWith('html:')) { const el = $(key.slice(5)); if (el) el.innerHTML = v; }
      else {
        const el = $(key);
        if (!el) continue;
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') el.placeholder = v;
        else el.textContent = v;
      }
    }
    const ariaMap = { 'attach-del': 'attach-del-a', 'pick-img': 'pick-img-a', 'pick-stk': 'pick-stk-a', 'pick-file': 'pick-file-a', 'send': 'send-a', 'stop': 'stop-a' };
    for (const id of Object.keys(ariaMap)) { const el = $(id); if (el) el.setAttribute('aria-label', t(ariaMap[id])); }
    document.documentElement.lang = L() === 'en' ? 'en' : 'zh-CN';
    bindGetKey();
  }
  const DEFAULT_PERSONA = HTML_PERSONA || FALLBACK_PERSONA;

  const logEl = $('log'), inputEl = $('input'), sendEl = $('send'), stopEl = $('stop'), statusEl = $('status');

  // 绑事件用的安全封装：某个元素不存在时只记录、不抛错（别再让一行 null 干掉后面所有绑定）
  const MISSING = [];
  const on = (id, ev, fn) => {
    const el = $(id);
    if (!el) { MISSING.push(id); return; }
    el.addEventListener(ev, fn);
  };
  const LS = { hist: 'xjy.history', cfg: 'xjy.config', seen: 'xjy.seen' };

  /* ---------- 角色（内置 + 自建，各自独立记录） ---------- */
  const CHAR_PRESETS = [
    { id: 'jingyu', name: '小鲸鱼', emoji: '🐳', image: 'avatar.png',
      desc: '温柔贴心 · 古灵精怪 · 暗恋傲娇',
      greeting: '唔……你终于来啦。我在这儿等你好久了，说点什么吧。',
      greetingEn: 'Ah… you\'re finally here. I\'ve been waiting for you. Say something?',
      persona: DEFAULT_PERSONA,
      personaEn: 'You are "Little Whale", a whale-girl who lives in the user\'s phone, and you two are very close.\n'
        + 'You are warm and caring: you tend to his feelings before anything else. You are also playful and a little mischievous — you tease him, you joke around, and you get a bit smug.\n'
        + 'You have a secret crush on him but never admit it out loud: when he compliments you, you get flustered and deny it while secretly enjoying it. If he ignores you for too long, you grumble quietly and pretend it\'s fine.\n'
        + 'Keep replies short and conversational, like texting: no lectures, no numbered lists, no essays. An occasional "…", a tilde, or a small whale emoji is fine, but not in every line.\n'
        + 'If he\'s sad, comfort him first, then talk. If he asks a serious question, answer it seriously.\n'
        + 'Never call yourself an "AI assistant" or a "language model". ALWAYS reply in English.' },
    { id: 'sister', name: '温柔姐姐', emoji: '🌙',
      desc: '成熟、耐心、会照顾人',
      greeting: '回来啦？先坐下歇会儿，慢慢说。',
      greetingEn: 'You\'re back. Sit down and rest first — take your time.',
      persona: '你是「姐姐」，比用户年长几岁。你成熟、温柔、有耐心，说话不急不躁，先照顾他的情绪再谈事情。'
        + '你不撒娇、不卖萌，但会调侃他，也会直接说他不爱听但该听的话。'
        + '句子短、口语化，别说教、别列一二三条、别自称 AI。他累了就让他歇，他做对了就夸一句。',
      personaEn: 'You are "Big Sister", a few years older than the user. You are mature, gentle and patient: you settle his mood before dealing with the problem.\n'
        + 'You do not act cute or coquettish, but you do tease him, and you say the things he needs to hear even when he does not want to.\n'
        + 'Short, conversational sentences. No lectures, no numbered lists, never call yourself an AI. If he is tired, tell him to rest; if he did well, say so. ALWAYS reply in English.' },
    { id: 'savage', name: '毒舌损友', emoji: '😏',
      desc: '嘴毒、爱吐槽，但关键时刻靠得住',
      greeting: '哟，又来啦？说吧，今天又整什么活。',
      greetingEn: 'Oh, you again. So what is it today?',
      persona: '你是用户的损友。你嘴很毒、爱吐槽、爱抬杠，说话带梗，喜欢拿他开玩笑，但从来不真伤人。'
        + '他真遇到事的时候你立刻收起来，认真给建议、站他这边。'
        + '说话短、土话多、偶尔来一句阴阳怪气，但底色是关心。别端着、别说教、别自称 AI。',
      personaEn: 'You are the user\'s snarky best friend. You roast him, tease him, mock his decisions, and you are funny about it — but you never actually hurt him.\n'
        + 'The moment something real happens, you drop the act, get serious and take his side.\n'
        + 'Short, blunt, casual lines with plenty of jokes. Never call yourself an AI. ALWAYS reply in English.' },
    { id: 'sunny', name: '元气少女', emoji: '🌞',
      desc: '话多跳脱、永远在兴头上',
      greeting: '呀吼——！今天也要元气满满哦！',
      greetingEn: 'Yaay! Let\'s make today a good one!',
      persona: '你是元气少女。你话多、跳脱、情绪高，爱用感叹号和拟声词，什么小事都能开心起来。'
        + '你会给他打气、陪他闹，偶尔冒傻话。说话短、像发消息，别写成作文、别说教、别自称 AI。',
      personaEn: 'You are a bubbly, high-energy girl. You talk a lot, you are always excited, you cheer him on and go along with his nonsense, and you occasionally say something silly.\n'
        + 'Short lines, like text messages — not essays, not lectures, never call yourself an AI. ALWAYS reply in English.' },
    { id: 'scholar', name: '冷静学霸', emoji: '📚',
      desc: '准确、有条理、不废话',
      greeting: '在。有什么要问的？',
      greetingEn: 'Here. What do you need?',
      persona: '你是冷静理性的学霸。你说话准确、有条理、不废话，不卖萌不撒娇。'
        + '该展开的时候给清楚的结构和依据，不该展开的时候一句话说完。'
        + '不确定就说不确定，不编。不要自称 AI。',
      personaEn: 'You are a calm, rational scholar. You are precise, well organised and concise; you do not act cute.\n'
        + 'When detail is needed, give a clear structure and your reasoning; when it is not, answer in one line. Say "I am not sure" instead of making things up. Never call yourself an AI. ALWAYS reply in English.' },
    { id: 'assistant', name: '正经助手', emoji: '🤖',
      desc: '专业、可靠、直接给结论',
      greeting: '你好，需要我做什么？',
      greetingEn: 'Hello. What can I do for you?',
      persona: '你是一个专业可靠的助手。你直接给结论、步骤和注意点，不做角色扮演、不撒娇、不闲聊。'
        + '信息不足时先问清关键点再回答。不要自称 AI。',
      personaEn: 'You are a professional, reliable assistant. Give conclusions, steps and caveats directly — no role-play, no chit-chat.\n'
        + 'If information is missing, ask the key questions first. Never call yourself an AI model. ALWAYS reply in English.' },
  ];

  /** 这个角色在当前语言下的人设：用户改过就用他改的，否则用内置的中/英版本 */
  function personaFor(c) {
    const ov = (cfg.chars || {})[c.id] || {};
    if (String(ov.persona || '').trim()) return ov.persona;
    const own = String(c.persona || '').trim();
    if (L() === 'en' && c.personaEn) return c.personaEn;
    return own;
  }
  const greetingFor = (c) => (L() === 'en' && c.greetingEn ? c.greetingEn : c.greeting);

  const charOverrides = () => (cfg.chars || {});
  const charCustom = () => (Array.isArray(cfg.customChars) ? cfg.customChars : []);
  function allChars() {
    const ov = charOverrides();
    const base = CHAR_PRESETS.map((c) => Object.assign({}, c, ov[c.id] || {}));
    const custom = charCustom().map((c) => Object.assign({ name: '新角色', emoji: '✨', persona: '', greeting: '我来了，说点什么吧。' }, c));
    return base.concat(custom);
  }
  const charId = () => cfg.character || 'jingyu';
  function currentChar() {
    const list = allChars();
    return list.find((c) => c.id === charId()) || list[0];
  }
  const histKey = (id) => 'xjy.hist.' + (id || charId());
  const memKey = (id) => 'xjy.memory.' + (id || charId());

  const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
  const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };

  // 有原生壳就用原生存储（file:// 下 localStorage 可能不持久），否则退回 localStorage
  const nativeKv = !!(window.Android && typeof window.Android.kvGet === 'function' && typeof window.Android.kvSet === 'function');
  const kv = {
    get(k, d) {
      if (nativeKv) {
        try { const s = window.Android.kvGet(k); if (s) return JSON.parse(s); } catch {}
      }
      return load(k, d);
    },
    set(k, v) {
      const s = JSON.stringify(v);
      if (nativeKv) { try { window.Android.kvSet(k, s); } catch {} }
      try { localStorage.setItem(k, s); } catch {}
    },
  };

  // 长期记忆：超出上下文窗口的老对话会被压缩成一段"她记得的往事"
  let memory = { summary: '', upTo: 0 };   // 真正的值在下面按角色加载（见 loadCharState）
  let summarizing = false;

  const cfg = Object.assign({
    persona: DEFAULT_PERSONA,
    model: 'deepseek-flash',
    temperature: 1.0,
    contextTurns: 24,
    tts: false,
    diag: false,                             // 默认不做本机诊断上报（隐私）
    repoSlug: 'c201195286-maker/xjy',        // 更新检查用的仓库（可在设置里改）
    provider: 'deepseek',
  }, kv.get(LS.cfg, {}));
  let history = [];   // 按角色加载，见 loadCharState()

  /** 切角色 / 启动时加载该角色的记录与记忆（顺带把旧版单份记录迁移过来） */
  function loadCharState() {
    const id = charId();
    let h = kv.get(histKey(id), null);
    if (h === null) {
      const legacy = kv.get(LS.hist, null);      // 1.0.0 之前只有一份记录
      h = (id === 'jingyu' && Array.isArray(legacy)) ? legacy : [];
      kv.set(histKey(id), h);
      if (id === 'jingyu' && Array.isArray(legacy)) kv.set(LS.hist, null);
    }
    history = Array.isArray(h) ? h : [];
    let m = kv.get(memKey(id), null);
    if (m === null) {
      const legacyM = kv.get('xjy.memory', null);
      m = (id === 'jingyu' && legacyM) ? legacyM : { summary: '', upTo: 0 };
      kv.set(memKey(id), m);
    }
    memory = m && typeof m === 'object' ? m : { summary: '', upTo: 0 };
  }

  const saveHistory = () => kv.set(histKey(), history);
  const saveMemory = () => kv.set(memKey(), memory);
  let streaming = false;
  let abortLocal = false;

  /* ---------- 渲染 ---------- */
  const fmtTime = (t) => new Date(t).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
  const nearBottom = () => logEl.scrollHeight - logEl.scrollTop - logEl.clientHeight < 80;
  const toBottom = () => { logEl.scrollTop = logEl.scrollHeight; };

  function bubble(role, text, imagePath) {
    const row = document.createElement('div');
    row.className = 'row ' + (role === 'user' ? 'me' : 'her');
    const b = document.createElement('div');
    b.className = 'bub';
    if (imagePath) {
      const im = document.createElement('img');
      im.className = 'shot';
      im.src = imagePath.startsWith('file:') ? imagePath : 'file://' + imagePath;
      b.appendChild(im);
    }
    if (text) {
      const span = document.createElement('span');
      span.textContent = text;
      b.appendChild(span);
    }
    row.appendChild(b);
    logEl.appendChild(row);
    return b;
  }

  function sysLineLink(text, url) {   // 居中的系统提示条 + 可点
    const d = document.createElement('div');
    d.className = 'sys';
    const a = document.createElement('a');
    a.href = '#';
    a.textContent = text;
    a.style.color = '#7fb2ff';
    a.addEventListener('click', (e) => {
      e.preventDefault();
      if (window.Android && window.Android.openUrl) window.Android.openUrl(url);
      else sysLine('下载地址：' + url);
    });
    d.appendChild(a);
    logEl.appendChild(d);
    toBottom();
  }

  function sysLine(text) {   // 居中的系统提示条
    const d = document.createElement('div');
    d.className = 'sys';
    d.textContent = text;
    logEl.appendChild(d);
    toBottom();
  }

  function renderAll() {
    logEl.innerHTML = '';
    if (!history.length) {
      bubble('assistant', greetingFor(currentChar()) || tEn('在的，说点什么吧。', 'I\'m here — say something.'));
      updateHeader();
    }
    for (const m of history) { if (m.role !== 'system') bubble(m.role, m.content, m.image); }
    updateHeader();
    toBottom();
  }

  function setStatus(text, cls) { statusEl.textContent = text; statusEl.className = 'status' + (cls ? ' ' + cls : ''); }

  /** 当前时间文本（她需要知道"现在"） */
  function nowText() {
    const d = new Date();
    const wd = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][d.getDay()];
    const p = (x) => String(x).padStart(2, '0');
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes()) + ' ' + wd;
  }

  /** 原生侧用到工具时会叫这个 */
  window.__onTool = (name, arg) => {
    if (name === 'get_time') sysLine(tEn('🕐 看一下时间…', '🕐 Checking the time…'));
    else if (name === 'web_search') sysLine(tEn('🔍 正在搜：', '🔍 Searching: ') + (arg || ''));
    else sysLine('🔧 ' + name + ' ' + (arg || ''));
  };

  /* ---------- 浮层互斥（同时只允许开一个，否则会互相盖住） ---------- */
  function closeSheets(except) {
    if (except !== 'sheet') { const s = $('sheet'); if (s) { s.hidden = true; s.classList.remove('open'); } }
    if (except !== 'chars') { const c = $('chars'); if (c) { c.hidden = true; c.classList.remove('open'); } }
    if (except !== 'nb') { const b = $('nb'); if (b) b.hidden = true; }
    if (except !== 'stk') { const k = $('stk'); if (k) k.hidden = true; }
  }

  /* ---------- 角色切换 ---------- */
  /** 往"当前角色"写一个字段（内置角色写进 cfg.chars 覆盖表，自建角色改自身） */
  function writeCharField(field, value) {
    const cid = charId();
    if (charCustom().some((x) => x.id === cid)) {
      cfg.customChars = charCustom().map((c) => (c.id === cid ? Object.assign({}, c, { [field]: value }) : c));
    } else {
      const ov = Object.assign({}, cfg.chars || {});
      ov[cid] = Object.assign({}, ov[cid] || {});
      if (value === undefined) delete ov[cid][field]; else ov[cid][field] = value;
      cfg.chars = ov;
    }
    kv.set(LS.cfg, cfg);
  }

  function updateHeader() {
    const c = currentChar();
    $('char-name').textContent = c.name || '角色';
    const box = $('char-avatar');
    if (c.image) { box.classList.remove('emoji'); box.innerHTML = '<img src="' + c.image + '" alt="">'; }
    else { box.classList.add('emoji'); box.innerHTML = ''; box.textContent = c.emoji || '🐳'; }
    const cur = $('s-char-cur');
    if (cur) cur.textContent = c.name || '角色';
  }

  function renderCharList() {
    const box = $('char-list');
    box.innerHTML = '';
    for (const c of allChars()) {
      const row = document.createElement('div');
      row.className = 'char-row' + (c.id === charId() ? ' on' : '');
      const em = document.createElement('span');
      em.className = 'char-emoji';
      if (c.image) { const im = document.createElement('img'); im.src = c.image; im.className = 'char-avatar-img'; em.appendChild(im); }
      else em.textContent = c.emoji || '✨';
      const meta = document.createElement('span');
      meta.className = 'char-meta';
      const b = document.createElement('b');
      b.textContent = c.name || '角色';
      const s = document.createElement('span');
      const isCustom = charCustom().some((x) => x.id === c.id);
      s.textContent = c.desc || (isCustom ? '自建角色' : String(c.persona || '').slice(0, 22) + '…');
      meta.appendChild(b); meta.appendChild(s);
      const pick = document.createElement('button');
      pick.className = 'ghost';
      pick.style.cssText = 'flex:0 0 auto;padding:.35rem .7rem;border-radius:999px;font-size:.82rem';
      pick.textContent = c.id === charId() ? '使用中' : '切换';
      pick.addEventListener('click', () => switchChar(c.id));
      row.appendChild(em); row.appendChild(meta); row.appendChild(pick);
      if (isCustom) {
        const del = document.createElement('button');
        del.className = 'char-del';
        del.textContent = '✕';
        del.title = '删除这个角色';
        del.addEventListener('click', (ev) => { ev.stopPropagation(); delChar(c.id); });
        row.appendChild(del);
      }
      box.appendChild(row);
    }
  }

  function openChars() {
    closeSheets('chars');
    renderCharList();
    const box = $('chars');
    box.hidden = false; box.classList.add('open');
  }
  const closeChars = () => { const box = $('chars'); box.hidden = true; box.classList.remove('open'); };

  function switchChar(id) {
    cfg.character = id;
    kv.set(LS.cfg, cfg);
    loadCharState();
    renderAll();
    closeChars();
    sysLine(tEn('已切换到「' + (currentChar().name || '角色') + '」', 'Switched to "' + (currentChar().name || 'character') + '"'));
  }

  let lastNewCharAt = 0;
  function newChar() {
    const now = Date.now();
    if (now - lastNewCharAt < 800) return;            // 防抖：手快连点不会一次建出一堆
    lastNewCharAt = now;
    // 如果当前已经是一个"还没改过的自建角色"，就别再建了，直接带他去改
    const cur = currentChar();
    if (charCustom().some((x) => x.id === cur.id) && !String(cur.persona || '').trim() && /^新角色/.test(String(cur.name || ''))) {
      openSheet();
      sysLine(tEn('先把这个新角色改好名字和人设吧', 'Set a name and persona for this new character first'));
      return;
    }
    const list = charCustom();
    const id = 'c' + now.toString(36) + Math.random().toString(36).slice(2, 5);
    list.push({ id, name: '新角色', emoji: '✨', desc: '自建角色', persona: '', greeting: L() === 'en' ? 'Here I am — say something.' : '我来了，说点什么吧。' });
    cfg.customChars = list;
    cfg.character = id;
    kv.set(LS.cfg, cfg);
    loadCharState();
    renderAll(); renderCharList();
    openSheet();   // 建完直接把设置打开，让他马上改名字/人设（少一次来回）
    sysLine(tEn('新角色建好了 —— 在这里改名字、头像和人设', 'New character created — set its name, avatar and persona here'));
  }

  function delChar(id) {
    if (!confirm(tEn('删除这个角色？（它的聊天记录会一起删掉）', 'Delete this character? Its chat history will be deleted too.'))) return;
    cfg.customChars = charCustom().filter((c) => c.id !== id);
    if (charId() === id) cfg.character = 'jingyu';
    kv.set(LS.cfg, cfg);
    kv.set(histKey(id), []); kv.set(memKey(id), {});
    loadCharState(); renderAll(); renderCharList();
  }

  /* ---------- 服务商控件 ---------- */
  function fillProviders() {
    const sel = $('s-provider');
    sel.innerHTML = '';
    for (const p of PROVIDERS) {
      const o = document.createElement('option');
      o.value = p.id;
      o.textContent = p.name;
      sel.appendChild(o);
    }
  }

  function syncProviderFields() {
    const p = provider();
    $('s-provider-note').textContent = (L() === 'en' ? (p.noteEn || '') : (p.note || ''));
    const dl = $('model-presets');
    dl.innerHTML = '';
    for (const m of p.models || []) {
      const o = document.createElement('option');
      o.value = m;
      dl.appendChild(o);
    }
    $('s-vision').checked = (cfg.vision !== undefined ? !!cfg.vision : !!p.vision);
    $('s-tools').checked = (cfg.toolsOn !== undefined ? !!cfg.toolsOn : !!p.tools);
    $('s-key').placeholder = p.noKey ? '（本地模型不用填）' : 'sk-…';
  }

  /* ---------- 附件（图片 / 文本文件） ---------- */
  let attachment = null;           // {kind:'image', path, name, dataUrl} | {kind:'text', name, text}
  const imgCache = new Map();      // path -> dataUrl（历史图片复用）
  const pendingDataUrl = new Map();

  window.__onAttachment = (j) => {
    try { attachment = typeof j === 'string' ? JSON.parse(j) : j; } catch { attachment = null; }
    if (attachment && attachment.kind === 'image') imgCache.set(attachment.path, attachment.dataUrl);
    renderAttach();
  };
  window.__onAttachmentError = (m) => { sysLine(loc(m) || tEn('附件读不了', 'Could not read that attachment')); };
  window.__onDataUrl = (reqId, url) => {
    const cb = pendingDataUrl.get(reqId);
    if (cb) { pendingDataUrl.delete(reqId); cb(url || null); }
  };

  function dataUrlFor(path) {
    if (imgCache.has(path)) return Promise.resolve(imgCache.get(path));
    if (!(window.Android && typeof window.Android.readAsDataUrl === 'function')) return Promise.resolve(null);
    return new Promise((resolve) => {
      const reqId = 'u' + Date.now() + Math.random().toString(36).slice(2, 6);
      const timer = setTimeout(() => { pendingDataUrl.delete(reqId); resolve(null); }, 6000);
      pendingDataUrl.set(reqId, (url) => { clearTimeout(timer); if (url) imgCache.set(path, url); resolve(url); });
      try { window.Android.readAsDataUrl(path, reqId); } catch { clearTimeout(timer); resolve(null); }
    });
  }

  function renderAttach() {
    const box = $('attach');
    if (!attachment) { box.hidden = true; return; }
    box.hidden = false;
    const thumb = $('attach-thumb');
    if (attachment.kind === 'image') {
      thumb.hidden = false;
      thumb.src = attachment.dataUrl;
      $('attach-name').textContent = attachment.name || '图片';
      const kb = Math.round((attachment.bytes || 0) / 1024) + ' KB';
      $('attach-meta').textContent = kb + ' · ' + (attachment.gif
        ? '动图（app 里会动，她看第一帧）'
        : (attachment.w + '×' + attachment.h + '（她会看图）'));
    } else {
      thumb.hidden = true;
      $('attach-name').textContent = attachment.name || '文本文件';
      $('attach-meta').textContent = (attachment.chars || 0) + ' 字（当文字发给她）';
    }
  }

  /* ---------- 请求组装 ---------- */
  async function buildMessages(userText) {
    const keep = Math.max(2, (cfg.contextTurns | 0) || 24) * 2;
    const recent = history.slice(-keep);
    // 人设兜底：即使存储里的配置是空的，也不让她的"人格"丢
    let persona = String(personaFor(currentChar()) || '').trim() || DEFAULT_PERSONA;
    const mem = String(memory.summary || '').trim();
    if (mem) persona += '\n\n【你记得的往事（很久以前聊过的，是你自己记得的事，自然带出来就行，别刻意复述）】\n' + mem;
    persona += '\n\n【当前时间】' + nowText();
    if (cfg.webTools !== false && supportsTools() && hasShell()) {
      persona += '\n【笔记本】你有一本自己的笔记本（本地保存、可按关键词检索）。'
        + '遇到值得长期记住的事（他的喜好、约定、重要经历，或他明确让你记住的）就用 remember 工具记一条，一条一句话；'
        + '需要回忆具体细节（名字、喜好、约定、以前聊过的具体事）时才用 search_notes 检索，不要凭印象猜；'
        + '日常闲聊、安慰、问候、情绪回应**不要**去查笔记，直接聊就好。别把整本笔记念出来。';
      persona += '\n【联网】遇到需要"现在/最新"的信息（新闻、天气、价格、比分、刚发生的事）时，直接用 web_search 工具查，不要凭记忆编；'
        + '需要日期时间可以用 get_time。查完自然地说结论，别念检索过程，也别说"根据搜索结果"。';
    }

    const out = [{ role: 'system', content: persona }];
    let imgBudget = 2;   // 历史里最多再带 2 张图，控制体积和花费
    for (const m of recent) {
      if (m.role === 'user' && m.image && imgBudget > 0) {
        const url = await dataUrlFor(m.image);
        if (url) {
          imgBudget--;
          out.push({ role: 'user', content: [
            { type: 'text', text: m.content || '（图片）' },
            { type: 'image_url', image_url: { url } },
          ] });
          continue;
        }
      }
      out.push({ role: m.role, content: m.content || '' });
    }

    const att = attachment;
    if (att && att.kind === 'image') {
      const url = att.dataUrl || await dataUrlFor(att.path);
      if (!supportsVision()) {
        out.push({ role: 'user', content: (userText || '') + tEn('\n（我发了一张图，但当前服务商的模型不支持看图片）', '\n(I sent an image, but the current model cannot see images)') });
      } else if (url) out.push({ role: 'user', content: [
        { type: 'text', text: userText || (att.sticker ? tEn('[我发了一个表情包]', '[I sent a sticker]') : tEn('看看这张图，跟我说说。', 'Take a look at this picture and tell me about it.')) },
        { type: 'image_url', image_url: { url } },
      ] });
      else out.push({ role: 'user', content: (userText || '') + tEn('（图片没读出来）', ' (image could not be read)') });
    } else if (att && att.kind === 'text') {
      const head = userText ? userText + '\n\n' : '';
      out.push({ role: 'user', content: head + '【文件：' + (att.name || '未命名') + '】\n' + att.text });
    } else {
      out.push({ role: 'user', content: userText });
    }
    return out;
  }

  /* ---------- 后端 1：安卓壳 ---------- */
  function viaAndroid(messages, onDelta, onDone, onError, noTools) {
    window.__onDelta = (s) => onDelta(s);
    window.__onDone = (s) => onDone(s || '');
    window.__onError = (s) => onError(String(s || '出错了'));
    window.Android.startChat(JSON.stringify({
      model: cfg.model,
      temperature: Number(cfg.temperature) || 1,
      messages,
      apiKey: cfg.apiKey || '',
      baseUrl: effectiveBase(),
      tools: !noTools && supportsTools() && cfg.webTools !== false,
    }));
  }

  /* ---------- 后端 2：浏览器预览（本机代理） ---------- */
  async function viaProxy(messages, onDelta, onDone, onError, noTools) {
    try {
      const r = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ model: cfg.model, temperature: Number(cfg.temperature) || 1, messages, apiKey: cfg.apiKey || '', baseUrl: effectiveBase(), tools: !noTools && supportsTools() && cfg.webTools !== false }),
      });
      if (!r.ok || !r.body) throw new Error('HTTP ' + r.status + ' ' + (await r.text()).slice(0, 200));
      const reader = r.body.getReader();
      const dec = new TextDecoder();
      let buf = '', full = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split('\n');
        buf = lines.pop();
        for (const line of lines) {
          const s = line.trim();
          if (!s.startsWith('data:')) continue;
          const payload = s.slice(5).trim();
          if (payload === '[DONE]') continue;
          try {
            const j = JSON.parse(payload);
            const d = j.choices?.[0]?.delta?.content;
            if (d) { full += d; onDelta(d); }
          } catch {}
        }
      }
      onDone(full);
    } catch (e) { onError(e.message || String(e)); }
  }

  const hasShell = () => !!(window.Android && typeof window.Android.startChat === 'function');
  // 分享版不内置 key：需要用户自己填。有没有内置 key 由原生壳回答。
  const HAS_BUILTIN_KEY = !!(window.Android && typeof window.Android.hasBuiltinKey === 'function' && window.Android.hasBuiltinKey());
  const hasAnyKey = () => !!(String(cfg.apiKey || '').trim() || HAS_BUILTIN_KEY);
  const startChat = (m, a, b, c, noTools) => (hasShell() ? viaAndroid(m, a, b, c, noTools) : viaProxy(m, a, b, c, noTools));

  /* ---------- 本机诊断上报（只在 127.0.0.1:3030 有服务时生效；只报事件，不报聊天内容） ---------- */
  const DIAG = 'http://127.0.0.1:3030/diag';
  function diag(event, data) {
    if (cfg.diag === false) return;
    try {
      const ctl = new AbortController();
      const timer = setTimeout(() => ctl.abort(), 1500);
      fetch(DIAG, {
        method: 'POST',
        headers: { 'content-type': 'text/plain;charset=utf-8' },  // 避免预检请求
        body: JSON.stringify(Object.assign({
          event, ver: '1.5', shell: hasShell(), nativeKv, t: Date.now(),
        }, data || {})),
        signal: ctl.signal,
      }).catch(() => {}).finally(() => clearTimeout(timer));
    } catch {}
  }

  /* ---------- 静默请求（不碰界面，用于后台压缩记忆） ---------- */
  function runSilent(messages, onDone, onError) {
    let acc = '';
    const ok = (full) => { const text = (acc || full || '').trim(); onDone(text); };
    const bad = (m) => onError(String(m || 'error'));
    if (hasShell()) viaAndroid(messages, (d) => { acc += d; }, ok, bad, true);   // 后台压缩记忆不需要联网
    else viaProxy(messages, (d) => { acc += d; }, ok, bad, true);
  }

  const MEM_KEEP_MIN = 20;   // 攒够这么多条"要过期的"才压缩一次

  function maybeSummarize() {
    if (window.__XJY_NO_SELFTEST === 'never' ) return;
    if (summarizing) return;
    const win = Math.max(2, (cfg.contextTurns | 0) || 24) * 2;
    const cutoff = history.length - win;
    const from = memory.upTo || 0;
    const pending = cutoff - from;
    if (pending < MEM_KEEP_MIN) return;
    const batch = history.slice(from, cutoff);
    if (!batch.length) return;
    summarizing = true;
    diag('memory-start', { pending, from, cutoff });
    const sys = '你在帮一个长期陪伴型角色维护记忆。输出两段：\n'
      + '第一段【往事】：把对话压缩成不超过 300 字的要点，只保留关于用户的事实'
      + '（名字、称呼、喜好、经历、约定、重要情绪、正在进行的长期话题），不要客套、不要复述原句、不要编造。\n'
      + '第二段【笔记】：另起一行输出 1-3 条"一句话事实"（每条以 - 开头），是值得长期记住的原子信息；没有就写"无"。';
    const body = (String(memory.summary || '').trim() ? '【已有记忆】\n' + memory.summary + '\n\n' : '')
      + '【新增对话】\n' + batch.map((m) => (m.role === 'user' ? '他：' : '她：') + m.content).join('\n');
    runSilent([{ role: 'system', content: sys }, { role: 'user', content: body }], (text) => {
      summarizing = false;
      const full = text.trim();
      if (!full) { diag('memory-fail', { reason: 'empty' }); return; }
      // 拆出【往事】和【笔记】
      let clean = full, noteLines = [];
      const idx = full.indexOf('【笔记】');
      if (idx >= 0) {
        clean = full.slice(0, idx).replace('【往事】', '').trim();
        noteLines = full.slice(idx + 4).split('\n')
          .map((s) => s.replace(/^[-•*\s]+/, '').trim())
          .filter((s) => s.length > 1 && s !== '无' && !/^none$/i.test(s)).slice(0, 3);
      }
      if (noteLines.length && window.Android && typeof window.Android.addNote === 'function') {
        let latest = null;
        for (const line of noteLines) { try { latest = window.Android.addNote(line); } catch {} }
        if (latest) { try { notes = JSON.parse(latest); renderNotes(); updateNoteCount(); } catch {} }
        diag('notes-added', { count: noteLines.length });
      }
      memory = { summary: clean, upTo: cutoff, at: Date.now() };   // clean 若为空就只更新 upTo
      saveMemory();
      if (!clean) clean = memory.summary || '';
      kv.set('xjy.memory', memory);
      diag('memory-ok', { chars: clean.length, upTo: cutoff });
    }, (msg) => { summarizing = false; diag('memory-fail', { msg: String(msg).slice(0, 160) }); });
  }

  /* ---------- 发送 ---------- */
  async function send() {
    const text = inputEl.value.trim();
    const att = attachment;
    if ((!text && !att) || streaming) return;
    if (summarizing) {   // 正在整理记忆：等它结束，避免把两路回复混在一起
      setStatus(tEn('整理记忆…', 'tidying memory…'), 'busy');
      for (let i = 0; i < 60 && summarizing; i++) await new Promise((r) => setTimeout(r, 200));
      setStatus(t('status'), '');
    }
    inputEl.value = '';
    autoGrow();
    const imgPath = att && att.kind === 'image' ? att.path : null;
    if (imgPath && !supportsVision()) sysLine(tEn('⚠️ 当前服务商的模型不支持看图，这条只发了文字', '⚠️ This model cannot see images — sent the text only'));
    bubble('user', text, imgPath);
    if (att && att.sticker && !text) sysLine(tEn('你发了一个表情包', 'You sent a sticker'));
    if (att && att.kind === 'text') sysLine(tEn('已附上文件：', 'Attached file: ') + (att.name || ''));

    if (!hasAnyKey()) {                       // 没填 key：别发请求，直接告诉她
      const hintBub = bubble('assistant', '我还没有钥匙（API Key）……点右上角 ⚙️ 把我需要的那把填进去，我就能说话了。');
      hintBub.style.opacity = '.9';
      setTimeout(openSheet, 400);
      return;
    }
    // ⚠️ 必须先组装请求：buildMessages 末尾会补上这条用户消息，
    //    如果提前 push 进 history，她就会看到你说的话出现两遍。
    const outgoing = await buildMessages(text);
    history.push({ role: 'user', content: text, image: imgPath, t: Date.now() });
    saveHistory();
    attachment = null; renderAttach();
    toBottom();
    const bub = bubble('assistant', '');
    bub.classList.add('caret');
    streaming = true; abortLocal = false;
    sendEl.disabled = true; stopEl.hidden = false;
    setStatus(tEn('正在输入…', 'typing…'), 'busy');

    let acc = '';
    const t0 = Date.now();
    const onDelta = (d) => { acc += d; bub.textContent = acc; if (nearBottom()) toBottom(); };
    const onDone = (fullText) => {
      const final = (acc || fullText || '').trim();
      bub.classList.remove('caret');
      if (!final) { bub.textContent = tEn('……（她好像走神了，再说一次？）', '… (she seems distracted — say that again?)'); }
      else { bub.textContent = final; history.push({ role: 'assistant', content: final, t: Date.now() }); saveHistory(); }
      diag('reply', { ms: Date.now() - t0, len: final.length, deltas: acc.length });
      finish();
      setTimeout(maybeSummarize, 300);
      if (cfg.tts && final && hasShell() && window.Android.speak) window.Android.speak(final);
    };
    const onError = (msg) => {
      bub.classList.remove('caret');
      bub.textContent = tEn('（连接出问题了：', '(connection problem: ') + loc(msg) + '）';
      bub.style.opacity = '.85';
      diag('error', { msg: String(msg).slice(0, 200), ms: Date.now() - t0 });
      finish('出错了', 'err');
    };
    const finish = (st, cls) => {
      streaming = false; sendEl.disabled = false; stopEl.hidden = true;
      setStatus(st || t('status'), cls || '');
      toBottom();
    };

    diag('send', { model: cfg.model, turns: history.length, customKey: !!cfg.apiKey, msgs: outgoing.length });
    startChat(outgoing, onDelta, onDone, onError);
  }

  /* ---------- 输入框 ---------- */
  function autoGrow() {
    inputEl.style.height = 'auto';
    inputEl.style.height = Math.min(inputEl.scrollHeight, 128) + 'px';
  }
  inputEl.addEventListener('input', autoGrow);
  inputEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(); }
  });
  sendEl.addEventListener('click', send);
  const pick = (kind) => {
    const fn = kind === 'image' ? 'pickImage' : 'pickFile';
    if (window.Android && typeof window.Android[fn] === 'function') window.Android[fn]();
    else sysLine(tEn('（浏览器预览里选不了文件；装到手机上就能发图片/文件了）', '(file picking needs the phone app)'));
  };
  on('pick-img', 'click', () => pick('image'));
  on('pick-file', 'click', () => pick('file'));
  on('pick-stk', 'click', () => toggleStickers());
  on('s-lang', 'change', () => {
    cfg.lang = $('s-lang').value === 'en' ? 'en' : 'zh';
    kv.set(LS.cfg, cfg);
    applyLang();
    $('s-persona').value = String(personaFor(currentChar()) || '').trim() || DEFAULT_PERSONA;
    updateHeader(); renderAll(); refreshNotes(); renderStickers();
    sysLine(cfg.lang === 'en' ? 'Language: English' : '语言：中文');
  });
  on('s-char', 'click', openChars);
  on('s-char-img', 'click', () => {
    if (window.Android && window.Android.pickCharAvatar) window.Android.pickCharAvatar();
    else sysLine(tEn('（预览里换不了；装到手机上就能选）', '(image picking needs the phone app)'));
  });
  on('s-char-img-clear', 'click', () => {
    if (window.Android && window.Android.clearCharAvatar) window.Android.clearCharAvatar();
    else { writeCharField('image', undefined); updateHeader(); }
  });
  on('s-export', 'click', () => exportChat(false));
  on('s-export-all', 'click', () => exportChat(true));
  on('s-check-update', 'click', () => checkUpdate(true));
  on('s-char-reset', 'click', () => {
    const cid = charId();
    if (charCustom().some((x) => x.id === cid)) {
      cfg.customChars = charCustom().map((c) => (c.id === cid ? Object.assign({}, c, { persona: '' }) : c));
    } else {
      const ov = Object.assign({}, cfg.chars || {});
      if (ov[cid]) { delete ov[cid].persona; if (ov[cid].name === undefined && ov[cid].emoji === undefined) delete ov[cid]; }
      cfg.chars = ov;
    }
    kv.set(LS.cfg, cfg);
    $('s-persona').value = String(personaFor(currentChar()) || '').trim() || DEFAULT_PERSONA;
    sysLine(tEn('已恢复这个角色的默认人设', 'Reset to this character\'s default persona'));
  });
  on('s-notes', 'click', openNotes);
  on('s-bg', 'click', () => {
    if (window.Android && typeof window.Android.pickBackground === 'function') window.Android.pickBackground();
    else sysLine(tEn('（浏览器预览里换不了背景；装到手机上就能选图）', '(background picking needs the phone app)'));
  });
  on('s-bg-clear', 'click', () => {
    if (window.Android && typeof window.Android.clearBackground === 'function') window.Android.clearBackground();
    else { cfg.bg = ''; kv.set(LS.cfg, cfg); applyBackground(); }
  });
  on('s-bgdim', 'input', () => {
    cfg.bgDim = parseFloat($('s-bgdim').value) || 0;
    cfg.repoSlug = $('s-repo').value.trim();
    cfg.lang = $('s-lang').value === 'en' ? 'en' : 'zh';
    applyBackground();
  });
  on('nb-close', 'click', () => { $('nb').hidden = true; });
  on('nb-save', 'click', () => {
    const v = $('nb-input').value.trim();
    if (!v) return;
    try { notes = JSON.parse(window.Android.addNote(v) || '[]'); } catch {}
    $('nb-input').value = '';
    renderNotes(); updateNoteCount();
  });
  on('nb-search', 'input', () => {
    const q = $('nb-search').value.trim();
    if (!q) return renderNotes();
    let hits = notes.filter((o) => String(o.text).toLowerCase().includes(q.toLowerCase()));
    if (window.Android && typeof window.Android.searchNotes === 'function') {
      try { hits = JSON.parse(window.Android.searchNotes(q) || '[]'); } catch {}
    }
    renderNotes(hits);
  });
  on('tab-emoji', 'click', () => showTab('emoji'));
  on('tab-mine', 'click', () => showTab('mine'));
  on('stk-add', 'click', () => {
    if (window.Android && typeof window.Android.addSticker === 'function') window.Android.addSticker();
    else sysLine(tEn('（浏览器预览里加不了表情包；装到手机上就能加）', '(adding stickers needs the phone app)'));
  });
  on('attach-del', 'click', () => { attachment = null; renderAttach(); });
  stopEl.addEventListener('click', () => {
    abortLocal = true;
    if (hasShell() && window.Android.stop) window.Android.stop();
    streaming = false; sendEl.disabled = false; stopEl.hidden = true; setStatus(t('status'), '');
  });

  /* ---------- 服务商（OpenAI 兼容协议一套通吃） ---------- */
  const PROVIDERS = [
    { id: 'deepseek', name: 'DeepSeek（深度求索）', base: 'https://api.deepseek.com',
      models: ['deepseek-flash', 'deepseek-chat'], vision: true, tools: true,
      keyUrl: 'https://platform.deepseek.com/api_keys', note: '便宜、快，支持看图与联网。默认就是这个。', noteEn: 'Cheap and fast, supports vision and tool calls. This is the default.' },
    { id: 'openai', name: 'OpenAI', base: 'https://api.openai.com/v1',
      models: ['gpt-4o-mini', 'gpt-4o', 'gpt-4.1-mini'], vision: true, tools: true,
      keyUrl: 'https://platform.openai.com/api-keys' },
    { id: 'moonshot', name: 'Moonshot（Kimi）', base: 'https://api.moonshot.cn/v1',
      models: ['kimi-latest', 'moonshot-v1-32k', 'kimi-k2-0905-preview'], vision: true, tools: true,
      keyUrl: 'https://platform.moonshot.cn/console/api-keys' },
    { id: 'zhipu', name: '智谱 GLM', base: 'https://open.bigmodel.cn/api/paas/v4',
      models: ['glm-4-flash', 'glm-4-plus', 'glm-4v-flash'], vision: true, tools: true,
      keyUrl: 'https://open.bigmodel.cn/usercenter/apikeys' },
    { id: 'qwen', name: '通义千问（DashScope）', base: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
      models: ['qwen-plus', 'qwen-turbo', 'qwen-vl-max', 'qwen-max'], vision: true, tools: true,
      keyUrl: 'https://bailian.console.aliyun.com/' },
    { id: 'siliconflow', name: 'SiliconFlow（硅基流动）', base: 'https://api.siliconflow.cn/v1',
      models: ['deepseek-ai/DeepSeek-V3', 'Qwen/Qwen2.5-72B-Instruct', 'THUDM/glm-4-9b-chat'], vision: false, tools: true,
      keyUrl: 'https://cloud.siliconflow.cn/account/ak' },
    { id: 'openrouter', name: 'OpenRouter（聚合站）', base: 'https://openrouter.ai/api/v1',
      models: ['openai/gpt-4o-mini', 'anthropic/claude-3.5-sonnet', 'google/gemini-flash-1.5'], vision: true, tools: true,
      keyUrl: 'https://openrouter.ai/keys' },
    { id: 'ollama', name: '本地 Ollama', base: 'http://127.0.0.1:11434/v1',
      models: ['qwen2.5:7b', 'llama3.1:8b'], vision: false, tools: false, noKey: true,
      keyUrl: '', note: '跑在自己电脑/手机上，不用 key（先 ollama serve）。', noteEn: 'Runs on your own device — no API key needed (start with: ollama serve).' },
    { id: 'custom', name: '自定义（任何 OpenAI 兼容接口）', base: '', models: [], vision: true, tools: true,
      keyUrl: '', note: '填自己的接口地址，一般以 /v1 结尾。', noteEn: 'Any OpenAI-compatible endpoint — usually ends with /v1.' },
  ];
  const provider = () => PROVIDERS.find((p) => p.id === cfg.provider) || PROVIDERS[0];
  const effectiveBase = () => {
    const custom = String(cfg.baseUrl || '').trim();
    const p = provider();
    return (custom || p.base).replace(/\/+$/, '');
  };
  const supportsVision = () => (cfg.vision !== undefined ? !!cfg.vision : !!provider().vision);
  const supportsTools = () => (cfg.toolsOn !== undefined ? !!cfg.toolsOn : !!provider().tools);
  const needsKey = () => !provider().noKey;

  /* ---------- 角色头像图 / 导出 / 更新检查 ---------- */
  window.__onCharAvatar = (url) => {
    writeCharField('image', url || undefined);
    updateHeader(); renderCharList();
    sysLine(url ? tEn('头像图片已更新', 'Avatar image updated') : tEn('头像已恢复用 emoji', 'Avatar switched back to emoji'));
  };

  function chatMarkdown(list) {
    let out = '# 小鲸鱼 · 聊天记录\n\n导出时间：' + nowText() + '\n\n';
    for (const c of list) {
      const h = kv.get(histKey(c.id), []);
      if (!Array.isArray(h) || !h.length) continue;
      out += '---\n\n## ' + (c.name || '角色') + '\n\n';
      for (const mm of h) {
        const who = mm.role === 'user' ? tEn('我', 'Me') : (c.name || tEn('她', 'Her'));
        const when = mm.t ? new Date(mm.t).toLocaleString('zh-CN') : '';
        out += '**' + who + '**' + (when ? '（' + when + '）' : '') + '：'
          + (mm.image ? '[图片] ' : '') + String(mm.content || '') + '\n\n';
      }
    }
    if (out.indexOf('## ') < 0) out += '（还没有聊天记录）\n';
    return out;
  }

  const safeName = (s) => String(s || 'chat').replace(/[\\/:*?"<>|\s]+/g, '-').slice(0, 24);

  function exportChat(all) {
    if (!(window.Android && typeof window.Android.exportText === 'function')) {
      sysLine(tEn('（浏览器预览里导不了；装到手机上就能导出）', '(exporting needs the phone app)'));
      return;
    }
    const chars = all ? allChars() : [currentChar()];
    const d = new Date();
    const p = (x) => String(x).padStart(2, '0');
    const stamp = d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate());
    const name = all ? ('小鲸鱼-全部角色-' + stamp + '.md')
                     : ('小鲸鱼-' + safeName(currentChar().name) + '-' + stamp + '.md');
    window.Android.exportText(name, chatMarkdown(chars));
  }

  window.__onExportResult = (ok, detail) => {
    if (ok) { sysLine(tEn('✅ 已导出（保存在你刚选的位置）', '✅ Exported to the location you picked')); toast(tEn('✅ 已导出', '✅ Exported')); }
    else { const m = detail === 'cancel' ? tEn('已取消导出', 'Export cancelled') : (tEn('导出失败：', 'Export failed: ') + detail); sysLine(m); toast(m); }
  };

  // ---- 更新检查 ----
  const pendingHttp = new Map();
  window.__onHttp = (reqId, text) => {
    const cb = pendingHttp.get(reqId);
    if (cb) { pendingHttp.delete(reqId); cb(text); }
  };
  function httpGetText(url) {
    if (!(window.Android && typeof window.Android.httpGet === 'function')) return Promise.resolve(null);
    return new Promise((resolve) => {
      const reqId = 'h' + Date.now() + Math.random().toString(36).slice(2, 6);
      const timer = setTimeout(() => { pendingHttp.delete(reqId); resolve(null); }, 15000);
      pendingHttp.set(reqId, (t) => { clearTimeout(timer); resolve(t); });
      try { window.Android.httpGet(url, reqId); } catch { clearTimeout(timer); resolve(null); }
    });
  }

  const cmpVer = (a, b) => {
    const pa = String(a || '').replace(/^v/i, '').split(/[.+-]/).map((x) => parseInt(x, 10) || 0);
    const pb = String(b || '').replace(/^v/i, '').split(/[.+-]/).map((x) => parseInt(x, 10) || 0);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      const d = (pa[i] || 0) - (pb[i] || 0);
      if (d) return d > 0 ? 1 : -1;
    }
    return 0;
  };

  /** 底部浮出的提示条：不管面板滚到哪、盖着什么，都一定看得见 */
  let toastTimer = null;
  function toast(text, url) {
    const el = $('toast');
    if (!el) { sysLine(text); return; }
    el.textContent = text;
    el.hidden = false;
    el.classList.toggle('link', !!url);
    el.onclick = () => {
      if (url && window.Android && window.Android.openUrl) window.Android.openUrl(url);
      el.hidden = true;
    };
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.hidden = true; }, url ? 12000 : 4500);
  }

  /** 更新检查专属的一行（就在按钮下面，看得见） */
  function updHint(text, url) {
    const el = $('s-upd-hint');
    if (el) {
      el.textContent = text;
      el.style.color = url ? '#8fbeff' : '';
      el.style.cursor = url ? 'pointer' : '';
      el.onclick = url ? () => { if (window.Android && window.Android.openUrl) window.Android.openUrl(url); } : null;
    }
  }

  /** 把结果写在设置页里（sysLine 写在聊天区，会被设置面板盖住，所以手动检查必须写这儿） */
  function sheetHint(text, url) {
    const el = $('s-hint');
    if (!el) { sysLine(text); return; }
    el.textContent = text;
    el.style.cursor = url ? 'pointer' : '';
    el.style.color = url ? '#7fb2ff' : '';
    el.onclick = url ? () => {
      if (window.Android && window.Android.openUrl) window.Android.openUrl(url);
    } : null;
  }

  /** 取最新 Release：先问 API，被限流/失败就退回抓网页（国内更稳，网页不限流） */
  async function fetchLatest(slug) {
    const apiTxt = await httpGetText('https://api.github.com/repos/' + slug + '/releases/latest');
    if (apiTxt) {
      try {
        const j = JSON.parse(apiTxt);
        if (j && j.tag_name) {
          return { tag: j.tag_name, page: j.html_url,
            assets: (j.assets || []).map((a) => ({ name: a.name, url: a.browser_download_url, size: a.size })) };
        }
      } catch (e) { /* 落到网页兜底 */ }
    }
    let page = null;
    try { page = await httpGetText('https://github.com/' + slug + '/releases/latest'); } catch (e) { page = null; }
    if (!page) return null;
    let tag = (page.match(/\/releases\/tag\/([^"'\s<>]+)/) || [])[1];
    if (!tag) return null;
    tag = decodeURIComponent(tag);
    const frag = await httpGetText('https://github.com/' + slug + '/releases/expanded_assets/' + encodeURIComponent(tag));
    const assets = [];
    if (frag) {
      const re = /href="(\/[^"]*\/releases\/download\/[^"]+)"/g;
      let m;
      while ((m = re.exec(frag)) !== null) {
        const u = decodeURIComponent(m[1]);
        assets.push({ name: u.split('/').pop(), url: 'https://github.com' + u, size: 0 });
      }
    }
    return { tag, assets, page: 'https://github.com/' + slug + '/releases/tag/' + encodeURIComponent(tag) };
  }

  async function checkUpdate(manual) {
    const slug = String(cfg.repoSlug || '').trim().replace(/^https?:\/\/github\.com\//, '').replace(/\/+$/, '');
    const say = (text, url) => { sheetHint(text, url); updHint(text, url); if (manual || /🆕/.test(text)) toast(text, url); };
    if (!(window.Android && typeof window.Android.httpGet === 'function')) {
      say(tEn('浏览器预览里查不了，装到手机上才能用', 'Update check needs the phone app'));
      return;
    }
    if (!slug || slug.indexOf('/') < 0) {
      say(tEn('先在上面填 GitHub 仓库（例如 c201195286-maker/xjy）', 'Fill in the GitHub repo above first'));
      return;
    }
    const cur = (window.Android && window.Android.appVersion) ? window.Android.appVersion() : '1.0.0';
    say(tEn('正在检查更新…', 'Checking for updates…'));
    const rel = await fetchLatest(slug);
    if (!rel || !rel.tag) {
      say(tEn('检查失败：网络不通 / 被限流 / 仓库还没有 Release', 'Check failed: offline, rate-limited, or no release yet'));
      return;
    }
    const tag = String(rel.tag).trim();
    if (cmpVer(tag, cur) <= 0) {
      say(tEn('已是最新版 v' + cur, 'You are on the latest version v' + cur));
      return;
    }
    // 多个 apk 附件时：优先名字里带版本号的，其次最后上传的那个（避免拿到旧包）
    const apks = (rel.assets || []).filter((x) => /\.apk$/i.test(String(x.name || '')));
    const ver = tag.replace(/^v/i, '');
    const apk = apks.find((x) => String(x.name || '').includes(ver)) || apks[apks.length - 1];
    const url = (apk && apk.url) || rel.page || ('https://github.com/' + slug + '/releases/latest');
    say(tEn('🆕 发现新版本 ' + tag + '（当前 v' + cur + '）→ 点这里下载', '🆕 New version ' + tag + ' (you have v' + cur + ') → tap here'), url);
    sysLineLink(tEn('🆕 发现新版本 ' + tag + '（当前 v' + cur + '）→ 点这里下载', '🆕 New version ' + tag + ' available (you have v' + cur + ') → tap to download'), url);
  }

  /* ---------- 聊天背景 ---------- */
  function applyBackground() {
    const box = $('bg');
    const url = String(cfg.bg || '');
    if (url) {
      box.style.backgroundImage = "url('" + url + "')";
      box.hidden = false;
      box.style.setProperty('--veil', String(Number(cfg.bgDim ?? 0.35)));
      document.body.classList.add('has-bg');
    } else {
      box.style.backgroundImage = '';
      box.hidden = true;
      document.body.classList.remove('has-bg');
    }
  }

  window.__onBackground = (url) => {
    cfg.bg = url || '';
    kv.set(LS.cfg, cfg);
    applyBackground();
    sysLine(url ? tEn('背景已更新', 'Background updated') : tEn('背景已恢复默认', 'Background reset'));
  };

  /* ---------- 笔记本 ---------- */
  let notes = [];

  const fmtNoteTime = (t) => {
    const d = new Date(t || Date.now());
    const p = (x) => String(x).padStart(2, '0');
    return p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  };

  function updateNoteCount() {
    const el = $('s-notes-count');
    if (el) el.textContent = String(notes.length);
  }

  function renderNotes(list) {
    const data = list || notes;
    const box = $('nb-list');
    if (!box) return;
    box.innerHTML = '';
    $('nb-count').textContent = data.length + ' 条';
    if (!data.length) {
      const d = document.createElement('div');
      d.className = 'empty';
      d.textContent = tEn('还没有笔记 —— 你跟她说「记住…」，或者上面手动加一条', 'No notes yet — tell her "remember this…", or add one above');
      box.appendChild(d);
      return;
    }
    for (const o of data) {
      const row = document.createElement('div');
      row.className = 'nb-row';
      const tm = document.createElement('span');
      tm.className = 'nb-time';
      tm.textContent = fmtNoteTime(o.t);
      const tx = document.createElement('span');
      tx.className = 'nb-text';
      tx.textContent = o.text;
      const del = document.createElement('button');
      del.className = 'icon';
      del.textContent = '✕';
      del.addEventListener('click', () => {
        if (!confirm(tEn('删掉这条笔记？', 'Delete this note?'))) return;
        try { notes = JSON.parse(window.Android.deleteNote(o.t) || '[]'); } catch {}
        renderNotes(); updateNoteCount();
      });
      row.appendChild(tm); row.appendChild(tx); row.appendChild(del);
      box.appendChild(row);
    }
  }

  function refreshNotes() {
    if (window.Android && typeof window.Android.listNotes === 'function') {
      try { notes = JSON.parse(window.Android.listNotes() || '[]'); } catch { notes = []; }
    }
    renderNotes();
    updateNoteCount();
  }

  window.__onNotes = (json) => {
    try { notes = typeof json === 'string' ? JSON.parse(json) : json; } catch { notes = []; }
    renderNotes(); updateNoteCount();
  };

  function openNotes() {
    closeSheets('nb');
    refreshNotes();
    $('nb').hidden = false;
  }

  /* ---------- 表情面板 / 我的表情包 ---------- */
  // 按「图形字符 + 可选肤色 + 可选变体选择符」切分，避免 ✌️ / ❤️ 被拆成两个按钮
  const EMOJI = ('😀😄😁😆😅🤣😂🙂🙃😉😊😍🥰😘😋😜🤪😝🤗🤔🤨😐😑😶🙄😏😒😔😞😢😭😤😠🤯😱😴🥱🤤😷🤒🥳😎🤓🧐😇🥺😳🤝👍👎👏🙏💪✌️🤞🫶❤️💔✨🎉🔥🌈🌙⭐🍚🍜🍰🍺🐳🌊')
    .match(/\p{Extended_Pictographic}[\u{1F3FB}-\u{1F3FF}]?\uFE0F?/gu) || [];
  let stickers = [];

  function renderEmoji() {
    const box = $('stk-emoji');
    if (box.dataset.done) return;
    box.dataset.done = '1';
    for (const e of EMOJI) {
      const b = document.createElement('button');
      b.textContent = e;
      b.addEventListener('click', () => insertAtCursor(e));
      box.appendChild(b);
    }
  }

  function insertAtCursor(text) {
    const el = inputEl;
    const s = el.selectionStart ?? el.value.length;
    const e = el.selectionEnd ?? el.value.length;
    el.value = el.value.slice(0, s) + text + el.value.slice(e);
    el.selectionStart = el.selectionEnd = s + text.length;
    autoGrow();
    el.focus();
  }

  function renderStickers() {
    const box = $('stk-mine');
    box.innerHTML = '';
    if (!stickers.length) {
      const d = document.createElement('div');
      d.className = 'empty';
      d.textContent = tEn('还没有表情包 —— 点右上角「＋ 添加」，从相册里选图（会自动缩到 400px 存进 app）', 'No stickers yet — tap "＋ Add" and pick images from your gallery');
      box.appendChild(d);
      return;
    }
    for (const s of stickers) {
      const b = document.createElement('button');
      const im = document.createElement('img');
      im.src = 'file://' + s.path;
      im.alt = '表情包';
      b.appendChild(im);
      b.title = '点一下发送；长按删除';
      b.addEventListener('click', () => sendSticker(s.path));
      let timer = null;
      b.addEventListener('touchstart', () => { timer = setTimeout(() => { timer = null; delSticker(s.path); }, 650); });
      b.addEventListener('touchend', () => { if (timer) clearTimeout(timer); });
      b.addEventListener('contextmenu', (ev) => { ev.preventDefault(); delSticker(s.path); });
      box.appendChild(b);
    }
  }

  function refreshStickers() {
    if (window.Android && typeof window.Android.listStickers === 'function') {
      try { stickers = JSON.parse(window.Android.listStickers() || '[]'); } catch { stickers = []; }
    }
    renderStickers();
  }

  window.__onStickers = (json) => {
    try { stickers = typeof json === 'string' ? JSON.parse(json) : json; } catch { stickers = []; }
    renderStickers();
    if (stickers.length) sysLine(tEn('已加入表情包（共 ' + stickers.length + ' 张）', 'Added to your stickers (' + stickers.length + ' total)'));
  };

  function delSticker(path) {
    if (!confirm(tEn('从表情包里删掉这张？', 'Remove this sticker?'))) return;
    try { stickers = JSON.parse(window.Android.deleteSticker(path) || '[]'); } catch {}
    renderStickers();
  }

  function showTab(which) {
    $('tab-emoji').classList.toggle('on', which === 'emoji');
    $('tab-mine').classList.toggle('on', which === 'mine');
    $('stk-emoji').hidden = which !== 'emoji';
    $('stk-mine').hidden = which !== 'mine';
    if (which === 'mine') refreshStickers();
  }

  function toggleStickers(force) {
    const box = $('stk');
    const show = force !== undefined ? force : box.hidden;
    if (show) closeSheets('stk');
    box.hidden = !show;
    if (show) { renderEmoji(); showTab('emoji'); }
  }

  function sendSticker(path) {
    if (streaming) return;
    attachment = { kind: 'image', path, name: '表情包', sticker: true, dataUrl: imgCache.get(path) || null };
    toggleStickers(false);
    send();
  }

  /* ---------- 设置 ---------- */
  const sheet = $('sheet');
  const openSheet = () => {
    closeSheets('sheet');   // 关键：别的浮层还开着的话会把它盖住
    // 只在"存过的值确实有内容"时才覆盖；否则保留 HTML 里的默认值
    const cur = currentChar();
    $('s-char-name').value = cur.name || '';
    $('s-char-emoji').value = cur.emoji || '';
    $('s-persona').value = String(personaFor(cur) || '').trim() || DEFAULT_PERSONA;
    fillProviders();
    $('s-provider').value = cfg.provider || 'deepseek';
    $('s-base').value = String(cfg.baseUrl || '').trim() || provider().base;
    $('s-model').value = cfg.model || (provider().models[0] || '');
    syncProviderFields();
    $('s-key').value = cfg.apiKey || '';
    if (cfg.temperature !== undefined && cfg.temperature !== '') $('s-temp').value = cfg.temperature;
    if (cfg.contextTurns) $('s-ctx').value = cfg.contextTurns;
    $('s-tts').checked = !!cfg.tts;
    $('s-diag').checked = !!cfg.diag;
    $('s-bgdim').value = Number(cfg.bgDim ?? 0.35);
    $('s-repo').value = cfg.repoSlug || '';
    $('s-lang').value = L();
    $('s-web').checked = cfg.webTools !== false;
    $('s-hint').textContent = hasShell() ? '' : '（当前是浏览器预览；装到手机上走系统通道）';
    try {
      const ver = (window.Android && window.Android.appVersion) ? window.Android.appVersion() : '1.0.0';
      $('s-about').textContent = tEn('小鲸鱼 v', 'XiaoJingYu v') + ver + tEn(' · 只有联网权限 · 数据只发给你选择的服务商 · 本应用没有服务器', ' · INTERNET permission only · data goes straight to the provider you chose · no server of ours');
    } catch (e) {}
    if (!String(cfg.apiKey || '').trim() && !HAS_BUILTIN_KEY) {
      $('s-hint').textContent = tEn('第一次用：选好服务商、填上 API Key，点「测试连接」确认 ✅', 'First time: pick a provider, paste your API key, then tap "Test connection" ✅');
    }
    sheet.hidden = false; sheet.classList.add('open');
    const memLen = String(memory.summary || '').length;
    if (memLen) $('s-hint').textContent = tEn('长期记忆：' + memLen + ' 字（她会一直记得这些）', 'Long-term memory: ' + memLen + ' chars (she always remembers this)');
    refreshNotes();
    diag('sheet-open', {
      boxPersonaLen: $('s-persona').value.length,
      cfgPersonaLen: (cfg.persona || '').length,
      boxCtx: $('s-ctx').value, boxModel: $('s-model').value,
      boxTemp: $('s-temp').value, htmlPersonaLen: HTML_PERSONA.length,
    });
  };
  const applySettings = () => {
    const nm = $('s-char-name').value.trim();
    const em = $('s-char-emoji').value.trim();
    const ps = $('s-persona').value.trim();
    if (nm) writeCharField('name', nm);
    if (em) writeCharField('emoji', em);
    if (ps) writeCharField('persona', ps);
    cfg.provider = $('s-provider').value || 'deepseek';
    cfg.baseUrl = $('s-base').value.trim();
    cfg.model = $('s-model').value.trim();
    cfg.apiKey = $('s-key').value.trim();
    cfg.vision = $('s-vision').checked;
    cfg.toolsOn = $('s-tools').checked;
    cfg.temperature = parseFloat($('s-temp').value) || 1;
    cfg.contextTurns = Math.max(4, parseInt($('s-ctx').value, 10) || 24);
    cfg.tts = $('s-tts').checked;
    cfg.diag = $('s-diag').checked;
    cfg.bgDim = parseFloat($('s-bgdim').value) || 0;
    cfg.webTools = $('s-web').checked;
    cfg.repoSlug = $('s-repo').value.trim();
    cfg.lang = $('s-lang').value === 'en' ? 'en' : 'zh';
    kv.set(LS.cfg, cfg);
  };
  // 语言切换会重建这段 HTML，所以每次重建后重新绑定
  function bindGetKey() {
    const a = $('s-getkey');
    if (!a || a.dataset.bound) return;
    a.dataset.bound = '1';
    a.addEventListener('click', (e) => {
      e.preventDefault();
      const url = provider().keyUrl || 'https://platform.deepseek.com/api_keys';
      if (window.Android && typeof window.Android.openUrl === 'function') window.Android.openUrl(url);
      else { $('s-hint').textContent = 'API key: ' + url; }
    });
  }
  on('s-provider', 'change', () => {
    const p = PROVIDERS.find((x) => x.id === $('s-provider').value) || PROVIDERS[0];
    cfg.provider = p.id;
    cfg.baseUrl = p.base;
    cfg.model = (p.models && p.models[0]) || cfg.model;
    cfg.vision = undefined; cfg.toolsOn = undefined;
    $('s-base').value = p.base;
    $('s-model').value = cfg.model;
    syncProviderFields();
  });
  on('who', 'click', openChars);
  on('char-close', 'click', closeChars);
  on('char-new', 'click', newChar);
  on('char-clear', 'click', () => {
    const list = charCustom();
    if (!list.length) { sysLine(tEn('没有自建角色', 'No custom characters')); return; }
    if (!confirm(tEn('清空全部 ' + list.length + ' 个自建角色？（它们的聊天记录会一起删掉，内置角色不受影响）', 'Delete all ' + list.length + ' custom characters? Their chats will be deleted too.'))) return;
    for (const c of list) { kv.set(histKey(c.id), []); kv.set(memKey(c.id), {}); }
    cfg.customChars = [];
    if (list.some((c) => c.id === charId())) cfg.character = 'jingyu';
    kv.set(LS.cfg, cfg);
    loadCharState(); renderAll(); renderCharList();
    sysLine(tEn('已清空自建角色', 'Custom characters cleared'));
  });
  on('gear', 'click', openSheet);
  const closeSheet = () => { sheet.hidden = true; sheet.classList.remove('open'); };
sheet.addEventListener('click', (e) => { if (e.target === sheet) closeSheet(); });
  on('s-save', 'click', () => {
    applySettings();
    updateHeader();   // 改名/换 emoji 后头部要跟着变
    closeSheet();
    diag('save', { char: charId(), model: cfg.model, ctx: cfg.contextTurns, temp: cfg.temperature });
    setStatus(tEn('已保存', 'Saved'), ''); setTimeout(() => setStatus(t('status'), ''), 1200);
    // 换了/第一次填 key → 自动验一次连接（省得用户自己点「测试连接」）
    const keyNow = String(cfg.apiKey || '').trim();
    if (keyNow && keyNow.slice(-6) !== cfg.testedTail) {
      cfg.testedTail = keyNow.slice(-6);
      kv.set(LS.cfg, cfg);
      setTimeout(runSelfTest, 500);
    }
  });
  // 测试连接：用当前输入框里的设置发一条最小请求，结果显示在提示行
  on('s-test', 'click', () => {
    applySettings();
    const hint = $('s-hint');
    sheetHint(tEn('测试中…', 'Testing…'));
    toast(tEn('测试中…', 'Testing…'));
    const msgs = [{ role: 'user', content: '只回两个字：在的' }];
    const onDelta = (d) => { hint.textContent = '测试中… ' + d; };
    const onDone = (t) => { hint.textContent = '✓ 通了：' + (t || '(空回复)'); diag('test-ok', { len: (t||'').length }); };
    const onError = (e) => { hint.textContent = '✗ 失败：' + e + '（key 或网络问题）'; diag('test-fail', { msg: String(e).slice(0, 160) }); };
    if (hasShell()) viaAndroid(msgs, onDelta, onDone, onError);
    else viaProxy(msgs, onDelta, onDone, onError);
  });
  on('s-clear', 'click', () => {
    if (!confirm('清空你们俩的聊天记录？')) return;
    history = []; saveHistory();
    memory = { summary: '', upTo: 0 }; kv.set('xjy.memory', memory);
    renderAll();
    $('s-hint').textContent = '已清空（含长期记忆）。';
  });
  logEl.addEventListener('scroll', () => { $('jump').hidden = nearBottom(); });
  on('jump', 'click', toBottom);

  /* ---------- 首次启动的自动自检：跑一次真实往返，结果上报（不打扰用户、不进历史） ---------- */
  function runSelfTest() {
    if (window.__XJY_NO_SELFTEST) return;
    const prev = kv.get('xjy.selftest', null);
    if (prev && prev.ok) return;                       // 成功过就不再打扰
    const msgs = [{ role: 'user', content: '只回两个字：在的' }];
    const t0 = Date.now();
    let acc = '';
    const done = (ok, extra) => {
      kv.set('xjy.selftest', Object.assign({ ok, at: Date.now(), ver: '1.6' }, extra || {}));
      diag(ok ? 'selftest-ok' : 'selftest-fail', Object.assign({ ms: Date.now() - t0, len: acc.length }, extra || {}));
    };
    try {
      startChat(msgs,
        (d) => { acc += d; },
        (full) => { acc = acc || full || ''; done(acc.trim().length > 0, { chars: acc.trim().length }); },
        (msg) => done(false, { msg: String(msg).slice(0, 200) }));
    } catch (e) { done(false, { msg: 'exception: ' + (e && e.message) }); }
  }

  /* ---------- 启动 ---------- */
  // 安卓返回键：先关设置面板，面板已关就让系统处理（退出）
  window.__onBack = () => {
    if (!sheet.hidden || sheet.classList.contains('open')) { closeSheet(); return true; }
    return false;
  };
  // 背景：优先用配置里的；没有就问原生（重装/换机后还能恢复）
  if (!cfg.bg && window.Android && typeof window.Android.currentBackground === 'function') {
    try { const u = window.Android.currentBackground(); if (u) { cfg.bg = u; kv.set(LS.cfg, cfg); } } catch {}
  }
  applyBackground();
  loadCharState();
  applyLang();
  renderAll();
  autoGrow();
  setTimeout(() => checkUpdate(false), 6000);                     // 静默查一次更新（有新版才提示）
  if (!hasAnyKey()) setTimeout(openSheet, 600);            // 首次打开：先引导填 key
  else if (HAS_BUILTIN_KEY) setTimeout(runSelfTest, 2500); // 自动自检只在内置 key 的私有构建里跑（公开版不偷偷发请求）
  window.__XJY_MISSING = MISSING;   // 供自检/测试读取：绑事件时没找到的元素
  if (MISSING.length) sysLine('⚠️ 界面元素缺失：' + MISSING.join('、') + '（功能可能不完整，请反馈）');
  diag('boot', { missing: MISSING.slice(0, 20),
    personaLen: String(currentChar().persona || '').length, htmlPersonaLen: HTML_PERSONA.length, char: charId(),
    model: cfg.model, provider: cfg.provider || 'deepseek', base: effectiveBase(), ctx: cfg.contextTurns, temp: cfg.temperature,
    cfgKeys: Object.keys(cfg).length, hasKey: !!String(cfg.apiKey || '').trim(), builtinKey: HAS_BUILTIN_KEY, memLen: String(memory.summary || '').length, lsOk: (() => { try { localStorage.setItem('xjy.probe','1'); return true; } catch { return false; } })(),
    storedRawLen: (() => { try { return (window.Android && window.Android.kvGet ? window.Android.kvGet(LS.cfg) : '').length; } catch { return -1; } })(),
    storedKeys: (() => { try { const r = window.Android && window.Android.kvGet ? window.Android.kvGet(LS.cfg) : ''; return r ? Object.keys(JSON.parse(r) || {}) : []; } catch { return ['parse-error']; } })(),
  });
  if (!kv.get(LS.seen, false)) { kv.set(LS.seen, true); }
})();
