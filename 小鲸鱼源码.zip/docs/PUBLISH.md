# 发布到 GitHub 的步骤

这份目录已经是**可以直接推上去**的状态（不含密钥、证书、构建产物、工具链）。

## 一次性：建仓库并推上去

```sh
cd xiaojingyu-repo          # 就是这份目录
git init
git add .
git commit -m "小鲸鱼 v1.0.0：一个只属于你自己的安卓 AI 聊天 App"
git branch -M main
git remote add origin https://github.com/c201195286-maker/xjy.git
git push -u origin main
```

> 仓库已经建好了（github.com/c201195286-maker/xjy）。如果建的时候勾了 README/LICENSE，先 `git pull --rebase origin main` 合一下，
> 或者（因为这是全新仓库）直接 `git push -u origin main --force`。

## 打一个 Release 并把 APK 挂上去

1. 仓库页右侧 **Releases → Draft a new release**
2. Tag 填 `v1.0.0`，标题「小鲸鱼 v1.0.0」，说明可以直接复制 [CHANGELOG.md](CHANGELOG.md) 里 1.0.0 那一段
3. 附件里把 `小鲸鱼.apk` 拖进去（**确认是不含 key 的那份**：`bash build.sh` 默认就不内置 key）
4. 发布

## 发布前自查清单

- [ ] `grep -rn "sk-[A-Za-z0-9]\{20,\}" .` 只应命中测试里的**假 key**（`tools/javastream/StreamTest.java` 的 `sk-invalid…`）
- [ ] 仓库里没有 `android/*.keystore`（各自本地生成，已加进 `.gitignore`）
- [ ] 仓库里没有 `build/`、`toolchain/`、`debs/`、`node_modules/`
- [ ] 上传的 APK 里搜不到真实 key：
      `unzip -p 小鲸鱼.apk classes.dex | strings | grep -c "sk-"` 结果应该是 0
- [ ] README 里的截图/图标路径正确（`docs/` 下）
- [ ] 想改默认人设：`app/index.html` 里那段人设文字（以及 `app/app.js` 的兜底串）

## 之后每次改版的流程

```sh
# 1. 改完代码，本地验证
node tools/smoke-test.mjs && node tools/memory-test.mjs
# 2. 升版本号（android/AndroidManifest.xml 的 versionName / versionCode，versionCode 必须递增）
# 3. 出包
bash build.sh
# 4. 更新 CHANGELOG.md，commit & push，再建一个 Release 挂上新 APK
```

> 小提示：Android 升级安装要求**同一个签名**，所以 `android/xiaojingyu.keystore` 虽然不进仓库，
> 但你自己要备份好 —— 丢了的话已装的用户只能卸载重装。
